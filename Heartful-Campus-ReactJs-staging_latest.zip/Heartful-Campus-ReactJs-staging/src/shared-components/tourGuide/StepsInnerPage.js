export default {
  "Superadmin" : {
    
  },
  "Admin" : {

  },
  "Volunteer Master" : {

  },
  "Content Editor" : {

  },
  "State Training Coordinator" : {

  },
  "State Coordinator" : {
    "college": [
      {
        content: "Click here to add new college and submit after entering the details. It will then redirect to College Staff page.",
        title: "Add College",
        target: ".collegeList",
        placement: "left",
        disableBeacon: true
      }
    ],
    "poc": [
      {
        content: "Click Add POC button and select the volunteer from dropdown to assign it as college POC for the college.",
        title: "Add POC",
        target: ".pocCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "staff": [
      {
        content: "Click Add Staff button and enter the required fields and submit it. After Submission College Staff will get an email to reset the password. Once password reset is done, Staff will get an email for login.",
        title: "Add Staff",
        target: ".staffCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "mou": [
      {
        content: "Click Choose File to Browse and Select MOU file for the college and click Save button to upload it.",
        title: "Add MOU",
        target: ".mouUpload",
        placement: "left",
        disableBeacon: true
      }
    ],
    "program": [
      {
        content: "Click Create Program button and select the program type from dropdown and rename the auto generated program name if you wish to change.",
        title: "Add Program",
        target: ".programCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "media": [
      {
        content: "Click Upload Media button and click Choose File button to browse and select the files related to the program and upload it.",
        title: "Add Media",
        target: ".uploadMedia",
        placement: "left",
        disableBeacon: true
      }
    ],
    "dispatch": [
      {
        content: "Select Type and Value and click on participant configuration.",
        title: "Participation Configuration",
        target: ".participationConfig",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Add Participant Config Type and Value before dispatching the certification for the Program",
        title: "Dispatch Certificate",
        target: ".dispatchCert",
        placement: "left",
        disableBeacon: true
      }
    ],
    "certificate": [
      {
        content: "Select Certificate from the gallery",
        title: "Certificate Template",
        target: ".certTemplate",
        placement: "left",
        disableBeacon: true
      }
    ],
    "changerequest": [
      {
        content: "Reassign another trainer",
        title: "Change Request",
        target: ".assignCRTrainer",
        placement: "left",
        disableBeacon: true
      }
    ],
    "session": [
      {
        content: "Click Add New button and select session from dropdown and select session start & end date and click Submit button.",
        title: "Add Session",
        target: ".sessionCreation",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Assign Trainer user icon from Actions column and select the trainer from dropdown for the session.",
        title: "Assign Session",
        target: ".assignTrainer",
        placement: "left",
        disableBeacon: true
      }
    ],
    "participant" : [
      {
        content: "Click Add New button and enter the required fields and submit it. After Submission added participant will be listed in the below table.",
        title: "Add Participant",
        target: ".addParticipant",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Choose File button to Browse and select the CSV file for participants bulk upload. Reference CSV file can be downloaded from click here link.",
        title: "Bulk Participant Upload",
        target: ".bulkUpload",
        placement: "left",
        disableBeacon: true
      }
    ]
  },
  "Zone Coordinator" : {
    "college": [
      {
        content: "Click here to add new college and submit after entering the details. It will then redirect to College Staff page.",
        title: "Add College",
        target: ".collegeList",
        placement: "left",
        disableBeacon: true
      }
    ],
    "poc": [
      {
        content: "Click Add POC button and select the volunteer from dropdown to assign it as college POC for the college.",
        title: "Add POC",
        target: ".pocCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "staff": [
      {
        content: "Click Add Staff button and enter the required fields and submit it. After Submission College Staff will get an email to reset the password. Once password reset is done, Staff will get an email for login.",
        title: "Add Staff",
        target: ".staffCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "mou": [
      {
        content: "Click Choose File to Browse and Select MOU file for the college and click Save button to upload it.",
        title: "Add MOU",
        target: ".mouUpload",
        placement: "left",
        disableBeacon: true
      }
    ],
    "program": [
      {
        content: "Click Create Program button and select the program type from dropdown and rename the auto generated program name if you wish to change.",
        title: "Add Program",
        target: ".programCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "session": [
      {
        content: "Click Add New button and select session from dropdown and select session start & end date and click Submit button.",
        title: "Add Session",
        target: ".sessionCreation",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Assign Trainer user icon from Actions column and select the trainer from dropdown for the session.",
        title: "Assign Session",
        target: ".assignTrainer",
        placement: "left",
        disableBeacon: true
      }
    ],
    "participant" : [
      {
        content: "Click Add New button and enter the required fields and submit it. After Submission added participant will be listed in the below table.",
        title: "Add Participant",
        target: ".addParticipant",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Choose File button to Browse and select the CSV file for participants bulk upload. Reference CSV file can be downloaded from click here link.",
        title: "Bulk Participant Upload",
        target: ".bulkUpload",
        placement: "left",
        disableBeacon: true
      }
    ],
    "media": [
      {
        content: "Click Upload Media button and click Choose File button to browse and select the files related to the program and upload it.",
        title: "Add Media",
        target: ".uploadMedia",
        placement: "left",
        disableBeacon: true
      }
    ],
    "changerequest": [
      {
        content: "Reassign another trainer",
        title: "Change Request",
        target: ".assignCRTrainer",
        placement: "left",
        disableBeacon: true
      }
    ]
  },
  "College Staff" : {
    "program": [
      {
        content: "Click Create Program button and select the program type from dropdown and rename the auto generated program name if you wish to change.",
        title: "Add Program",
        target: ".programCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "mou": [
      {
        content: "Click Choose File to Browse and Select MOU file for the college and click Save button to upload it.",
        title: "Add MOU",
        target: ".mouUpload",
        placement: "left",
        disableBeacon: true
      }
    ]
  },
  "Volunteer" : {
    "college": [
      {
        content: "Click here to add new college and submit after entering the details. It will then redirect to College Staff page.",
        title: "Add College",
        target: ".collegeList",
        placement: "left",
        disableBeacon: true
      }
    ],
    "mou": [
      {
        content: "Click Choose File to Browse and Select MOU file for the college and click Save button to upload it.",
        title: "Add MOU",
        target: ".mouUpload",
        placement: "left",
        disableBeacon: true
      }
    ],
    "program": [
      {
        content: "Click Create Program button and select the program type from dropdown and rename the auto generated program name if you wish to change.",
        title: "Add Program",
        target: ".programCreation",
        placement: "left",
        disableBeacon: true
      }
    ],
    "session": [
      {
        content: "Click Add New button and select session from dropdown and select session start & end date and click Submit button.",
        title: "Add Session",
        target: ".sessionCreation",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Assign Trainer user icon from Actions column and select the trainer from dropdown for the session.",
        title: "Assign Session",
        target: ".assignTrainer",
        placement: "left",
        disableBeacon: true
      }
    ],
    "participant" : [
      {
        content: "Click Add New button and enter the required fields and submit it. After Submission added participant will be listed in the below table.",
        title: "Add Participant",
        target: ".addParticipant",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Choose File button to Browse and select the CSV file for participants bulk upload. Reference CSV file can be downloaded from click here link.",
        title: "Bulk Participant Upload",
        target: ".bulkUpload",
        placement: "left",
        disableBeacon: true
      }
    ],
    "media": [
      {
        content: "Click Upload Media button and click Choose File button to browse and select the files related to the program and upload it.",
        title: "Add Media",
        target: ".uploadMedia",
        placement: "left",
        disableBeacon: true
      }
    ],
    "certificate": [
      {
        content: "Select Certificate from the gallery",
        title: "Certificate Template",
        target: ".certTemplate",
        placement: "left",
        disableBeacon: true
      }
    ],
    "dispatch": [
      {
        content: "Select Type and Value and click on participant configuration.",
        title: "Participation Configuration",
        target: ".participationConfig",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Add Participant Config Type and Value before dispatching the certification for the Program",
        title: "Dispatch Certificate",
        target: ".dispatchCert",
        placement: "left",
        disableBeacon: true
      }
    ],
    "changerequest": [
      {
        content: "Reassign another trainer",
        title: "Change Request",
        target: ".assignCRTrainer",
        placement: "left",
        disableBeacon: true
      }
    ]
  },
  "Trainer" : {
    "upcoming": [
      {
        content: "You can inform about your unavailability here.",
        title: "Notify Unavailability",
        target: ".notifyUnavailable",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Update your comment for change request",
        title: "Change Request",
        target: ".changeReq",
        placement: "left",
        disableBeacon: true
      }
    ],
    "completed": [
      {
        content: "Manage Participant for sessions",
        title: "Manage Participant",
        target: ".manageParticipant",
        placement: "left",
        disableBeacon: true
      }
    ],
    "participant" : [
      {
        content: "Click Add New button and enter the required fields and submit it. After Submission added participant will be listed in the below table.",
        title: "Add Participant",
        target: ".addParticipant",
        placement: "left",
        disableBeacon: true
      },
      {
        content: "Click Choose File button to Browse and select the CSV file for participants bulk upload. Reference CSV file can be downloaded from click here link.",
        title: "Bulk Participant Upload",
        target: ".bulkUpload",
        placement: "left",
        disableBeacon: true
      }
    ],
    "notify" : [
      {
        content: "Notify Unavailability Module",
        title: "Notify Unavailability",
        target: ".notifyUnavailable",
        placement: "left",
        disableBeacon: true
      }
    ]
  }
}