export default {
  "State Coordinator": [
    {
      content: "FAQ Section. Get to know Frequently Asked Questions about the process",
      title: "FAQ",
      target: ".faq .list",
      placement: "top",
      disableBeacon: true
    },
    {
      content: "Click on this link for any help.",
      title: "Help",
      target: ".help .listq",
      placement: "top"
    },
    {
      content: "Notification Section. Will list all the received notifications.",
      title: "User Notification Details",
      target: ".notification",
      placement: "top"
    },
    {
      content: "You can access your profile information here.",
      title: "Profile",
      target: ".profile",
      placement: "top"
    },
    {
      content: "Navigate all menu items.",
      textAlign: "center",
      target: ".projects",
      placement: "top",
      title: "Menu List"
    },
    {
      content: "Add and Manage college.",
      placement: "right",
      target: ".college",
      title: "College"
    },
    {
      content: "By clicking this, will list all the users and its details.",
      placement: "right",
      target: ".user",
      title: "User"
    },
    {
      content: "By clicking this, will show all the conducted programs in colleges and its details.",
      placement: "right",
      target: ".list",
      title: "Program"
    },
    {
      content: "Add and Manage trainers.",
      placement: "right",
      target: ".trainerMenu",
      title: "Trainer"
    }
  ],
  "Zone Coordinator": [
    {
      content: "FAQ Section. Get to know Frequently Asked Questions about the process",
      title: "FAQ",
      target: ".faq .list",
      placement: "top",
      disableBeacon: true
    },
    {
      content: "Click on this link for any help.",
      title: "Help",
      target: ".help .listq",
      placement: "top"
    },
    {
      content: "Notification Section. Will list all the received notifications.",
      title: "User Notification Details",
      target: ".notification",
      placement: "top"
    },
    {
      content: "You can access your profile information here.",
      title: "Profile",
      target: ".profile",
      placement: "top"
    },
    {
      content: "Navigate all menu items.",
      textAlign: "center",
      target: ".projects",
      placement: "bottom",
      title: "Menu List"
    },
    {
      content: "Add and Manage college.",
      placement: "right",
      target: ".college",
      title: "College"
    },
    {
      content: "By clicking this, will show all the conducted programs in colleges and its details.",
      placement: "right",
      target: ".list",
      title: "Program"
    },
    {
      content: "Add and Manage trainers.",
      placement: "right",
      target: ".trainerMenu",
      title: "Trainer"
    }
  ],
  "Trainer": [
    {
      content: "FAQ Section",
      title: "FAQ",
      target: ".faq .list",
      placement: "top",
      disableBeacon: true
    },
    {
      content: "Click on this link for any help.",
      title: "Help",
      target: ".help .listq",
      placement: "top"
    },
    {
      content: "Notification Section. Will list all the received notifications.",
      title: "User Notification Details",
      target: ".notification",
      placement: "top"
    },
    {
      content: "You can access your profile information here.",
      title: "Profile",
      target: ".profile",
      placement: "top"
    },
    {
      content: "Navigate all menu items.",
      textAlign: "center",
      target: ".projects",
      placement: "bottom",
      title: "Menu List"
    },
    {
      content: "By clicking this, will show all the conducted programs for the trainer and its details.",
      placement: "right",
      target: ".list",
      title: "My Program"
    }
  ],
  "College Staff" : [
    {
      content: "Click Create Program button and select the program type from dropdown and rename the auto generated program name if you wish to change.",
      title: "Add Program",
      target: ".programCreation",
      placement: "left",
      disableBeacon: true
    },
    {
      content: "Click Choose File to Browse and Select MOU file for the college and click Save button to upload it.",
      title: "Add MOU",
      target: ".mouUpload",
      placement: "left"
    }
  ],
  "Volunteer" : [
    {
      content: "FAQ Section. Get to know Frequently Asked Questions about the process",
      title: "FAQ",
      target: ".faq .list",
      placement: "top",
      disableBeacon: true
    },
    {
      content: "Click on this link for any help.",
      title: "Help",
      target: ".help .listq",
      placement: "top"
    },
    {
      content: "Notification Section. Will list all the received notifications.",
      title: "User Notification Details",
      target: ".notification",
      placement: "top"
    },
    {
      content: "You can access your profile information here.",
      title: "Profile",
      target: ".profile",
      placement: "top"
    },
    {
      content: "Navigate all menu items.",
      textAlign: "center",
      target: ".projects",
      placement: "bottom",
      title: "Menu List"
    },
    {
      content: "Add and Manage college.",
      placement: "right",
      target: ".college",
      title: "College"
    },
    {
      content: "By clicking this, will show all the conducted programs in colleges and its details.",
      placement: "right",
      target: ".list",
      title: "Program"
    } 
  ]
}