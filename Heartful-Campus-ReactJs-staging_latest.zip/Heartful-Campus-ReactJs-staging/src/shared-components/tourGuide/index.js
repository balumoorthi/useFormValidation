import React, { Component } from 'react';
import { connect } from 'react-redux';

import Joyride,{ ACTIONS, EVENTS, STATUS } from 'react-joyride';

import PropTypes from 'prop-types';

import { OPENSIDEBAR } from 'store/actions/type/app';

import { Cookies, withCookies } from "react-cookie";
import { instanceOf } from "prop-types";

class HFNReactJoyride extends Component  {
  static propTypes = {
    cookies: instanceOf(Cookies).isRequired
  };
  constructor(props) {
    super(props);

    this.state = {
      tourGuidance: localStorage.getItem('tourGuidance'),
      tourGuidance1 : this.props.cookies.get("tourGuidance"),
    };
  }
  
  static propTypes = {
    joyride: PropTypes.shape({
      callback: PropTypes.func
    })
  };
  
  static defaultProps = {
    joyride: {}
  };
  
  handleClickStart = async() => {
    const { cookies } = this.props;
    if(this.props.cookies.get("tourRequired") !== 'no' || this.props.cookies.get("tourGuidance") == 2) {
      await this.setState({
        run:this.props.td && this.props.td.toursteps.run,
        continuous:this.props.td && this.props.td.toursteps.continuous,
        loading:this.props.td && this.props.td.toursteps.loading,
        stepIndex:this.props.td && this.props.td.toursteps.stepIndex,
        steps:this.props.td && this.props.td.toursteps.steps,
        loadSet:this.props.td && this.props.td.toursteps.loadSet,
      })
      cookies.set("tourGuidance", 0, { path: "/" }); // set the cookie
    }
  };
  
  handleClickNextButton = () => {
    const { stepIndex } = this.state;
    if (this.state.stepIndex === 1) {
      this.setState({
        stepIndex: stepIndex + 1
      });
    }
  };
  
  handleJoyrideCallback = data => {
    const { joyride } = this.props;
    const { action, index, type, status } = data;
    if ([STATUS.FINISHED, STATUS.SKIPPED].includes(status) && this.state.run) {
      // Need to set our running state to false, so we can restart if we click start again.
      this.setState({ run: false });
    } else if (type === EVENTS.STEP_AFTER && index === 0) {
      
      this.setState({ run: false, loading: true });
  
      setTimeout(() => {
        this.setState({
          loading: false,
          run: true,
          stepIndex: index + (action === ACTIONS.PREV ? -1 : 1)
        });
      }, 0);
    } else if (type === EVENTS.STEP_AFTER || type === EVENTS.TARGET_NOT_FOUND) {
      if(data.step.content ==="Navigate all menu items."){
        this.props.dispatch({ type: OPENSIDEBAR, payload: false })
      }
      // Update state to advance the tour
      this.setState({ stepIndex: index + (action === ACTIONS.PREV ? -1 : 1) });
    } else if (type === EVENTS.TOOLTIP_CLOSE) {
      this.setState({ stepIndex: index + 1 });
    }

    if (typeof joyride.callback === "function") {
      joyride.callback(data);
    } else {
      // console.group(type);
      // console.log(data); //eslint-disable-line no-console
      // console.groupEnd();
    }
  };

  componentDidMount(){
  //  this.handleClickStart()
  }
  componentDidUpdate() {
    
    if(this.props.td.toursteps.loadSet !== this.state.loadSet){
     this.handleClickStart()
    }
  }

  // componentDidUpdate() {
  //   this.handleClickStart();
  // }
  
  
  render() {
    const { ...joyrideProps } = this.state;
    const props = {
      ...joyrideProps,
    };
    
  return (
    <div>
      <Joyride
          scrollToFirstStep
          showProgress
          showSkipButton
          disableCloseOnEsc
          disableOverlayClose
          {...props}
          // styles={{overflowY:"scroll !important"}}
          styles={{
            buttonNext: {
              backgroundColor: '#FFF',
              color: 'rgb(51, 51, 51)',
              border: '1px solid #000',
              borderRadius: '6px'
            },
            buttonBack: {
              color: 'rgb(51, 51, 51)'
            },
            buttonClose: {
              display: 'none'
            }
          }}
          locale={{
            last: "End Tour",
            skip: "Close Tour"
          }}
          callback={this.handleJoyrideCallback}/>
    </div>
  )
}
}
const mapStateToProps = (state) => ({
  td: state.appDetails
});

export default withCookies(connect(mapStateToProps)(HFNReactJoyride));