import { ax } from 'services/base';

export default class DashboardService {

  getCountsOfCards() {
    return ax.get('maindashboard');
  }

  getCollegesPerState() {
    return ax.get('collegestats');
  }

  getEventTypes() {
    return ax.get('eventtypestats');
  }

  getCenterSessions(payload) {
    return ax.post('activeboards', payload);
  }

  getTrainerSessions(payload) {
    return ax.post('activeboards', payload);
  }

  getEventsByMonth() {
    return ax.get('sessionsbymonths');
  }

}