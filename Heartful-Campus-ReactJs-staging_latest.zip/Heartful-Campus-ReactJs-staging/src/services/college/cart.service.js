import { ax } from 'services/base'

export default class CollegeCartService {

  getCart(id) {
    return ax.get(`collegecart/${id}`)
  }

  getCollegeList() {
    return ax.get(`collegecart`)
  }

  getModulesOffered(payload) {
    return ax.post(`listdisciplinemodules`, payload)
  }

  addCart(payload) {
    return ax.post(`collegecart`, payload)
  }

  updateCart(id, payload) {
    return ax.post(`collegecart/${id}`, payload)
  }

  removeCart(id) {
    return ax.delete(`collegecart/${id}`)
  }

  getCollegeStatus(params) {
    return ax.get(`Cartinprogress/`, { params: params })
  }

  addCartItem(payload) {
    return ax.post(`collegecartmodule/`, payload)
  }

  finalizeCart(payload) {
    return ax.post(`collegecartfinalize/`, payload)
  }

  cancelCart(payload) {
    return ax.post(`cancel-cart`, payload)
  }

}