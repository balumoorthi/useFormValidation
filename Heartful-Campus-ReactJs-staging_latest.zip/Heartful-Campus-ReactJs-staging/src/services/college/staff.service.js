import { ax } from 'services/base'

const config = { headers: { 'content-type': 'multipart/form-data' } }

export default class StaffService {

  getStaff(id) {
    return ax.get(`collegestaff/${id}`)
  }

  getStaffList(payload) {
    return ax.post(`collegestaffcollege`, payload)
  }

  addStaff(payload) {
    return ax.post(`collegestaff`, payload, config)
  }

  updateStaff(id, payload) {
    return ax.put(`user/${id}`, payload);
  }

  removeStaff(id) {
    return ax.delete(`collegestaff/${id}`)
  }

}
