import { ax } from 'services/base'

const config = { headers: { 'content-type': 'multipart/form-data' } }

export default class CollegeService {

  getCollege(id) {
    return ax.get(`college/${id}`)
  }
  
  getCollegeList(payload) {
    return ax.post(`college-list`, payload)
  }
  
  addCollege(payload) {
    return ax.post(`college`, payload, config)
  }
  
  updateCollege(id, payload) {
    return ax.post(`college/${id}`, payload)
  }
  
  removeCollege(id) {
    return ax.delete(`college/${id}`)
  }
  
  updateCollegeMOU(id, payload) {
    return ax.post(`college-upload-mou/${id}`, payload, config)
  }
  
  collegereport(payload) {
    return ax.post('collegereport', payload)
  }
  
  collegeLookUp(params) {
    return ax.get(`collegelookup`,{params: params})
  }

  getCollegeMous(payload) {
    return ax.post(`college/list-all-mous`, payload)
  }

  downloadArtifacts(payload) {
    return ax.post('artifacts-download', payload)
  }

}