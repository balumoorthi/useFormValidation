import { ax } from 'services/base';

export default class Participant {

  getParticipantList(payload) {
    return ax.post(`listparticipants`, payload)
  }

  getParticipant(id) {
    return ax.get(`participant/${id}`)
  }

  addParticipant(payload) {
    return ax.post(`participant`, payload)
  }

  updateParticipant(id, payload) {
    return ax.post(`participant/${id}`, payload)
  }

  removeParticipant(id) {
    return ax.delete(`participant/${id}`)
  }

  uploadParticipantList(payload) {
    return ax.post(`participantbulk`, payload);
  }

  getOverallParticipantList(payload) {
    return ax.post(`listoverallparticipants`, payload)
  }

  generateParticipantCertificate(payload) {
    return ax.post(`generatemanualCert`, payload)
  }

  downloadParticipantCertificate(payload) {
    return ax.post(`downloadCert`, payload)
  }
}