import { Component } from 'react'
import { ax } from 'services/base'

const config = { headers: { 'content-type': 'multipart/form-data' } }

export default class Program extends Component {

  getProgramList(params, id) {
    return ax.get(`program/college/${id}`, { params })
  }

  getProgram(id) {
    return ax.get(`collegecart/${id}`)
  }

  addProgram(payload) {
    return ax.post(`program`, payload, config)
  }

  updateProgram(id, payload) {
    return ax.post(`program/${id}`, payload)
  }

  removeProgram(id) {
    return ax.delete(`collegecart/${id}`)
  }

  programdocuments(payload, eventId) {
    return ax.post(`programdocuments`, { session_id: eventId, ...payload })
  }

  programdocumentsUpload(payload) {
    return ax.post(`programdocuments/upload`, payload)
  }

  removeProgramdocuments(id) {
    return ax.delete(`programdocuments/${id}`)
  }

  getCollegeProgramList(payload) {
    return ax.post(`program/college`, payload)
  }

  uploadCertificate(payload) {
    return ax.post(`program/uploadcertificate`, payload, config)
  }

  attchCertificateFromGallery(payload) {
    return ax.put(`program/uploadcertificate`, payload, config)
  }

  saveCertificatePosition(payload) {
    return ax.post(`setcertposition`, payload)
  }

  previewCertificate(payload) {
    return ax.post(`certificatepreview`, payload)
  }
}