import { ax } from 'services/base'

export default class POCService {

  getPOC(id) {
    return ax.get(`collegepoc/${id}`)
  }

  getPOCList(payload) {
    return ax.post(`collegepoccollege`, payload)
  }

  addPOC(payload) {
    return ax.post(`collegepoc`, payload)
  }

  updatePOC(id, payload) {
    return ax.post(`collegepoc/${id}`, payload)
  }

  removePOC(id) {
    return ax.delete(`collegepoc/${id}`)
  }

}