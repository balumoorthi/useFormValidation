
import { ax } from 'services/base'

export default class FaqService {

  getFAQList(payload) {
    return ax.post('faq-list', payload)
  }

  getFAQ(id) {
    return ax.get(`faq/${id}`)
  }

  addFAQ(payload) {
    return ax.post(`faq`, payload)
  }

  updateFAQ(id, payload) {
    return ax.put(`faq/${id}`, payload)
  }

  removeFAQ(id) {
    return ax.delete(`faq/${id}`)
  }


  getFaqViewList(id, params) {
    if (params.user_type === "CS")
      return ax.get(`listactivefaqs/${id}`, { params: params })
    else
      return ax.get(`listactivefaqs/${id}`)
  }

  getHelpList(payload) {
    return ax.post(`help`, payload)
  }

  getHelpDetails(id) {
    return ax.get(`help/${id}`,)
  }

}
