
import { ax } from 'services/base';

export default class TrainerDashboardService {

  getTrainerData(userId) {
    return ax.get(`trainer/dashboard/${userId}`)
  }


}
