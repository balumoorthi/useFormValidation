
import { ax } from 'services/base';

export default class StaffHelpService {
   getStaffHelp(payload) {
    return ax.post(`help`,payload)
  }
   getStaffHelpDetails(id) {
    return ax.get(`help/${id}`,)
  }
}
