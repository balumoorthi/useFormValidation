import { ax } from 'services/base';

export default class SessionService {

  getSession(id) {
    return ax.get(`program/${id}`)
  }

  getSessions(payload) {
    return ax.post(`session-list`, payload)
  }

  addSession(payload) {
    return ax.post(`finalizemisseditems`, payload)
  }

  assignTrainer(id, payload) {
    return ax.put(`program/${id}`, payload)
  }
  
  removeSession(id) {
    return ax.delete(`program/${id}`)
  }
  
  dispatchCertificate(payload) {
    return ax.post(`certdispatch`, payload);
  }

  updateSession(id, payload) {
    return ax.put(`program/${id}`, payload)
  }

  participantConfig(payload) {
    return ax.post(`participation-configuration`, payload);
  }

  updateProgram(id, payload) {
    return ax.put(`collegecart/${id}`, payload)
  }
}