import { ax } from 'services/base';

export default class AutoCompleteService {

  getCollegeSearchList(payload) {
    return ax.post(`collegeSearchList/`, payload)
  }

  getTrainerSearchList(payload) {
    return ax.post(`admin/viewrequest/`, payload)
  }

}
