
import { ax } from "services/base";

export default class CollegeStaffService {

  getCollegeStaffs(payload) {
    return ax.post("cs-user-list", payload);
  }

  updateCollegeStaff(id, payload) {
    return ax.put(`user/${id}`, payload);
  }

  removeCollegeStaff(id) {
    return ax.delete(`user/${id}`);
  }

}
