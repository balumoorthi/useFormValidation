import { ax } from 'services/base'

const config = { headers: { 'content-type': 'multipart/form-data' } }

export default class ProgramService {

  getProgram(id) {
    return ax.get(`program/${id}`)
  }

  getProgramList(payload) {
    return ax.post(`cart-list`,payload)
  }

  addProgram(payload) {
    return ax.post(`program`,payload ,config)
  }

  updateProgram(id,payload) {
    return ax.post(`program/${id}`, payload)
  }

  removeProgram(id) {
    return ax.delete(`collegecart/${id}`)
  }

  programReport(payload) {
    return ax.post('eventreport', payload)
  }

  updateProgramName(id,payload) {
    return ax.put(`collegecart/${id}`, payload)
  }

}
