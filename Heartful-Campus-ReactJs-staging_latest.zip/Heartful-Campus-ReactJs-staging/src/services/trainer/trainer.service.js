
import { ax } from 'services/base';

export default class TrainerService {

  getTrainerList(payload) {
    return ax.post('trainer-list', payload)
  }

  getTrainer(id) {
    return ax.get(`trainer/${id}`)
  }

  addTrainer(payload) {
    return ax.post(`trainer`, payload)
  }

  activateTrainer(params) {
    return ax.get(`user/activate`, { params: params });
  }

  updateTrainer(id, payload) {
    return ax.put(`trainer/${id}`, payload)
  }

  removeTrainer(id) {
    return ax.delete(`trainer/${id}`)
  }

  getTrainerPrograms(payload, id) {
    return ax.post(`trainer/listmyprograms/${id}`, payload)
  }

  getTrainerCalendar(payload) {
    return ax.post(`trainer/getmonthwiseprograms`, payload)
  }

  getTrainerReport(payload) {
    return ax.post(`trainerreport`, payload)
  }

  createChangeRequest(payload) {
    return ax.post(`trainer/postrequest`, payload)
  }

  getChangeRequests(payload) {
    return ax.post(`admin/viewrequest`, payload)
  }

  updateChangeRequest(payload) {
    return ax.post(`admin/updaterequeststatus`, payload)
  }

  revertChangeRequest(params) {
    return ax.post(`trainer/withdrawrequest`, params)
  }
  gettraineravailability(payload) {
    let id = payload.user_info_id
    return ax.get(`trainer/gettraineravailability?user_id=${id}`)
  }

  traineravailability(payload) {
    return ax.post(`trainer/traineravailability`, payload.item);
  }

}
