
import { ax } from 'services/base'

export default class FaqCategoryService {

  getFAQCategoryList(payload) {
    return ax.post('faqcategorylist', payload)
  }

  getFAQCategory(id) {
    return ax.get(`faqcategory/${id}`)
  }

  addFAQCategory(payload) {
    return ax.post(`faqcategory`, payload)
  }

  updateFAQCategory(id, payload) {
    return ax.put(`faqcategory/${id}?category=${payload.category}&status_id=${payload.status_id}`, payload)
  }

  removeFAQCategory(id) {
    return ax.delete(`faqcategory/${id}`)
  }
}
