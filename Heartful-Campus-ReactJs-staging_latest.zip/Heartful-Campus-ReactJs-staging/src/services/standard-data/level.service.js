
import { ax } from 'services/base'

export default class LevelService {

  getLevelList(params) {
    return ax.post('listlevel',{ ...params })
  }

  getLevel(id) {
    return ax.get(`level/${id}`)
  }

  addLevel(payload) {
    return ax.post(`level`, payload)
  }

  updateLevel(id, payload) {
    return ax.put(`level/${id}`, payload)
  }

  removeLevel(id) {
    return ax.delete(`level/${id}`)
  }

}
