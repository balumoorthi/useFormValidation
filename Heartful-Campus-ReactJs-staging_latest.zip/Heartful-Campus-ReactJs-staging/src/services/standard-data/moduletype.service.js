import { ax } from 'services/base'

export default class ModuleTypeService {

  getModuleTypeList(params) {
    return ax.post('listmoduletype',{ ...params })
  }

  getModuleType(id) {
    return ax.get(`moduletype/${id}`)
  }

  addModuleType(payload) {
    return ax.post(`moduletype`, payload)
  }

  updateModuleType(id, payload) {
    return ax.put(`moduletype/${id}`, payload)
  }

  removeModuleType(id) {
    return ax.delete(`moduletype/${id}`)
  }

}