
import { ax } from 'services/base';

const config = { headers: { 'content-type': 'multipart/form-data' } }

export default class UnitService {

  getUnitList(params) {
    return ax.post('listunit', { ...params })
  }

  getUnit(id) {
    return ax.get(`unit/${id}`)
  }

  addUnit(payload) {
    return ax.post(`unit`, payload)
  }

  updateUnit(id, payload) {
    return ax.put(`unit/${id}`, payload)
  }

  removeUnit(id) {
    return ax.delete(`unit/${id}`)
  }
  addAttachment(payload) {
    return ax.post(`units/postdocuments`, payload, config)
  }
  listAttachments(id) {
    return ax.get(`units/listdocuments/${id}`)
  }

  removeAttachment(id) {
    return ax.delete(`units/deletedocuments/${id}`)
  }

}
