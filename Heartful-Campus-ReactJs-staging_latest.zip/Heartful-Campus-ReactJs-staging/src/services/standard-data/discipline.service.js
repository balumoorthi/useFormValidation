
import { ax } from 'services/base'

export default class DisciplineService {

  getDisciplineList(params) {
    return ax.post('listdiscipline',{ ...params })
  }

  getDiscipline(id) {
    return ax.get(`discipline/${id}`)
  }

  addDiscipline(payload) {
    return ax.post(`discipline`, payload)
  }

  updateDiscipline(id, payload) {
    return ax.put(`discipline/${id}`, payload)
  }

  removeDiscipline(id) {
    return ax.delete(`discipline/${id}`)
  }

}
