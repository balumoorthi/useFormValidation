
import { ax } from 'services/base'

export default class BatchService {

  getBatchList(params) {
    return ax.post('listbatch', { ...params })
  }

  getBatch(id) {
    return ax.get(`batch/${id}`)
  }

  addBatch(payload) {
    return ax.post(`batch`, payload)
  }

  updateBatch(id, payload) {
    return ax.put(`batch/${id}`, payload)
  }

  removeBatch(id) {
    return ax.delete(`batch/${id}`)
  }
  
}
