
import { ax } from 'services/base'

export default class AgeGroupService {

  getAgegroupList(params) {
    return ax.post('listagegroup',{ ...params })
  }

  getAgegroup(id) {
    return ax.get(`agegroup/${id}`)
  }

  addAgegroup(payload) {
    return ax.post(`agegroup`, payload)
  }

  updateAgegroup(id, payload) {
    return ax.put(`agegroup/${id}`, payload)
  }

  removeAgegroup(id) {
    return ax.delete(`agegroup/${id}`)
  }

}
