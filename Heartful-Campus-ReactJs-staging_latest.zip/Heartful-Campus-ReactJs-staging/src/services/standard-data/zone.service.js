
import { axSRCMGatsby } from 'services/base';

export default class ZoneService {

  getZoneList() {
    return new Promise((resolve, reject) => {
      axSRCMGatsby.get('groups/zone/all.json')
        .then(response => {
          let resposeData = {
            data: {
              count: 0,
              data: [],
              isError: true
            }
          }

          if (response && response.data) {
            resposeData = {
              ...response,
              data: {
                count: response.data.count || 0,
                data: response.data.results ? response.data.results.map(zone => {
                  return {
                    ...zone,
                    name: zone.name ? zone.name.trim() : zone.name,
                    complete_name: zone.complete_name ? zone.complete_name.trim() : zone.complete_name,
                  }
                }) : [],
                isError: false
              }
            }
          }

          resolve(resposeData)
        })
        .catch(err => { reject(err) });
    })
  }

}
