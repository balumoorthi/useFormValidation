
import { ax } from 'services/base'

export default class LanguageService {

  getLanguageList(params) {
    return ax.post('listlanguage',{ ...params })
  }

  getLanguage(id) {
    return ax.get(`language/${id}`)
  }

  addLanguage(payload) {
    return ax.post(`language`, payload)
  }

  updateLanguage(id, payload) {
    return ax.put(`language/${id}`, payload)
  }

  removeLanguage(id) {
    return ax.delete(`language/${id}`)
  }
  

}
