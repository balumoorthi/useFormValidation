
import { ax } from 'services/base'

export default class ProgramService {

  getProgramList(params) {
    return ax.post('listprogramtype',{ ...params })
  }

  getProgram(id) {
    return ax.get(`programtype/${id}`)
  }

  addProgram(payload) {
    return ax.post(`programtype`, payload)
  }

  updateProgram(id, payload) {
    return ax.put(`programtype/${id}`, payload)
  }

  removeProgram(id) {
    return ax.delete(`programtype/${id}`)
  }

}
