import { ax } from 'services/base';

const config = { headers: { 'content-type': 'multipart/form-data' } }

export default class ModuleService {

  getModuleList(payload) {
    return ax.post('module-list', payload)
  }

  getModule(id) {
    return ax.get(`module/${id}`)
  }

  getModuleByUnit(payload) {
    return ax.post(`listunitmodules/`,payload)
  }

  addModule(payload) {
    return ax.post(`module`, payload)
  }

  updateModule(id, payload) {
    return ax.put(`module/${id}`, payload)
  }

  removeModule(id) {
    return ax.delete(`module/${id}`)
  }

  addAttachment(payload) {
    return ax.post(`modules/postdocuments`, payload, config)
  }

  listAttachments(id) {
    return ax.get(`modules/listdocuments/${id}`)
  }

  removeAttachment(id) {
    return ax.delete(`modules/deletedocuments/${id}`)
  }
}
