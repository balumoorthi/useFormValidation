// redux store
import appStore from 'store/index';

// redux store action types
import { CARTPAGEVISIBILITY, UPDATECARTDETAILS, CARTITEM } from "store/actions/type/cart";

export const toggleCartPage = toggle => {
  appStore.dispatch({ type: CARTPAGEVISIBILITY, payload: toggle });
};

export const updateCart = cartDetails => {
  appStore.dispatch({ type: UPDATECARTDETAILS, payload: cartDetails });
};

export const setCart = cart => {
  if (cart && Array.isArray(cart.modules) && Array.isArray(cart.units))
    appStore.dispatch({ type: CARTITEM, payload: { modules: cart.modules, units: cart.units, isSavedCart: true } });
};

export const addModule = module => {
  const cartModules = appStore.getState().cartDetails.cart.modules;
  let unitModules = [];

  if (Array.isArray(module.unitmodules) && (module.unitmodules.length > 0))
    unitModules = module.unitmodules.map(unit => { module.unit_id = unit.unit_id; return module; });
  else
    unitModules = [module];

  appStore.dispatch({
    type: CARTITEM,
    payload: {
      modules: cartModules.concat(unitModules),
      isSavedCart: false
    }
  });
};

export const removeModule = module => {
  const cartModules = appStore.getState().cartDetails.cart.modules;

  appStore.dispatch({
    type: CARTITEM,
    payload: {
      modules: cartModules.filter(cartModule => cartModule.module_id !== module.module_id),
      isSavedCart: false
    }
  });
};

export const addUnit = (unit, modules) => {
  const cartModules = appStore.getState().cartDetails.cart.modules;
  const cartUnits = appStore.getState().cartDetails.cart.units;
  let unitModules = [];

  unitModules = modules.filter(module => {
    return !cartModules.find(cartModule => ((cartModule.module_id === module.module_id) && (cartModule.unit_id === module.unit_id)))
  }).map(module => {
    module.unit_name = unit.unit_name;
    return module;
  })

  appStore.dispatch({
    type: CARTITEM,
    payload: {
      modules: cartModules.concat(unitModules),
      units: cartUnits.concat([unit]),
      isSavedCart: false
    }
  });
};

export const removeUnit = unit => {
  const cartModules = appStore.getState().cartDetails.cart.modules;
  const cartUnits = appStore.getState().cartDetails.cart.units;

  return appStore.dispatch({
    type: CARTITEM,
    payload: {
      modules: cartModules.filter(cartModule => cartModule.unit_id !== unit.unit_id),
      units: cartUnits.filter(cartUnit => cartUnit.unit_id !== unit.unit_id),
      isSavedCart: false
    }
  });
};

export const clearCart = () => {
  appStore.dispatch({ type: CARTITEM, payload: { modules: [], units: [] } });
};

export const setSavedCart = (isSavedCart = true) => {
  appStore.dispatch({ type: CARTITEM, payload: { isSavedCart: isSavedCart } });
};