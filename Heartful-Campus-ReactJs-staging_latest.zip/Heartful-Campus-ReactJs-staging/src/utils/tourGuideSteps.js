// redux store
import appStore from 'store/index';

import { TOURGUIDE } from "store/actions/type/app";

const tourGuideSteps = (props, toursteps) => {
  let tourGuidance = localStorage.getItem('tourGuidance');
  if(tourGuidance === '0')
    appStore.dispatch({ type: TOURGUIDE, payload: toursteps })
};

export default tourGuideSteps;