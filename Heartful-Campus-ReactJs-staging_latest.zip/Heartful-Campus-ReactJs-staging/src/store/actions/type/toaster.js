export const SUCCESS       = 'SUCCESS'     ;
export const INFO          = 'INFO'        ;
export const WARN          = 'WARN'        ;
export const ERROR         = 'ERROR'       ;
export const CUSTOM        = 'CUSTOM'      ;
export const REQUESTERROR  = 'REQUESTERROR';
export const SETTOASTERREF = 'SETTOASTERREF';