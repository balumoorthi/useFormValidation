export const TOGGLE = 'CDTOGGLE';
export const ACCEPT = 'CDACCEPT';
export const REJECT = 'CDREJECT';
export const ONHIDE = 'CDONHIDE';
export const CUSTOM = 'CDCUSTOM';