export const TOGGLE = 'GPTOGGLE';
export const LINKCOPY = 'GP_ON_LINK_COPY';
export const ATTACHCOPY = 'GP_ON_ATTACHMENT_COPY';
export const HIDE = 'GP_ON_HIDE';
export const CUSTOM = 'GPCUSTOM';