export const LOGIN  = 'LOGIN';
export const SIGNUP = 'SIGNUP';
export const LOGOUT = 'LOGOUT';
export const SHOWLOGIN = 'SHOW_LOGIN';