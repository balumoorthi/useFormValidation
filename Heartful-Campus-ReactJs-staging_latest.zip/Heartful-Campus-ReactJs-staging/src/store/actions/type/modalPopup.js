export const TOGGLE = 'MPTOGGLE';
export const ONHIDE = 'MPONHIDE';
export const ONSHOW = 'MPONSHOW';
export const CUSTOM = 'MPCUSTOM';