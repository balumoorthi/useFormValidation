import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { statusBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { createdDateBadge, gotoPage } from "utils/badgeTemplate";

import { bulk } from "utils/bulk";

import { getUserName, getModuleAccess, getUser, getUserID, getUserRole } from "utils/common";

// components
import CollegeForm from 'components/college/listing/collegeForm';

// prime components 
import { Tooltip } from "primereact/tooltip";

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import collegeService from 'services/college/college.service';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class CollegeListing extends Component {

  constructor(props) {

    super(props);

    //variable init starts
    this.collegeService = new collegeService();

    this.collegeTable = React.createRef(null);

    this.collegeFormInitValue = {
      label: null,
      email_address: null,
      address: null,
      city: null,
      state: null,
      country: null,
      status_id: null,
      zone_id: null,
      college_type_id: null,
    }

    const moduleAccess = getModuleAccess("COLLEGE") || {};
    const enableViewLink = Array.isArray(moduleAccess.access) ? moduleAccess.access.includes("view") : false;
    //variable init end

    localStorage.setItem('moduleName', 'college');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['college'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      collegeForm: {
        isEditable: false,
        initValue: this.collegeFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "College", url: "college", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("COLLEGE"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
          rowClassName: rowData => {
            return {
              'college-mou-signed': rowData.upload_documents ? true : false
            }
          }
        },

        url: this.collegeService,

        method: 'getCollegeList',

        params: {
          manage_state: (getUser().role_slug === 'state-coordinator') ? getUser().state : undefined,
          manage_zone: (getUser().role_slug === 'zone-coordinator') ? getUser().zone : undefined,
          poc_id: (getUser().type === 'POC') ? getUserID() : undefined,
          role: getUser() ? getUser().role_slug : undefined
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1,
        },

        columns: [
          {
            header: 'College',
            field: 'label',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
            body: enableViewLink ? (rowData, { field }) => { return gotoPage(rowData, field, this.gotoCollegeDetails) } : null
          },
          {
            header: 'Email',
            field: 'email_address',
            sortable: true,
            filter: true,
            title: true,
            headerStyle: {
              width: '200px'
            },
            transformValue: false
          },
          {
            header: 'Address',
            field: 'address',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: this.statusHeaderTemplate(),
            field: 'status_id',
            sortable: true,
            filter: true,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "collegeStatus"
            },
            body: statusBadge,
            headerStyle: {
              width: '120px'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-mr-2 p-button-icon-only",
            title: 'View College',
            onClick: this.gotoCollegeDetails
          },
          {
            type: 'update',
            icon: "uil uil-pen edit-icon",
            className: "p-mr-2 addCollege",
            title: 'Edit College',
            onClick: this.editCollege
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            title: 'Delete College',
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this college?",
                accept: () => { this.removeCollege(rowdata.college_id) }
              })
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'College List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "You are about to mass update the status of colleges?",
                  accept: () => { this.bulkStatusUpdate(selections, status) }
                });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "Are you sure you want to delete these colleges? This may affect other screens",
                  accept: () => { this.bulkDelete(selections) }
                });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setcollegeFormInitValue, classNames:"collegeList" }
          ]
        },
        enableSelection: true,
      },

      // datatables 

    }
  }

  statusHeaderTemplate() {
    return <><i className="pi pi-info-circle p-dt-tooltip" data-pr-position="top" /> Status</>;
  }

  // bulk Status update section starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "College",
        name: "college_id",
        value: selections.map(value => { return value.college_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.collegeTable,
    })
  }
  // bulk Status update section end

  // bulk Delete section starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "College",
        name: "college_id",
        value: selections.map(value => { return value.college_id }),
        deleted_by: getUserName()
      },
      dataTable: this.collegeTable,
    })
  }
  // bulk delete section end
  setcollegeFormInitValue = () => {
    this.setState({
      collegeForm: {
        ...this.state.collegeForm,
        initValue: this.collegeFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'ADD College' })
      })
  }
  //Edit college section starts
  editCollege = (ev, rowdata) => {
    this.setState({
      collegeForm: {
        ...this.state.collegeForm,
        initValue: {
          college_id: rowdata.college_id,
          label: rowdata.label,
          email_address: rowdata.email_address,
          address: rowdata.address,
          city: rowdata.city,
          state: rowdata.state,
          country: rowdata.country ? rowdata.country.country_id : null,
          status_id: rowdata.status.status_id,
          zone_id: rowdata.zone_id,
          college_type_id: rowdata.discipline ? rowdata.discipline.discipline_id : null,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'UPDATE College' })
      })
  }
  //Edit college section end

  //Remove college section starts
  removeCollege = async (id) => {
    await response.remove({
      service: this.collegeService,
      method: 'removeCollege',
      data: { itemId: id },
      dataTable: this.collegeTable,
    })
  }
  //Remove college section end

  gotoCollegeDetails = (ev, rowData) => {
    this.props.history.push(`/college/details/${rowData.college_id}`);
  }

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.country();
    dropdown.zone();
    dropdown.generalStatus();
    dropdown.collegeStatus()
  }

  render() {
    return (
      <div>
        <Tooltip target=".p-dt-tooltip" mouseTrack mouseTrackTop={10}>
            <p>Dormant - College is not active for more than 45 days.<br></br>Hibernate - College is not active for more than 60 days.<br></br>Planning - College is planning to create cart items.<br></br>MOU- Green Highlighted Rows are MOU Uploaded Colleges.<br></br>Approached - Newly Added College.<br></br>Active - College is in Active State.</p>
        </Tooltip>
        <HFNDataTable ref={this.collegeTable} options={this.state.options} />
        <HFNModalPopup>
          <CollegeForm initialValue={this.state.collegeForm} dataTableRef={this.collegeTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(CollegeListing));