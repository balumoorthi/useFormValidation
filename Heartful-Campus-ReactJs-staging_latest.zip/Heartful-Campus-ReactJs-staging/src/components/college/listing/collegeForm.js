import React, { useEffect, useState } from "react";

import { useHistory } from "react-router-dom";

// utils 

import { validations } from 'utils/validations';

import { isEmpty, isObject } from 'lodash';

import { response } from "utils/response";

import { cityAutoCompleteTemplate, getUserName } from "utils/common";

import { dropdown } from "utils/dropdown";

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import CollegeService from 'services/college/college.service';

const CollegeForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const collegeService = new CollegeService()
  // variable init end

  // state management start

  // validations start

  const setCollegeName = (ev, setValue) => {
    if (ev && isObject(ev.value)) {
      setValue("label", ev.value.college_name, { shouldValidate: true, shouldDirty: true });
    }
  };

  const history = useHistory();

  const [collegeFormFields] = useState({
    collegeName: {
      properties: {
        type: 'AutoComplete',
        label: 'College Search',
        fieldWrapperClassNames: 'p-md-12',
        searchField: 'query',
        fieldLabel: 'college_name',
        service: collegeService,
        method: 'collegeLookUp',
        primeFieldProps: {
          onChange: setCollegeName
        },
        validations: {
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        }
      },
    },
    label: {
      properties: {
        type: 'InputText',
        label: 'College Name',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    email_address: {
      properties: {
        type: 'InputText',
        label: 'Email',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
          pattern: validations.email,
        }
      }
    },
    address: {
      properties: {
        type: 'InputTextarea',
        label: 'Address',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {}
      }
    },

    city: {
      properties: {
        type: 'CityAutoComplete',
        label: 'City',
        fieldWrapperClassNames: 'p-md-12',
        searchField: 'name',
        fieldLabel: 'name',
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        },
        stateField: {
          label: 'State',
          fieldName: 'state',
          fieldWrapperClassNames: 'p-md-12',
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required,
          }
        },
        countryField: {
          label: 'Country',
          fieldName: 'country',
          fieldWrapperClassNames: 'p-md-12',
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required,
          },
          dropdownOptions: "country"
        }
      },
    },

    zone_id: {
      properties: {
        type: 'SelectDropdown',
        label: 'Zone',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          isSearchable: true,
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "zone"

      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: 'generalStatus'
      }
    },
    college_type_id: {
      properties: {
        type: 'Dropdown',
        label: 'Discipline',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {

        },
        dropdownOptions: 'discipline'

      }
    },
  });
  // validations end

  // state management end

  // College form section start 

  // form submit section start

  const collegeFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    formData = getUserName(isEditable, formData)

    if (isEmpty(error)) {
      addUpdateCollege(formData)
    }
  }

  // form submit section end

  // add new and update college section start
  const addUpdateCollege = async (data) => {

    const formData = new FormData();

    Object.keys(data).forEach(key => {
      formData.append(key, data[key]);
    });

    if (isEditable) {
      formData.append("_method", "PUT");
    }

    if (!isEditable) {
      let apiResponse = await response.add({
        service: collegeService,
        method: 'addCollege',
        data: { item: formData }
      });
      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        const collegeID = apiResponse.data.data.college_id;
        if (collegeID)
          history.push(`/college/details/${collegeID}?action=reg`);
      }
    } else {
      await response.update({
        service: collegeService,
        method: 'updateCollege',
        data: { itemId: initValue.college_id, item: formData },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update college section end

  useEffect(() => {
    dropdown.discipline();
  }, [])

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={collegeFormFields} onFormSubmit={collegeFormOnsubmit} />
    </div>
  );
}

export default CollegeForm;
