import React, { Component } from 'react';

import { Switch, } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import CollegeListing from 'components/college/listing';

import CollegeDetails from 'components/college/collegeDetails';

import Cart from 'components/college/cart/';

import Checkout from 'components/college/cart/checkout';

import CollegeReport from 'components/college/reports';

import Participant from 'components/college/collegeDetails/program/participant';

import Session from 'components/college/collegeDetails/program/session';

// shared components 
import HFNLoader from 'shared-components/lazyLoading';

class College extends Component {
  render() {
    return (
      <div>
        <HFNLoader>
          <Switch>
            <AuthGuard path='/college/listing' component={CollegeListing} />
            <AuthGuard path='/college/reports' component={CollegeReport} />
            <AuthGuard exact path='/college/details/:id' component={CollegeDetails} />
            <AuthGuard path='/college/cart/checkout/:id' component={Checkout} />
            <AuthGuard path='/college/cart/:id' component={Cart} />
            <AuthGuard path='/college/:collegeID/program/:programID/session/:sessionID/participant' component={Participant} />
            <AuthGuard path='/college/:collegeID/program/:programID/session' component={Session} />
            <AuthGuard path='/college/listing' component={CollegeListing} />
            <AuthGuard path='/college/:id' component={CollegeDetails} />
          </Switch>
        </HFNLoader>
      </div>
    );
  }
}

export default College;

