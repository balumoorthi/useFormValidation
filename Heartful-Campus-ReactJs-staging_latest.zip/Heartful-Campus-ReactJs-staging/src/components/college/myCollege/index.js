import React, { Component } from 'react';

import { Switch, Route } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import MyCollege from 'components/college/myCollege/MyCollege';

import Cart from 'components/college/cart/';

import Checkout from 'components/college/cart/checkout';

import Session from 'components/college/collegeDetails/program/session';

import Participant from 'components/college/collegeDetails/program/participant';

// shared components 
import HFNLoader from 'shared-components/lazyLoading';

// utils
import { getUserRole } from 'utils/common';

import { modalPopup } from "utils/modalPopup";

import HFNModalPopup from 'shared-components/modalPopup';

import { Button } from 'primereact/button';

import Steps from 'shared-components/tourGuide/Steps';

import tourGuideSteps from 'utils/tourGuideSteps';

import { Cookies, withCookies } from "react-cookie";
import { instanceOf } from "prop-types";

class College extends Component {
  static propTypes = {
    cookies: instanceOf(Cookies).isRequired
  };
  constructor(props) {
    super (props);
    this.state = {
      tourGuidance : this.props.cookies.get("tourGuidance"),
      tourRequired : this.props.cookies.get("tourRequired"),
      joyDetails: { 
        run: true,
        steps: Steps[getUserRole()],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      }
    }
  }

  componentDidMount() {
    if(this.state.tourRequired === '') {
      this.setState(() => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Tour Guidance', className: 'sdm-popup' })
      })
    }
  }
  render() {
    const { cookies } = this.props;
    return (
      <div>
        <HFNLoader>
          <Switch>
            <AuthGuard path='/mycollege/cart/checkout' component={Checkout} />
            <AuthGuard path='/mycollege/cart' component={Cart} />
            <AuthGuard path='/mycollege/program/:programID/session/:sessionID/participant' component={Participant} />
            <AuthGuard path='/mycollege/program/:programID/session' component={Session} />
            <Route>
              {
                this.props.location.pathname === "/mycollege"
                  ?
                  <MyCollege />
                  :
                  <></>
              }
            </Route>
          </Switch>
        </HFNLoader>
        {(this.state.tourRequired === '') ?
        <HFNModalPopup>
          <div className="p-d-flex p-flex-wrap p-my-3">
            <div className="p-col-12 p-d-flex p-flex-wrap p-mx-5">
              <p style={{ height: '50px' }}>Would you like to go for Tour Guidance?</p>
            </div>
            <div className="form-button-group">
            <Button 
              type="button" 
              className='p-button p-button-primary p-mr-2' 
              label="Yes" 
              onClick={() => { 
                localStorage.setItem('tourGuidance', 0);
                localStorage.setItem('tourRequired', 'yes');
                cookies.set("tourRequired", "yes", { path: "/" }); // set the cookie
                cookies.set("tourGuidance", 0, { path: "/" }); // set the cookie
                tourGuideSteps(this.props,this.state.joyDetails);
                modalPopup.toggle(false)
              }} 
            />
            <Button 
              type="button" 
              className='p-button p-button-secondary p-mr-2' 
              label="No! I am good" 
              onClick={() => { 
                localStorage.setItem('tourGuidance', 1);
                localStorage.setItem('tourRequired', 'no');
                cookies.set("tourRequired", "no", { path: "/" }); // set the cookie
                cookies.set("tourGuidance", 1, { path: "/" }); // set the cookie
                modalPopup.toggle(false) }}
            />
            </div>
          </div>
        </HFNModalPopup>
        :""}
      </div>
    );
  }
}

export default withCookies(College);