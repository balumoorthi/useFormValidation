import React, { Component } from 'react';

import { withRouter } from 'react-router';

// state
import { connect } from "react-redux";

// components
import POC from 'components/college/collegeDetails/poc';

import Staff from 'components/college/collegeDetails/staff';

import MOU from 'components/college/collegeDetails/mou/MOUForm';

import Program from 'components/college/collegeDetails/program';

// prime components
import { Accordion, AccordionTab } from 'primereact/accordion';

import { TabView, TabPanel } from 'primereact/tabview';

import { Button } from 'primereact/button';

// utils
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { getCollegeID, getUserType } from 'utils/common';

import { toaster } from 'utils/toaster';

import { dropdown } from 'utils/dropdown';

// services
import CollegeService from "services/college/college.service";

class MyCollege extends Component {

  constructor(props) {

    super(props);

    // variables init start
    this.collegeService = new CollegeService();
    // variables init end
    const temptbreadcrumb = [
      { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
      { label: "My College", url: "mycollege", },
    ];
    if (getUserType() === "CS") {
      temptbreadcrumb.shift();
    }

    // state management start
    this.state = {
      collegeInfo: null,

      breadcrumbs: temptbreadcrumb,

      collegeID: getCollegeID()
    }
    // state management end

  }

  // get college information start
  getCollegeDetail = async () => {
    try {
      if (this.state.collegeID) {
        const apiResponse = await response.get({
          service: this.collegeService,
          method: 'getCollege',
          data: { itemId: this.state.collegeID }
        });

        if (apiResponse && apiResponse.data) {
          const apiResponseData = apiResponse.data;

          if (!apiResponseData.isError) {
            if (apiResponseData.data) {
              this.setState({ collegeInfo: apiResponseData.data })
            }
          } else {
            toaster.error(apiResponseData.message || "Error in fetching college information")
          }
        }
      }
    } catch (err) {
      console.log(err)
    }
  }
  // get college information end

  gotoCartPage = () => {
    this.props.history.push(`/mycollege/cart`);
  }

  componentDidMount = () => {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.programStatus();
    this.getCollegeDetail();
    dropdown.zone();
  }

  render() {
    // state and props destructure start
    const { label, address, city, state, country, zone_id, status, discipline, upload_documents } = { ...this.state.collegeInfo };
    const zone = this.props.zones.find(value => value.value === zone_id);
    // state and props destructure end

    return (
      <>
        <div className='p-card college-details p-mt-4'>

          <Accordion activeIndex={null} >
            <AccordionTab header="College Details">

              <div className="p-d-flex p-flex-wrap">

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Name</b>
                  </p>
                  <span>{label}</span>
                </div>
                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Discipline</b>
                  </p>
                  <span>{discipline ? discipline.discipline_name : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Country</b>
                  </p>
                  <span>{country ? country.country_name : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Address</b>
                  </p>
                  <span>{address ? address : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>City</b>
                  </p>
                  <span>{city ? city : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>State</b>
                  </p>
                  <span>{state ? state : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Zone</b>
                  </p>
                  <span>{(zone && zone.label) ? zone.label : '-'}</span>
                </div>
                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Status</b>
                  </p>
                  <span>{status ? status.status_name : '-'}</span>
                </div>
                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>MOU Signed</b>
                  </p>
                  <span>{upload_documents !== null ? 'Yes' : 'No'}</span>
                </div>

              </div>

            </AccordionTab>
          </Accordion>

        </div>

        <div className="p-card p-my-3 p-p-4">
          <div className="p-d-flex p-jc-between p-ai-center">
            {
              (this.state.collegeInfo && this.state.collegeInfo.draft_status)
                ?
                <div className="p-my-2">Please finalize the cart in draft before creating a new cart</div>
                :
                <></>
            }
            <div className="college-create-program">
              <Button
                className="p-button p-button-primary programCreation"
                style={{ minWidth: '125px', marginLeft: "10px" }}
                label="Create Program"
                disabled={!this.state.collegeInfo || (this.state.collegeInfo && this.state.collegeInfo.draft_status === true) ? true : false}
                onClick={() => { this.gotoCartPage() }}
              />
            </div>

          </div>
        </div>

        <div className='tab-section'>

          <TabView>
            <TabPanel header="Programs">
              <Program collegeID={this.state.collegeID} />
            </TabPanel>
            <TabPanel header="POC">
              <POC collegeID={this.state.collegeID} />
            </TabPanel>
            <TabPanel header="Staffs">
              <Staff collegeID={this.state.collegeID} />
            </TabPanel>
            <TabPanel header="MOU / Permission letters">
              <MOU collegeID={this.state.collegeID} collegeInfo={this.state.collegeInfo} />
            </TabPanel>
          </TabView>
        </div>
      </>
    )
  }
}

const mapStateToProps = (state) => ({
  zones: state.dropdownDetails.zone,
});

export default withRouter(connect(mapStateToProps)(MyCollege));