import React, { Component } from 'react';

// components
// shared-components
import ReportForm from 'shared-components/report';

// utils
import buildBreadcrumb from 'utils/breadcrumb';

import { dropdown } from 'utils/dropdown';

// services
import CollegeService from 'services/college/college.service';

import AutoCompleteService from 'services/autoComplete/autoComplete.service';

class CollegeReport extends Component {
  constructor(props) {

    super(props);

    // variable init start
    this.collegeService = new CollegeService();

    this.autoCompleteService = new AutoCompleteService();
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: 'Dashboard', url: 'dashboard', icon: 'pi pi-home' },
        { label: 'College Report', url: 'reports' },
      ],

      initialValues: {},

      options: {
        title: 'College Report',

        service: this.collegeService,

        method: 'collegereport',

        rows: 1000,

        timestampSuffix: 'DDMMYYYY',

        fileName: 'College_Report',

        columns: [
          {
            label: 'College Name',
            key: 'label',
          },
          {
            label: 'Email Address',
            key: 'email_address',
          },
          {
            label: 'Address',
            key: 'address',
          },
          {
            label: 'City',
            key: 'city',
          },
          {
            label: 'State',
            key: 'state',
          },
          {
            label: 'Country',
            key: 'country_name',
          },
          {
            label: 'Status',
            key: 'status_name',
          },
        ],
      },

      formFields: {

        label: {
          properties: {
            type: 'AutoComplete',
            label: 'College Name',
            fieldWrapperClassNames: 'p-md-3',
            searchField: 'college_name',
            fieldLabel: 'label',
            service: this.autoCompleteService,
            method: 'getCollegeSearchList',
            validations: {
              minLength: {
                value: 3,
                message: 'Search value must be minimum 3 character...',
              },
            },
          },
        },

        from_date: {
          properties: {
            type: 'Calendar',
            label: 'Registered From',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              maxDate: new Date(),
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          },
        },

        to_date: {
          properties: {
            type: 'Calendar',
            label: 'Registered To',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              maxDate: new Date(),
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          },
        },

        city: {
          properties: {
            type: 'InputText',
            label: 'City',
            fieldWrapperClassNames: 'p-md-3',
            validations: {
              maxLength: {
                value: 120,
                message: 'Please enter city with maximum 120 characters',
              },
            },
          },
        },

        state: {
          properties: {
            type: 'InputText',
            label: 'State',
            fieldWrapperClassNames: 'p-md-3',
            validations: {
              maxLength: {
                value: 120,
                message: 'Please enter state with maximum 120 characters',
              },
            },
          },
        },

        country: {
          properties: {
            type: 'Dropdown',
            label: 'Country',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: 'country',
          },
        },

        zone_id: {
          properties: {
            type: 'SelectDropdown',
            label: 'Zone',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { isSearchable: true, isClearable: true },
            dropdownOptions: 'zone',
          },
        },

        status_id: {
          properties: {
            type: 'Dropdown',
            label: 'Status',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: 'collegeStatus',
          },
        },

      },
    };
    // state management end
  }

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.collegeStatus();
    dropdown.country();
    dropdown.zone();
  }

  render() {
    return (
      <div>
        <ReportForm fields={this.state.formFields} initialValues={this.state.initialValues} options={this.state.options} />
      </div>
    );
  }
}

export default CollegeReport;
