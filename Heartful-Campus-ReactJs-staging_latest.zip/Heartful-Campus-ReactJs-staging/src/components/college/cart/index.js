import React, { Component } from 'react';

// state
import { connect } from "react-redux";

// components 
import ModulesCart from 'components/college/cart/modulesCart';

import UnitsCart from 'components/college/cart/unitsCart';

import CartForm from 'components/college/cart/cartForm';

// prime components
import { RadioButton } from 'primereact/radiobutton';

import { Button } from 'primereact/button';

// shared components 
import HFNLoader from 'shared-components/lazyLoading/Loading';

import HFNModalPopup from 'shared-components/modalPopup';

// utils 
import { modalPopup } from "utils/modalPopup";

import { response } from 'utils/response';

import { toggleCartPage, updateCart, setCart, clearCart, setSavedCart } from 'utils/cart';

import { getUserType, getCollegeID } from 'utils/common';

import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from 'utils/dropdown';

import { getUserName } from "utils/common";

// services 
import CollegeCartService from 'services/college/cart.service';

class Cart extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.moduleTable = React.createRef(null);
    this.cartService = new CollegeCartService();
    this.userType = getUserType();
    this.cartFormInitValue = {
      cart_name: null,
      college_id: (this.userType === "CS") ? getCollegeID() : this.props.match.params.id,
      created_by: getUserName(),
      status_id: 1
    }
    // variable init end

    // state management start
    this.state = {

      loader: false,

      userType: this.userType,

      showMessage: this.props.location.search === '?status=saved' ? true : false,

      collegeID: (getUserType() === "CS") ? getCollegeID() : this.props.match.params.id,

      breadcrumbs: (this.userType === "CS")
        ?
        [
          { label: "My College", url: "mycollege", },
          { label: "Cart", url: "mycollege/cart", },
        ]
        :
        [
          { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
          { label: "College List", url: "college/listing", },
          { label: "College", url: `college/details/${this.props.match.params.id}`, },
          { label: "Cart", url: `college/cart/${this.props.match.params.id}`, },
        ],

      shownTable: "A"

    }
    // state management end
  }

  // check cart existance and check existing cart data section start
  checkCollegeCart = async () => {
    try {
      let getCartItems, cartItems = [], cartResponse, cartResponseData = [];

      cartResponse = await response.getList({
        service: this.cartService,
        method: "getCollegeStatus",
        params: { college_id: this.state.collegeID }
      });

      if (cartResponse && cartResponse.data && !cartResponse.data.isError && cartResponse.data.data) {
        cartResponseData = cartResponse.data.data
      }

      if (cartResponseData && cartResponseData.cart_details && cartResponseData.cart_details.status_id && cartResponseData.cart_details.status_id === 1) {

        toggleCartPage(true);

        updateCart({
          cart_id: cartResponseData.cart_details.cart_id,
          cart_name: cartResponseData.cart_details.cart_name,
          college_id: cartResponseData.cart_details.college_id,
        });

        if (cartResponseData.items[0]) {
          getCartItems = cartResponseData.items[0].cart_details;
          cartItems = JSON.parse(getCartItems);
          setCart(cartItems);
        }

      } else {
        toggleCartPage(false);
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Create Program', className: 'sdm-popup' })
      }

    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // check cart existance and check existing cart data section end

  // go to college section start
  gotoCollege = async () => {
    if (getUserType() === "CS")
      this.props.history.push(`/mycollege`);
    else
      this.props.history.push(`/college/details/${this.state.collegeID}`);
  }
  // go to college section end

  // save cart section start
  saveCart = async () => {
    try {
      let cartData = {
        cart_id: this.props.cd.cartDetails.cart_id,
        cart_name: this.props.cd.cartDetails.cart_name,
        items: { modules: this.props.cd.cart.modules, units: this.props.cd.cart.units },
        status_id: 1,
        college_id: this.state.collegeID
      };
      cartData = getUserName(false, cartData);

      let apiResponse = await response.add({
        service: this.cartService,
        method: 'addCartItem',
        data: { item: cartData },
        toasterMessage: {
          success: 'Items saved to cart successfully',
          error: 'Items not saved to cart',
        },
        modalPopupHide: false
      });

      if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
        setSavedCart()
      }

      if (getUserType() === "CS")
        this.props.history.push(`/mycollege/cart?status=saved`);
      else
        this.props.history.push(`/college/cart/${this.state.collegeID}?status=saved`);
      this.checkCollegeCart();
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // save cart section end

  // cancel cart section start
  cancelCart = async () => {
    try {
      const { cartDetails } = this.props.cd;

      if (cartDetails && cartDetails.cart_id) {
        const payload = { cart_id: cartDetails.cart_id };

        let apiResponse = await response.add({
          service: this.cartService,
          method: 'cancelCart',
          data: { item: payload },
          toasterMessage: {
            success: 'Cart cancelled successfully',
            error: 'Unable to cancel cart'
          }
        });

        if (apiResponse && apiResponse.data && !apiResponse.data.isError) {

          if (this.state.userType === "CS") {
            this.props.history.push(`/mycollege`);
          }
          else if (this.state.collegeID) {
            this.props.history.push(`/college/details/${this.state.collegeID}`);
          }

          clearCart();
        }
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // cancel cart section end

  // view checkout section start
  gotoCheckout = () => {
    modalPopup.toggle(false);

    if (this.state.userType === "CS")
      this.props.history.push(`/mycollege/cart/checkout`);
    else
      this.props.history.push(`/college/cart/checkout/${this.state.collegeID}`);
  }
  // view checkout section end

  // page reload confirm section start
  pageReloadConfirm = (event) => {
    event.preventDefault();
    return event.returnValue = "Changes you made may not be saved.";
  }
  // page reload confirm section end

  // set loader state section start
  setLoader = loader => {
    this.setState({ loader: loader });
  }
  // set loader state section end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.discipline();
    dropdown.programType();
    dropdown.level();
    dropdown.durationTiming();

    const { modules, units } = this.props.cd.cart;
    let cartLength = modules.length + units.length;

    if (this.state.userType === "CS") {
      if (cartLength === 0) {
        this.checkCollegeCart();
      }
    }
    else
      this.checkCollegeCart();

    window.addEventListener("beforeunload", this.pageReloadConfirm, { capture: true });
  }

  componentWillUnmount() {
    window.removeEventListener("beforeunload", this.pageReloadConfirm, { capture: true });
  }

  render() {
    const { modules, isSavedCart } = this.props.cd.cart;
    const { cart_name } = this.props.cd.cartDetails;

    return (

      <div>
        {(this.state.loader === true) ? <HFNLoader /> : <></>}

        {
          (this.state.showMessage === true)
            ?
            <h4 className="cart-success p-mb-2"> Your cart has been successfully saved please proceed with checkout </h4>
            :
            <></>
        }

        {
          (this.props.cpv)
            ?
            <div>
              {
                cart_name
                  ?
                  <div className="p-toolbar">
                    <div className="p-toolbar-group-left">
                      <div className="datatable-title p-mb-2">
                        <h4> {cart_name} </h4>
                      </div>
                    </div>
                  </div>
                  :
                  <></>
              }

              <div className="p-cart-table-section">

                <div className="p-card p-mb-3">
                  <div className="p-d-flex p-jc-between p-flex-wrap p-px-3 p-pt-3">
                    <div className="p-pb-3">
                      <Button className="p-button p-button-primary p-pl-3" icon="pi pi-arrow-circle-left" onClick={this.gotoCollege} label="Back to College" />
                    </div>
                    <div className="p-d-flex p-jc-end p-flex-wrap p-pb-3">
                      {
                        ((modules.length > 0) && isSavedCart)
                          ?
                          <button className="p-button p-button-primary p-mr-3" onClick={this.gotoCheckout} > Checkout </button>
                          :
                          <></>
                      }
                      <button className="p-button p-button-danger p-mr-3" onClick={this.cancelCart} > Cancel Cart </button>
                      <button className="p-button p-button-success" onClick={this.saveCart} > Save Cart </button>
                    </div>
                  </div>
                </div>

                <div className="p-d-flex p-flex-wap p-jc-end p-mb-1">
                  <div className="p-field-radiobutton p-mb-0 p-mr-3">
                    <RadioButton inputId="A" name="All" value="A" onChange={(e) => this.setState({ shownTable: e.value })} checked={this.state.shownTable === 'A'} />
                    <label htmlFor="A">All</label>
                  </div>
                  <div className="p-field-radiobutton p-mb-0 p-mr-3">
                    <RadioButton inputId="M" name="Modules" value="M" onChange={(e) => this.setState({ shownTable: e.value })} checked={this.state.shownTable === 'M'} />
                    <label htmlFor="M">Modules</label>
                  </div>
                  <div className="p-field-radiobutton p-mb-0">
                    <RadioButton inputId="U" name="Units" value="U" onChange={(e) => this.setState({ shownTable: e.value })} checked={this.state.shownTable === 'U'} />
                    <label htmlFor="U">Units</label>
                  </div>
                </div>

                {
                  ((this.state.shownTable === "A") || (this.state.shownTable === "M"))
                    ?
                    <div className="p-mb-4">
                      <div className="p-toolbar">
                        <div className="p-toolbar-group-left">
                          <div className="datatable-title">
                            <h4>Modules Offered</h4>
                          </div>
                        </div>
                      </div>
                      <ModulesCart ref={this.moduleTable} collegeID={this.state.collegeID} />
                    </div>
                    :
                    <></>
                }

                {
                  ((this.state.shownTable === "A") || (this.state.shownTable === "U"))
                    ?
                    <div className="p-mb-4">
                      <div className="p-toolbar">
                        <div className="p-toolbar-group-left">
                          <div className="datatable-title">
                            <h4>Units Offered</h4>
                          </div>
                        </div>
                      </div>
                      <UnitsCart moduleTable={this.moduleTable} setLoader={this.setLoader} />
                    </div>
                    :
                    <></>
                }

                <div className="p-card p-mt-4">
                  <div className="p-d-flex p-jc-end p-p-3">
                    {
                      ((modules.length > 0) && isSavedCart)
                        ?
                        <button className="p-button p-button-primary p-mr-3" onClick={this.gotoCheckout} > Checkout </button>
                        :
                        <></>
                    }
                    <button className="p-button p-button-danger p-mr-3" onClick={this.cancelCart} > Cancel Cart </button>
                    <button className="p-button p-button-success" onClick={this.saveCart} > Save Cart </button>
                  </div>
                </div>
              </div>
            </div>
            :
            <HFNModalPopup>
              <CartForm initialValue={this.cartFormInitValue} />
            </HFNModalPopup>
        }

      </div>

    );
  }
}

const mapStateToProps = (state) => ({
  cd: state.cartDetails,
  cpv: state.cartDetails.cartPageVisibility,
});

export default connect(mapStateToProps)(Cart);
