import React, { Component } from 'react';

// state 
import { connect } from "react-redux";

// components 
import UnitModuleListing from 'components/college/cart/unitModuleListing';

// primereact components 
import { DataTable } from 'primereact/datatable';

import { Column } from 'primereact/column';

import { confirmDialog } from 'primereact/confirmdialog';

import { ToggleButton } from 'primereact/togglebutton';

import { Dialog } from 'primereact/dialog';

// shared component 
import HFNDataTablePagination from 'shared-components/datatable/HFNDataTablePagination';

// utils 
import { addUnit, removeUnit } from 'utils/cart';

// services 
import UnitService from 'services/standard-data/unit.service';

import ModuleService from 'services/module/module.service';

export class UnitsCart extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.ModuleService = new ModuleService();

    this.UnitService = new UnitService();
    // variable init end

    // state management start
    this.state = {

      loading: false,

      totalRecords: 0,

      units: null,

      lazyParams: {
        first: 0,
        rows: 5,
        page: 1,
        filters: {
          status_id: { "value": 1, "matchMode": "startsWith" }
        }
      },

      pagination: {

        prevPageLink: {
          isPrevPageLink: true,
          classNames: ''
        },

        nextPageLink: {
          isNextPageLink: true,
          classNames: ''
        },

        pageLinks: {
          isPageLinks: true,
          classNames: ''
        },

        rowsPerPageDropdown: {
          isRowPerPage: true,
          dropdownOptions: [
            { label: 5, value: 5 },
            { label: 10, value: 10 },
            { label: 20, value: 20 },
            { label: 50, value: 50 },
          ],
          classNames: ''
        },

        currentPageReport: {
          isPageResult: true,
          isPageNavigator: false,
          classNames: ''
        }

      },

      unitID: null,

      unitName: null,

      unitModulesPopup: false

    };
    // state management end

  }

  // datatable methods start 
  loadLazyData = async () => {
    this.setState({ loading: true });

    try {
      let apiResponse = await this.UnitService.getUnitList({ lazyEvent: this.state.lazyParams })

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && Array.isArray(apiResponse.data.data)) {
        this.setState({
          totalRecords: apiResponse.data.count,
          units: apiResponse.data.data,
          loading: false
        }, () => {
          this.setCartItem();
        });
      }
      else
        this.setState({ loading: false });
    }
    catch {
      this.setState({ loading: false });
    }
  }

  onPage = (event) => {
    event.page = event.page + 1;
    let lazyParams = { ...this.state.lazyParams, ...event };
    this.setState({ lazyParams }, this.loadLazyData);
  }

  onSort = (event) => {
    if (event.sortField) {
      let lazyParams = { ...this.state.lazyParams, ...event };
      this.setState({ lazyParams }, this.loadLazyData);
    }
  }

  onFilter = (event) => {
    let lazyParams = { ...this.state.lazyParams, ...event };
    lazyParams['first'] = 0;
    this.setState({ lazyParams }, this.loadLazyData);
  }
  // datatable methods end

  // datatable templates section start
  // unit template section start
  unitTemplate = rowData => {
    return (
      <div className="info-section" title={rowData.unit_name}>
        <span className="info">{rowData.unit_name}</span>
        <span className="info-icon" onClick={() => { this.unitInfo(rowData) }} > <i className="uil uil-info-circle"></i> </span>
      </div>
    )
  }
  // unit template section end

  // show modules template section start
  showModulesTemplate = rowData => {
    return (
      <div className="show-modules-link">
        <p onClick={() => {
          this.setState({ unitName: rowData.unit_name, unitID: rowData.unit_id }, () => { this.toggleUnitModulesPopup() })
        }}
        >
          <u style={{ cursor: "pointer" }}>Show Modules for this Unit</u>
        </p>
      </div>
    )
  }
  // show modules template section end

  // action template section start
  actionTemplate = rowData => {
    return (
      <div className="cart-action-section">
        <ToggleButton
          className="cart-toogle-btn"
          onLabel="Remove Item"
          offLabel="Add Item"
          checked={this.state["u" + rowData.unit_id]}
          onChange={(e) => this.addCartItem(e, rowData)} />
      </div>
    );
  }
  // action template section end
  // datatable templates section end

  // unit info popup section start
  unitInfo = unitInfo => {
    confirmDialog({
      message: unitInfo.unit_desc,
      header: unitInfo.unit_name,
      className: 'module-confirm-popup mcp-desc'
    });
  }
  // unit info popup section end

  // unit modules popup section start
  toggleUnitModulesPopup = () => {
    this.setState({ unitModulesPopup: !this.state.unitModulesPopup })
  }
  // unit modules popup section end

  // add or remove unit to cart section start
  addCartItem = async (ev, unit) => {
    try {
      this.props.setLoader(true);
      if (ev.value) {
        let apiResponse = await this.ModuleService.getModuleByUnit({ unit_id: unit.unit_id })

        if (apiResponse && apiResponse.data && !apiResponse.data.isError && Array.isArray(apiResponse.data.data)) {
          await addUnit(unit, apiResponse.data.data);
        }
        else {
          this.props.setLoader(false);
          return;
        }
      }
      else
        await removeUnit(unit);

      this.setState({ ["u" + unit.unit_id]: ev.value });
      if (this.props.moduleTable && this.props.moduleTable.current)
        this.props.moduleTable.current.setCartItem();
      this.props.setLoader(false);
    }
    catch {
      console.log("Something went wrong.");
      this.props.setLoader(false);
    }
  }
  // add or remove unit to cart section end

  // set unit selection state in table section start
  setCartItem = () => {
    if (this.props.cd.cart && this.props.cd.cart.units) {
      this.props.cd.cart.units.forEach(unit => {
        if (unit.unit_id)
          this.setState({ ["u" + unit.unit_id]: true })
      });
    }
  }
  // set unit selection state in table section end

  componentDidMount() {
    this.loadLazyData();
  }

  render() {
    return (
      <div>
        <div className="hfn-datatable hfn-datatable-lazy">

          <DataTable
            ref={(el) => this.dt = el}
            value={this.state.units}
            lazy
            paginator
            paginatorTemplate={HFNDataTablePagination(this.state.pagination)}
            first={this.state.lazyParams.first}
            rows={this.state.lazyParams.rows}
            totalRecords={this.state.totalRecords}
            onPage={this.onPage}
            onSort={this.onSort}
            sortField={this.state.lazyParams.sortField}
            sortOrder={this.state.lazyParams.sortOrder}
            onFilter={this.onFilter}
            filters={this.state.lazyParams.filters}
            loading={this.state.loading}
            autoLayout={true}
          >
            <Column field="unit_name" header="Unit" sortable filter body={this.unitTemplate} />
            <Column header="Show Modules" body={this.showModulesTemplate} />
            <Column header="Action" body={this.actionTemplate} style={{ minWidth: "140px", width: '140px' }} />
          </DataTable>

          <Dialog header={this.state.unitName} visible={this.state.unitModulesPopup} onHide={this.toggleUnitModulesPopup} className={"cart-popup"}>
            <UnitModuleListing unitID={this.state.unitID} />
            <div className="p-text-right p-mt-3">
              <button className="p-button p-button-secondary" onClick={this.toggleUnitModulesPopup} > Cancel </button>
            </div>
          </Dialog>

        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  cd: state.cartDetails,
});

export default connect(mapStateToProps)(UnitsCart);
