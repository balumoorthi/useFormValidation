import React, { useState } from "react";

import { useHistory } from "react-router";

import { useParams } from "react-router-dom";

// components
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// prime components 
import { Button } from 'primereact/button';

// utils 
import { isEmpty } from 'lodash';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getUserType, randomText } from 'utils/common';

import { toggleCartPage, updateCart } from "utils/cart";

import { modalPopup } from "utils/modalPopup";

// services 
import CollegeCartService from 'services/college/cart.service';

const CartForm = (props) => {
  const history = useHistory();

  const params = useParams();

  // props destructure start
  const { initialValue } = props;
  // props destructure end

  // variable init start 
  const collegeCartService = new CollegeCartService();
  // variable init end

  // state management start
  const [initValue] = useState(initialValue)

  let discipline, level, cartMasterName;

  // validations start
  const [cartFormFields] = useState({
    discipline_id: {
      properties: {
        type: 'Dropdown',
        label: 'Discipline',
        primeFieldProps: {
          onChange: (ev, setValue) => {
            let disciplineName = ev.originalEvent.target.ariaLabel;
            disciplineName = disciplineName.split(' ');
            if(disciplineName.length > 1)
              disciplineName = disciplineName.map( item => item.toUpperCase().substring(0, 1)).join('');
            else
              disciplineName = disciplineName.map( item => item.toUpperCase().substring(0, 2)).join('');
            discipline = disciplineName;
            setValue("cart_name", '');
            setValue("cart_master_id", '');
          }
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "discipline"
      }
    },
    level_id: {
      properties: {
        type: 'Dropdown',
        label: 'Level',
        primeFieldProps: {
          onChange: (ev, setValue) => {
            let levelName = ev.originalEvent.target.ariaLabel;
            levelName = levelName.split(' ');
            if(levelName.length > 1)
              levelName = levelName.map( item => item.toUpperCase().substring(0, 1)).join('');
            else
              levelName = levelName.map( item => item.toUpperCase().substring(0, 2)).join('');
            level = levelName;
            setValue("cart_name", '');
            setValue("cart_master_id", '');
          }
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "level"
      }
    },
    cart_master_id: {
      properties: {
        type: 'Dropdown',
        label: 'Program Type',
        primeFieldProps: {
          onChange: (ev, setValue) => {
            // let cartMasterName;
            if (ev.originalEvent.target.ariaLabel)
              cartMasterName = discipline + "-" + level + "-" + ev.originalEvent.target.ariaLabel + " " + randomText(6);
            else
              cartMasterName = discipline + "-" + level + "-" + randomText(6);
            setValue("cart_name", cartMasterName, { shouldValidate: true, shouldDirty: true })
          }
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "programType"
      }
    },
    cart_name: {
      properties: {
        type: 'InputText',
        label: 'Program Name',
        primeFieldProps: {
        },
        validations: {
          required: validations.required
        }
      }
    }
  });
  // validations end
  // state management end

  // form button group section start 
  const formSubmitButtonGroup = () => {
    return (
      <div className="form-button-group">
        <Button type="button" className='p-button p-button-secondary p-mr-2' label="Back to Details" onClick={gotoCollegePage} >
        </Button>
        <Button type="submit" label="Submit" className="p-button p-button-primary" />
      </div>
    )
  }
  // form button group section end 

  // form submit section start
  const formOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      addCart(formData)
    }
  };

  // create new cart section  start
  const addCart = async (data) => {
    try {
      let cartResponse = await response.add({
        service: collegeCartService,
        method: "addCart",
        data: { item: data },
        toasterMessage: {
          success: 'Cart created successfully',
          error: 'Cart not created'
        }
      });

      if (cartResponse && cartResponse.data && !cartResponse.data.isError) {
        let cartData = cartResponse.data.data;
        toggleCartPage(true);
        if (cartData) {
          updateCart({
            cart_id: cartData.cart_id,
            cart_name: cartData.cart_name,
            college_id: cartData.college_id,
          });
        }
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // create new cart section end
  // form submit section end

  // college page navigation section start
  const gotoCollegePage = () => {
    modalPopup.toggle(false);
    if (getUserType() === "CS")
      history.push(`/mycollege`);
    else
      history.push(`/college/details/${params.id}`);
  }
  // college page navigation section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={cartFormFields} onFormSubmit={formOnsubmit} submitButtonGroup={formSubmitButtonGroup} />
    </div>
  )
}

export default CartForm;