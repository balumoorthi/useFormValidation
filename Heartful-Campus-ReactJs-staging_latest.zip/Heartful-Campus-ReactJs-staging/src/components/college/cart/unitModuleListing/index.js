import React, { Component } from 'react';

// components
// primereact components 
import { DataTable } from 'primereact/datatable';

import { Column } from 'primereact/column';

import { confirmDialog } from 'primereact/confirmdialog';

// shared component 
import HFNDataTablePagination from 'shared-components/datatable/HFNDataTablePagination';

// utils 
import { downloadFile, getUserType } from "utils/common";

import { response } from 'utils/response';

import { toaster } from 'utils/toaster';

// services 
import ModuleService from 'services/module/module.service';

// config
import config from 'assets/config';

export class UnitModuleListing extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.moduleService = new ModuleService();

    this.userType = getUserType();
    // variable init end

    // state management start
    this.state = {

      loading: false,

      totalRecords: 0,

      modules: null,

      lazyParams: {
        first: 0,
        rows: 5,
        page: 1,
        filters: {}
      },

      pagination: {

        prevPageLink: {
          isPrevPageLink: true,
          classNames: ''
        },

        nextPageLink: {
          isNextPageLink: true,
          classNames: ''
        },

        pageLinks: {
          isPageLinks: true,
          classNames: ''
        },

        rowsPerPageDropdown: {
          isRowPerPage: true,
          dropdownOptions: [
            { label: 5, value: 5 },
            { label: 10, value: 10 },
            { label: 20, value: 20 },
            { label: 50, value: 50 },
          ],
          classNames: ''
        },

        currentPageReport: {
          isPageResult: true,
          isPageNavigator: false,
          classNames: ''
        }

      }

    };
    // state management end

  }

  // datatable methods start 
  loadLazyData = async () => {
    this.setState({ loading: true });

    try {
      let apiResponse = await this.moduleService.getModuleByUnit({ lazyEvent: this.state.lazyParams, unit_id: this.props.unitID })

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && Array.isArray(apiResponse.data.data)) {
        this.setState({
          totalRecords: apiResponse.data.count,
          modules: apiResponse.data.data,
          loading: false
        });
      }
      else
        this.setState({ loading: false });
    }
    catch {
      this.setState({ loading: false });
    }
  }

  onPage = (event) => {
    event.page = event.page + 1;
    let lazyParams = { ...this.state.lazyParams, ...event };
    this.setState({ lazyParams }, this.loadLazyData);
  }

  onSort = (event) => {
    if (event.sortField) {
      let lazyParams = { ...this.state.lazyParams, ...event };
      this.setState({ lazyParams }, this.loadLazyData);
    }
  }

  onFilter = (event) => {
    let lazyParams = { ...this.state.lazyParams, ...event };
    lazyParams['first'] = 0;
    this.setState({ lazyParams }, this.loadLazyData);
  }
  // datatable methods end

  // datatable templates section start
  // default template section start
  defaultTemplate = (rowData, { field }) => {
    return rowData[field] ? <div title={rowData[field]}> {rowData[field]} </div> : "-";
  }
  // default template section end

  // module template section start
  moduleTemplate = rowData => {
    return (
      <div className="info-section" title={rowData.module_name}>
        <span className="info"> {rowData.module_name} </span>
        <span className="info-icon" onClick={() => { this.moduleInfo(rowData) }} > <i className="uil uil-info-circle"></i> </span>
      </div>
    );
  }
  // module template section end

  // download template section start
  downloadTemplate = rowData => {
    return (
      <p style={{ cursor: 'pointer' }}>
        <u onClick={() => { this.downloadModulesAttachments(rowData) }}>Link</u>
      </p>
    );
  }
  // download template section end
  // datatable templates section end

  // module info popup section start
  moduleInfo = moduleInfo => {
    confirmDialog({
      message: moduleInfo.module_desc,
      header: moduleInfo.module_name,
      className: 'module-confirm-popup mcp-desc'
    });
  }
  // module info popup section end

  // download module attachments section start
  downloadModulesAttachments = async (module) => {
    let moduleFilesResponse, moduleFilesResponseData = [];
    try {
      moduleFilesResponse = await response.get({
        service: this.moduleService,
        method: 'listAttachments',
        data: { itemId: module.module_id }
      });

      if (moduleFilesResponse && moduleFilesResponse.data && !moduleFilesResponse.data.isError && Array.isArray(moduleFilesResponse.data.data)) {
        moduleFilesResponseData = moduleFilesResponse.data.data.map((item) => {
          return {
            url: config.mediaURL + "digital-asset/" + item.document_name,
            fileName: item.document_name
          }
        })
      }

      if (moduleFilesResponseData.length > 0) {
        // eslint-disable-next-line array-callback-return
        moduleFilesResponseData.map(item => {
          downloadFile(item.url, item.fileName);
        });
      }
      else
        toaster.info(`This "${module.module_name}" module does not have any attachments`);
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // download module attachments section end

  componentDidMount() {
    this.loadLazyData();
  }

  render() {
    return (
      <div>
        <div className="hfn-datatable hfn-datatable-lazy">

          <DataTable
            ref={(el) => this.dt = el}
            value={this.state.modules}
            lazy
            paginator
            paginatorTemplate={HFNDataTablePagination(this.state.pagination)}
            first={this.state.lazyParams.first}
            rows={this.state.lazyParams.rows}
            totalRecords={this.state.totalRecords}
            onPage={this.onPage}
            onSort={this.onSort}
            sortField={this.state.lazyParams.sortField}
            sortOrder={this.state.lazyParams.sortOrder}
            onFilter={this.onFilter}
            filters={this.state.lazyParams.filters}
            loading={this.state.loading}
            autoLayout={true}
          >
            <Column field="module_name" header="Module Name" body={this.moduleTemplate} sortable filter />
            <Column field="discipline_name" header="Discipline" body={this.defaultTemplate} sortable filter />
            <Column field="level_name" header="Level" body={this.defaultTemplate} sortable filter />
            {
              this.userType !== "CS"
                ?
                <Column header="Description" body={this.downloadTemplate} />
                :
                null
            }
          </DataTable>

        </div>
      </div>
    )
  }
}

export default UnitModuleListing;
