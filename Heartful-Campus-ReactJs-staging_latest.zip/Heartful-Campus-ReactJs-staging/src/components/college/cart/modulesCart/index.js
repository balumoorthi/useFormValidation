import React, { Component } from 'react';

// state 
import { connect } from "react-redux";

// components
// primereact components 
import { DataTable } from 'primereact/datatable';

import { Column } from 'primereact/column';

import { confirmDialog } from 'primereact/confirmdialog';

import { ToggleButton } from 'primereact/togglebutton';

// shared component 
import HFNDataTablePagination from 'shared-components/datatable/HFNDataTablePagination';

// utils 
import { downloadFile, getUserType } from "utils/common";

import { addModule, removeModule } from 'utils/cart';

import { response } from 'utils/response';

import { toaster } from 'utils/toaster';

// services 
import ModuleService from 'services/module/module.service';

import CartService from 'services/college/cart.service';

// config
import config from 'assets/config';

export class ModulesCart extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.moduleService = new ModuleService();

    this.cartService = new CartService();

    this.userType = getUserType();
    // variable init end

    // state management start
    this.state = {

      loading: false,

      totalRecords: 0,

      modules: [],

      lazyParams: {
        first: 0,
        rows: 5,
        page: 1,
        filters: {}
      },

      pagination: {

        prevPageLink: {
          isPrevPageLink: true,
          classNames: ''
        },

        nextPageLink: {
          isNextPageLink: true,
          classNames: ''
        },

        pageLinks: {
          isPageLinks: true,
          classNames: ''
        },

        rowsPerPageDropdown: {
          isRowPerPage: true,
          dropdownOptions: [
            { label: 5, value: 5 },
            { label: 10, value: 10 },
            { label: 20, value: 20 },
            { label: 50, value: 50 },
          ],
          classNames: ''
        },

        currentPageReport: {
          isPageResult: true,
          isPageNavigator: false,
          classNames: ''
        }

      }

    };
    // state management end

  }

  // datatable methods start 
  loadLazyData = async () => {
    this.setState({ loading: true });

    try {
      let apiResponse = await this.cartService.getModulesOffered({ lazyEvent: this.state.lazyParams, college_id: this.props.collegeID })

      if (apiResponse && apiResponse.data && apiResponse.data.data && !apiResponse.data.isError) {
        this.setState({
          totalRecords: apiResponse.data.count,
          modules: apiResponse.data.data,
          loading: false
        }, () => {
          this.setCartItem();
        });
      }
      else {
        this.setState({ loading: false });
      }
    }
    catch {
      this.setState({ loading: false });
    }
  }

  onPage = (event) => {
    event.page = event.page + 1;
    let lazyParams = { ...this.state.lazyParams, ...event };
    this.setState({ lazyParams }, this.loadLazyData);
  }

  onSort = (event) => {
    if (event.sortField && event.sortField !== "SortingDisabled") {
      let lazyParams = { ...this.state.lazyParams, ...event };
      this.setState({ lazyParams }, this.loadLazyData);
    }
  }

  onFilter = (event) => {
    let lazyParams = { ...this.state.lazyParams, ...event };
    lazyParams['first'] = 0;
    this.setState({ lazyParams }, this.loadLazyData);
  }
  // datatable methods end

  // datatable templates section start
  // default template section start
  defaultTemplate = (rowData, { field }) => {
    const fieldValue = field.split('.').reduce((o, k) => o && o[k], rowData);
    return fieldValue ? <div title={fieldValue}> {fieldValue} </div> : "-";
  }
  // default template section end

  // module template section start
  moduleTemplate = rowData => {
    return (
      <div className="info-section" title={rowData.module_name}>
        <span className="info">{rowData.module_name}</span>
        <span className="info-icon" onClick={() => { this.moduleInfo(rowData) }} > <i className="uil uil-info-circle"></i> </span>
      </div>
    )
  }
  // module template section end

  // download template section start
  downloadTemplate = rowData => {
    return (
      <p style={{ cursor: 'pointer' }}>
        <u onClick={() => { this.downloadModuleAttachments(rowData) }}> Download </u>
      </p>
    );
  }
  // download template section end

  // action template section start
  actionTemplate = rowData => {
    return (
      <div className="cart-action-section">
        <ToggleButton
          className="cart-toogle-btn p-px-3"
          onLabel="Remove Item"
          offLabel="Add Item"
          checked={this.state["m" + rowData.module_id]}
          onChange={(e) => this.addCartItem(e, rowData)}
        />
      </div>
    );
  }
  // action template section end
  // datatable templates section end

  // module info popup section start
  moduleInfo = moduleInfo => {
    confirmDialog({
      message: moduleInfo.module_desc,
      header: moduleInfo.module_name,
      className: 'module-confirm-popup mcp-desc'
    });
  }
  // module info popup section end

  // download module attachments section start
  downloadModuleAttachments = async (module) => {
    let moduleFilesResponse, moduleFilesResponseData = [];

    try {
      moduleFilesResponse = await response.get({
        service: this.moduleService,
        method: 'listAttachments',
        data: { itemId: module.module_id }
      });

      if (moduleFilesResponse && moduleFilesResponse.data && moduleFilesResponse.data.data) {
        moduleFilesResponseData = moduleFilesResponse.data.data.map((item) => {
          return {
            url: config.mediaURL + "digital-asset/" + item.document_name,
            fileName: item.document_name
          }
        })
      }

      if (moduleFilesResponseData.length > 0) {
        // eslint-disable-next-line array-callback-return
        moduleFilesResponseData.map((item) => {
          downloadFile(item.url, item.fileName);
        })
      } else {
        toaster.info(`This "${module.module_name}" module does not have any attachments`)
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // download module attachments section end

  // add or remove module to cart section start
  addCartItem = (ev, cartItem) => {
    (ev.value) ? addModule(cartItem) : removeModule(cartItem);
    this.setState({ ["m" + cartItem.module_id]: ev.value })
  }
  // add or remove module to cart section enfd

  // set module selection state in table section start
  setCartItem = () => {
    if (this.props.cd.cart && this.props.cd.cart.modules) {
      const selectedModules = this.props.cd.cart.modules;
      this.state.modules.forEach(module => {
        this.setState({
          ["m" + module.module_id]: (selectedModules.find(sModule => sModule.module_id === module.module_id) ? true : false)
        })
      })
    }
  }
  // set module selection state in table section end

  componentDidMount() {
    this.loadLazyData();
  }

  render() {
    return (
      <div>
        <div className="hfn-datatable hfn-datatable-lazy">
          <DataTable
            ref={(el) => this.dt = el}
            value={this.state.modules}
            lazy
            paginator
            paginatorTemplate={HFNDataTablePagination(this.state.pagination)}
            first={this.state.lazyParams.first}
            rows={this.state.lazyParams.rows}
            totalRecords={this.state.totalRecords}
            onPage={this.onPage}
            onSort={this.onSort}
            sortField={this.state.lazyParams.sortField}
            sortOrder={this.state.lazyParams.sortOrder}
            onFilter={this.onFilter}
            filters={this.state.lazyParams.filters}
            loading={this.state.loading}
            autoLayout={true}
          >
            <Column field="module_name" header="Module" sortable filter body={this.moduleTemplate} />
            <Column field="disciplines.discipline_name" header="Discipline" body={this.defaultTemplate} sortField="SortingDisabled" filter />
            <Column field="levels.level_name" header="Level" body={this.defaultTemplate} sortField="SortingDisabled" filter />
            {
              this.userType !== "CS"
                ?
                <Column header="Downloads" body={this.downloadTemplate} style={{ minWidth: "100px" }} />
                :
                null
            }
            <Column field="program_types.program_type_name" header="Program Type" body={this.defaultTemplate} sortField="SortingDisabled" filter style={{ minWidth: "240px" }} />
            <Column header="Action" body={this.actionTemplate} style={{ minWidth: "140px", width: '140px' }} />

          </DataTable>
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  cd: state.cartDetails
});

export default connect(mapStateToProps, null, null, { forwardRef: true })(ModulesCart);
