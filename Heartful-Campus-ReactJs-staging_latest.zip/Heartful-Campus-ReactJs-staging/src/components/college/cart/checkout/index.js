import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// components
// primereact components 
import { DataTable } from 'primereact/datatable';

import { Column } from 'primereact/column';

import { confirmDialog } from 'primereact/confirmdialog';

import { Calendar } from 'primereact/calendar';

// shared components
import HFNLoader from 'shared-components/lazyLoading/Loading';

import HFNDataTablePagination from 'shared-components/datatable/HFNDataTablePagination';

// utils 
import { uniqBy } from 'lodash';

import moment from 'moment';

import { clearCart } from 'utils/cart';

import { response } from 'utils/response';

import { getUserType } from 'utils/common';

import { getUserName } from "utils/common";

import { toaster } from 'utils/toaster';

// services 
import CollegeCartService from 'services/college/cart.service';

import { Dropdown } from 'primereact/dropdown';

class Checkout extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.cartService = new CollegeCartService();
    // variable init end

    // state management start
    this.state = {

      loader: false,

      data: uniqBy(this.props.cd.cart.modules, 'module_id').map(module => {
        if (!module.discipline_name && module.disciplines && module.disciplines.discipline_name)
          module.discipline_name = module.disciplines.discipline_name;
        if (!module.level_name && module.levels && module.levels.level_name)
          module.level_name = module.levels.level_name;
        if (!module.program_type_name && module.program_types && module.program_types.program_type_name)
          module.program_type_name = module.program_types.program_type_name;
        if (!module.unit_name && Array.isArray(module.unitmodules)) {
          const moduleUnit = module.unitmodules.find(unit => (unit.units && unit.units.unit_name));
          if (moduleUnit)
            module.unit_name = moduleUnit.units.unit_name;
        }
        return module;
      }),

      collegeID: this.props.match.params.id,

      pagination: {

        prevPageLink: {
          isPrevPageLink: true,
          classNames: ''
        },

        nextPageLink: {
          isNextPageLink: true,
          classNames: ''
        },

        pageLinks: {
          isPageLinks: true,
          classNames: ''
        },

        rowsPerPageDropdown: {
          isRowPerPage: true,
          dropdownOptions: [
            { label: 5, value: 5 },
            { label: 10, value: 10 },
            { label: 20, value: 20 },
            { label: 50, value: 50 },
          ],
          classNames: ''
        },

        currentPageReport: {
          isPageResult: true,
          isPageNavigator: false,
          classNames: ''
        }
        
      }
    }
    // state management end
  }

  // datatable template start
  // default template section start
  defaultTemplate = (rowData, { field }) => {
    return rowData[field] ? <div className="hfn-datatable-td" title={rowData[field]}>{rowData[field]}</div> : "-";
  }
  // default template section end

  // module template section start
  moduleTemplate = rowData => {
    return (
      <div className="info-section">
        <span className="info" title={rowData.module_name}>{rowData.module_name}</span>
        <span className="info-icon" onClick={() => { this.moduleInfo(rowData) }} > <i className="uil uil-info-circle"></i> </span>
      </div>
    );
  }
  // module template section end

  // date template section start
  dateTemplate = (rowData, { field }) => {
    let date;

    if (rowData[field])
      date = new Date(rowData[field]);
    return (
      <Calendar
        className="eventDateIcon"
        showTime
        showIcon
        hourFormat="12"
        placeholder="MM/DD/YYYY HH:MM AM/PM"
        showOnFocus={false}
        yearNavigator
        yearRange={"2020:"+new Date().getFullYear()}
        // readOnlyInput
        value={date}
        onChange={(ev) => {
          this.setDate(ev.value, rowData, field)
        }}
      />
    );
  }
  // date template section end
  // durartion section start
  changeDuration = (rowData, { field }) => {
    let durationValue;

    if (rowData[field])
      durationValue = rowData[field];
    return (
      <Dropdown
        optionLabel="label"
        value={durationValue}
        disabled={!rowData.enable}
        options={this.props.dd.durationTiming}
        onChange={(ev) => {
          this.setDate(ev.value, rowData, field)
        }}
      />
    );
  }
  // duration section end

  // action template section start
  actionTemplate = (rowData) => {
    return (
      <div className="actions-section">
        <button className="p-button p-button-danger" onClick={(ev) => this.removeModule(ev, rowData)}>
          <i className="uil uil-trash-alt"></i>
          Remove
        </button>
      </div>
    );
  }
  // action template section end
  // datatable templates section end 

  // module template popup section start
  moduleInfo = (moduleInfo) => {
    confirmDialog({
      header: moduleInfo.module_name,
      message: moduleInfo.module_desc,
      className: 'module-confirm-popup mcp-desc'
    });
  }
  // module template popup section end

  // set start date and end date on change event section start
  setDate = (date, rowData, field) => {
    this.setState({
      data: this.state.data.map(module => {
        if (module.module_id === rowData.module_id) {
          if (field === "event_start_date") {
            module.event_start_date = date;
            module.enable=true;
            module.duration = ""
            module.event_end_date = ""
          }
          else {
            let time = date;
            let hours = time.charAt(0);
            let minutes = time.slice(-2);
            let durationChange = new Date(module.event_start_date);
            durationChange.setHours(durationChange.getHours() + Number(hours));
            durationChange.setMinutes(durationChange.getMinutes() + Number(minutes));
            module.event_end_date = durationChange;
            module.duration = date
          }
        }
        return module;
      })
    });
  }
  // set start date and end date on change event section end

  // remove module section start
  removeModule = (ev, rowData) => {
    confirmDialog({
      message: `Are you sure to remove module "${rowData.module_name}"?`,
      header: "Waring",
      className: 'module-confirm-popup',
      accept: () => {
        this.setState({ data: this.state.data.filter(module => module.module_id !== rowData.module_id) });
      }
    });
  }
  // remove module section end

  // finalize cart section start
  finalizeCart = async () => {
    try {
      this.setState({ loader: true });
      const cartDetails = this.props.cd.cartDetails;
      const checkDate = (start, end) => {
        var mStart = moment(start);
        var mEnd = moment(end);
        return mStart.isBefore(mEnd);
      }
      let dateErrors = [];

      this.state.data.forEach(module => {
        let startDate, endDate, isValidDate;

        startDate = moment(new Date(module.event_start_date)).isValid();
        endDate = moment(new Date(module.event_end_date)).isValid();
        isValidDate = checkDate(module.event_start_date, module.event_end_date);

        if (!startDate || !endDate) {
          dateErrors.push({
            item_name: module.module_name,
            message: `The start date and duration is required for this module`
          })
        }
        else if (!isValidDate) {
          dateErrors.push({
            item_name: module.module_name,
            message: `The end date should be greater than start date`
          });
        }
      });

      if (dateErrors.length === 0) {
        let cartData = {
          cart_id: cartDetails.cart_id,
          cart_name: cartDetails.cart_name,
          status_id: 2,
          college_id: cartDetails.college_id,
          created_by: getUserName(),
          items: this.state.data.map(module => ({
            type: "Module",
            cart_id: cartDetails.cart_id,
            cart_name: cartDetails.cart_name,
            college_id: cartDetails.college_id,
            id: module.module_id,
            event_start_date: module.event_start_date,
            event_end_date: module.event_end_date
          }))
        };

        let cartResponse = await response.add({
          service: this.cartService,
          method: 'finalizeCart',
          data: {
            item: cartData
          },
          toasterMessage: {
            success: 'Successfully Finalized Cart!',
            error: 'Cart was not finalized',
          },
          modalPopupHide: true
        });

        if (cartResponse && cartResponse.data && !cartResponse.data.isError) {
          clearCart();
          if (getUserType() === "CS")
            this.props.history.push(`/mycollege`);
          else
            this.props.history.push(`/college/details/${this.state.collegeID}`);
        }
        else
          this.setState({ loader: false });
      }
      else {
        this.setState({ loader: false });
        toaster.custom({ severity: "error", summary: dateErrors[0].item_name, detail: dateErrors[0].message });
      }
    }
    catch {
      this.setState({ loader: false });
    }
  }
  // finalize cart section end

  // cart page navigation section start
  gotoCart = () => {
    if (getUserType() === "CS")
      this.props.history.push(`/mycollege/cart`)
    else
      this.props.history.push(`/college/cart/${this.state.collegeID}`)
  }
  // cart page navigation section end

  // page reload confirmation prompt section start
  pageReloadConfirm = (event) => {
    event.preventDefault();
    return event.returnValue = "Changes you made may not be saved.";
  }
  // page reload confirmation prompt section end

  // redirect to college on direct navigation section start
  redirectToCart = () => {
    try {
      if (this.state.data.length === 0) {
        if (getUserType() === "CS")
          this.props.history.push(`/mycollege/cart`)
        else
          this.props.history.push(`/college/details/${this.state.collegeID}`)
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // redirect to college on direct navigation section end

  componentDidMount() {
    this.redirectToCart();
    window.addEventListener("beforeunload", this.pageReloadConfirm, { capture: true });
  }

  componentWillUnmount() {
    window.removeEventListener("beforeunload", this.pageReloadConfirm, { capture: true });
  }

  render() {
    
    const { cart, cartDetails } = this.props.cd;

    return (
      <div className="p-cart-view-table-section">
        {(this.state.loader === true) ? <HFNLoader /> : <></>}

        <div className="p-toolbar checkout-toolbar">
          <div className="datatable-title">
            <h4> Final Cart -&nbsp;{cartDetails.cart_name || ""}</h4>
          </div>
          <button className="p-button p-button-primary" onClick={() => { this.gotoCart() }}> Back to cart </button>
        </div>

        <div className="hfn-datatable">
          <DataTable
            ref={(el) => this.dt = el}
            value={this.state.data}
            paginator
            paginatorTemplate={HFNDataTablePagination(this.state.pagination)}
            rows={5}
            emptyMessage="No items found."
            autoLayout={true}
          >
            <Column field="module_name" header="Module" sortable filter filterMatchMode='contains' body={this.moduleTemplate} />
            <Column field="discipline_name" header="Discipline" sortable filter filterMatchMode='contains' body={this.defaultTemplate} />
            <Column field="level_name" header="Level" sortable filter filterMatchMode='contains' body={this.defaultTemplate} />
            <Column field="unit_name" header="Unit Name" sortable filter filterMatchMode='contains' body={this.defaultTemplate} />
            <Column field="program_type_name" header="Program Type" sortable filter filterMatchMode='contains' style={{ minWidth: "240px" }} body={this.defaultTemplate} />
            <Column field="event_start_date" header="Start Date" body={this.dateTemplate} style={{ minWidth: "212px", width: '212px' }} />
            <Column field="duration" header="Duration" body={this.changeDuration} style={{ minWidth: "200px", width: '200px' }} />
            <Column header="Action" body={this.actionTemplate} style={{ minWidth: "110px", width: '110px' }} />
          </DataTable>

          <div className="p-card p-mt-3">
            <div className="p-card-body p-p-3">
              <div className="p-d-flex p-jc-end">
                <button className="p-button p-button-primary" disabled={(cart.length <= 0) ? "disabled" : null} onClick={this.finalizeCart}> Finalize Cart </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  cd: state.cartDetails,
  dd: state.dropdownDetails,
});

export default withRouter(connect(mapStateToProps)(Checkout));
