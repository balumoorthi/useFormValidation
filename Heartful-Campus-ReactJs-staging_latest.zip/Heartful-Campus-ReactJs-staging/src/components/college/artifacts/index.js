import React, { Component } from 'react';

import { connect } from "react-redux";

// Components
import CollegeMouListing from 'components/college/artifacts/collegeMouListing';

// shared-components
import ReportForm from 'shared-components/report';

// utils
import buildBreadcrumb from 'utils/breadcrumb';

import { dropdown } from 'utils/dropdown';

import { Dropdown } from 'primereact/dropdown';

// services
import CollegeService from 'services/college/college.service';

import AutoCompleteService from 'services/autoComplete/autoComplete.service';

class CollegeArtifacts extends Component {
  constructor(props) {

    super(props);

    // variable init start
    this.collegeService = new CollegeService();

    this.autoCompleteService = new AutoCompleteService();
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: 'Dashboard', url: 'dashboard', icon: 'pi pi-home' },
        { label: 'College Artifacts', url: 'artifacts' },
      ],
      
      showMOU: false,
      showTestimonials: false,
      showMedia: false,
      artifactType: "",

      initialValues: {},

      artifactTypeValues: {
        typeOfDownload: "artifact",
        type: "",
      },

      options: {
        title: 'Artifact Filters',

        service: this.collegeService,

        method: 'downloadArtifacts',

        rows: 10,

        timestampSuffix: 'DDMMYYYY',

        fileName: 'College_Artifact',
      },

      formFields: {
        college_id: {
          properties: {
            // type: "Dropdown",
            type: "MultiSelect",
            label: "College",
            fieldWrapperClassNames: "p-md-3",
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: "colleges"
          }
        },

        from_date: {
          properties: {
            type: 'Calendar',
            label: 'Registered From',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              maxDate: new Date(),
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          },
        },

        to_date: {
          properties: {
            type: 'Calendar',
            label: 'Registered To',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              maxDate: new Date(),
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          },
        },

        city: {
          properties: {
            type: 'InputText',
            label: 'City',
            fieldWrapperClassNames: 'p-md-3',
            validations: {
              maxLength: {
                value: 120,
                message: 'Please enter city with maximum 120 characters',
              },
            },
          },
        },

        state: {
          properties: {
            type: 'InputText',
            label: 'State',
            fieldWrapperClassNames: 'p-md-3',
            validations: {
              maxLength: {
                value: 120,
                message: 'Please enter state with maximum 120 characters',
              },
            },
          },
        },

        country: {
          properties: {
            type: 'Dropdown',
            label: 'Country',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: 'country',
          },
        },

        zone_id: {
          properties: {
            type: 'SelectDropdown',
            label: 'Zone',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { isSearchable: true, isClearable: true },
            dropdownOptions: 'zone',
          },
        },

        status_id: {
          properties: {
            type: 'Dropdown',
            label: 'Status',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: 'collegeStatus',
          },
        },

      },
    };
    // state management end
  }

  updateArtifactTypeValue = (e) => {
    this.setState({ artifactType: e.value })
    this.setState({
      artifactTypeValues: {
        ...this.state.artifactTypeValues,
        type: e.value,
      },
    });
    if(e.value === "mou") {
      this.setState({ showMOU: true})
      this.setState({ showTestimonials: false})
      this.setState({ showMedia: false })
    } else if(e.value === "testimonial") {
      this.setState({ showMOU: false})
      this.setState({ showTestimonials: true})
      this.setState({ showMedia: false })
    } else if(e.value === "media") {
      this.setState({ showMOU: false})
      this.setState({ showTestimonials: false})
      this.setState({ showMedia: true })
    }
  }

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.collegeStatus();
    dropdown.country();
    dropdown.zone();
    dropdown.artifactType();
    dropdown.colleges();
  }

  render() {
    return (
      <div>
        <div className="p-d-flex p-flex-wrap">
          <div className="p-col-12 p-d-flex p-flex-wrap p-md-6">
            <div className="p-col-12 p-text-left">
              <div>
                <label className="p-col-1">Artifact Type: </label>
                <Dropdown 
                  value={this.state.artifactType} 
                  options={this.props.ld.artifactType} 
                  onChange={(e) => { this.updateArtifactTypeValue(e) }}
                  optionLabel="label" filter showClear filterBy="label" 
                />
              </div>
            </div>
          </div>
        </div>
        {
          this.state.showMOU ? 
          <>
            <ReportForm fields={this.state.formFields} initialValues={this.state.initialValues} artifactValues={this.state.artifactTypeValues} options={this.state.options} />
            <CollegeMouListing artifactValues={this.state.artifactTypeValues} />
          </> : <></>
        }
        {
          this.state.showMedia || this.state.showTestimonials ?
          <ReportForm fields={this.state.formFields} initialValues={this.state.initialValues} artifactValues={this.state.artifactTypeValues} options={this.state.options} />
          :
          <></>
        }
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ld: state.dropdownDetails
});

export default connect(mapStateToProps)(CollegeArtifacts);
