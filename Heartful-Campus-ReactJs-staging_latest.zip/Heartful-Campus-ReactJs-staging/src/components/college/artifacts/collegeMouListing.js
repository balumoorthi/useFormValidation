import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { confirmDialog } from "utils/confirmDialog";

import { createdDateBadge, gotoPage } from "utils/badgeTemplate";

import { bulk } from "utils/bulk";

import { getModuleAccess } from "utils/common";

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// services 
import collegeService from 'services/college/college.service';

class CollegeMouListing extends Component {

  constructor(props) {

    super(props);

    //variable init starts
    this.collegeService = new collegeService();

    this.collegeTable = React.createRef(null);

    const moduleAccess = getModuleAccess("COLLEGE") || {};
    const enableViewLink = Array.isArray(moduleAccess.access) ? moduleAccess.access.includes("view") : false;
    //variable init end

    this.state = {
      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "College Artifacts", url: "artifacts", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: false,
          moduleName: getModuleAccess("COLLEGE"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px"
        },

        url: this.collegeService,

        method: 'getCollegeMous',

        params: {
          
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1,
        },

        columns: [
          {
            header: 'College',
            field: 'college.label',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
            body: enableViewLink ? (rowData, { field }) => { return gotoPage(rowData, field, this.gotoCollegeDetails) } : null
          },
          {
            header: 'MOU Document',
            field: 'upload_documents',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        enableActionColumn: false,
        
        toolBarBtnOptions: {
          title: 'College MOU List',
          selection: {
            enableUpdate: false,
            field: {
              options: "generalStatus"
            },
            deleteBtnsOptions: {
              label: "Downlod MOUs",
              classNames: "p-button-primary",
              icon: "pi pi-download",
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "You are about to download MOU of selected colleges?",
                  accept: () => { this.bulkDownlaod(selections) }
                });
              }
            },
          },
          rightBtnsOptions: [
            {
              visibility: false
            }
          ]
        },
        enableSelection: true,
      },

      // datatables 

    }
  }

  // bulk Status update section starts
  bulkDownlaod = async (selections) => {
    await bulk.setBulkDownload({
      data: {
        type: "College",
        name: "college_id",
        value: selections.map(value => { return value.college_id }),
        artifactType: this.props.artifactValues.type
      },
      dataTable: this.collegeTable,
    })
  }
  // bulk Status update section end

  gotoCollegeDetails = (ev, rowData) => {
    this.props.history.push(`/college/details/${rowData.college_id}`);
  }

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.collegeTable} options={this.state.options} />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(CollegeMouListing));