import React, { Component } from 'react';

import { withRouter } from "react-router";

// utils 
import { programStatusBadge, createdDateBadge, gotoPage, totalHoursBadge, participantCountBadge } from "utils/badgeTemplate";

import { getUserType, getModuleAccess, getUserRole } from 'utils/common';

import { confirmDialog } from "utils/confirmDialog";

import { response } from "utils/response";

import { toaster } from "utils/toaster";

import { modalPopup } from "utils/modalPopup";

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import ProgramService from 'services/college/program.service';

import SessionEditForm from './session/SessionEditForm';

import ProgramEditForm from './ProgramEditForm';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class ProgramListing extends Component {

  constructor(props) {

    super(props);

    this.programService = new ProgramService();

    this.programTable = React.createRef();

    const moduleAccess = getModuleAccess("PROGRAM") || {};
    const enableViewLink = Array.isArray(moduleAccess.access) ? moduleAccess.access.includes("view") : false;

    localStorage.setItem('moduleName', 'program');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['program'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      // datatables 
      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("PROGRAM"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.programService,

        method: 'getCollegeProgramList',

        params: {
          college_id: this.props.collegeID
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Program',
            field: 'cart_name',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
            body: enableViewLink ? (rowData, { field }) => { return gotoPage(rowData, field, this.viewSession) } : null
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: programStatusBadge,
            filterType: 'select',
            headerStyle: {
              width: '150px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "programStatus"
            }
          },
          {
            header: 'Total Hours',
            sortable: true,
            field: 'total_hours',
            headerStyle: {
              width: '125px'
            },
            body: totalHoursBadge
          },
          {
            header: 'Participants',
            field: 'participant_count',
            sortField: "SortingDisabled",
            body: participantCountBadge,
            headerStyle: {
              width: '175px'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'create',
            icon: "uil uil-pen edit-icon",
            className: "p-mr-2",
            visibilityCheck: rowData => rowData.status_id === 1,
            title: 'Finalize Program',
            onClick: this.gotoCartPage
          },
          {
            type: 'update',
            icon: "uil uil-edit edit-icon",
            className: "p-mr-2",
            title: 'Edit Program',
            onClick: this.editProgram
          },
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-mr-2 p-button-icon-only",
            title: "View Sessions",
            visibilityCheck: rowData => rowData.status_id !== 1,
            onClick: this.viewSession
          },
          {
            type: 'create',
            icon: "pi pi-user-plus edit-icon",
            className: "p-mr-2",
            title: 'Add Participant Count',
            onClick: this.addParticipantCount,
            visibilityCheck: rowData => (rowData.status_id === 6) ? true : false,
            visibility: (getUserType() === "U") ? "true" : false
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            className: "p-mr-2",
            title: 'Delete Program',
            onClick: (ev, rowData) => {
              let programID = rowData.cart_id;
              if (programID) {
                confirmDialog.toggle(true)
                confirmDialog.custom({
                  message: "Are you sure you want to delete this program?",
                  accept: () => { this.removeProgram(programID) }
                });
              }
            },
            visibility: (getUserType() === "U") ? "true" : false
          },
        ],

        toolBarBtnOptions: {
          title: 'Program List',
          rightBtnsOptions: [
            { visibility: false }
          ]
        }

      }
    }
  }

  gotoCartPage = () => {
    if (getUserType() === "CS")
      this.props.history.push(`/mycollege/cart`);
    else
      this.props.history.push(`/college/cart/${this.props.collegeID}`);
  }

  // Edit Program Section starts
  editProgram = (ev, rowdata) => {
    this.setState({programOpen:true})
    this.setState({
      programEdit: {
        initValue: {
          cart_id: rowdata.cart_id,
          cart_name: rowdata.cart_name
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Edit Program', className: "sdm-popup" });
      }
    )
  }
  // Edit Program Section ends

  viewSession = (ev, rowData) => {
    let programID = rowData.cart_id, collegeID = rowData.college_id;
    if (rowData.status_id === 5) {
      toaster.info("The program was cancelled");
      return;
    }

    if (getUserType() === "CS") {
      if (programID)
        this.props.history.push(`/mycollege/program/${programID}/session`);
    }
    else {
      if (collegeID && programID)
        this.props.history.push(`/college/${collegeID}/program/${programID}/session`);
    }
  }

  // add participant section start
  addParticipantCount = (ev, rowdata) => {
    this.setState({sessionOpen:true})
    this.setState({
      sessionEdit: {
        initValue: {
          cart_id: rowdata.cart_id,
          cart_name: rowdata.cart_name,
          manual_participant_count: rowdata.manual_participant_count
        },
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Add Participant Count', className: "sdm-popup" });
      }
    )
  }
  // add participant section end

  // program delete start

  removeProgram = async (id) => {
    if (id) {
      await response.remove({
        service: this.programService,
        method: 'removeProgram',
        data: { itemId: id },
        dataTable: this.programTable,
      })
    }
  }

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
  }

  // program delete end

  render() {
    return (
      <div>
        <HFNDataTable ref={this.programTable} options={this.state.options} />
        <HFNModalPopup>
          {this.state.sessionOpen ? 
            <SessionEditForm  initialValue={this.state.sessionEdit} dataTableRef={this.programTable}/>:
            (this.state.programOpen) ?
            <ProgramEditForm  initialValue={this.state.programEdit} dataTableRef={this.programTable}/>:
            <></>
          }
        </HFNModalPopup>
      </div>
    );
  }
}

export default withRouter(ProgramListing);
