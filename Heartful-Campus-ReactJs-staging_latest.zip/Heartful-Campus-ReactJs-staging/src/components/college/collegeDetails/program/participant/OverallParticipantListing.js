import React, { Component } from 'react';

import { withRouter } from 'react-router';
// utils 
import { response } from "utils/response";

import { certificateSentBadge, createdDateBadge, overallCertificateSentBadge } from "utils/badgeTemplate";

import { getModuleAccess, getResponseMessage, downloadFile, getUserType } from 'utils/common';

import { toaster } from "utils/toaster";

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// services 
import ParticipantService from 'services/college/participant.service';

import { Dialog } from 'primereact/dialog';

import { Button } from 'primereact/button';

import SessionService from 'services/session/session.service';

class OverallParticipantListing extends Component {

  constructor(props) {

    super(props);

    // variable init start 
    this.participantService = new ParticipantService();

    this.sessionService = new SessionService();

    this.participantTable = React.createRef(null);

    const module = getModuleAccess("PARTICIPANTS") || {};

    this.moduleAccess = module.access || [];
    // variable init end

    // state management start
    this.state = {
      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("PARTICIPANTS"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
        },

        url: this.participantService,

        method: 'getOverallParticipantList',

        params: { 
          cart_id: this.props.programID 
        },

        columns: [
          {
            header: 'Name',
            field: 'participant_name',
            sortable: true,
            filter: true
          },
          {
            header: 'Email',
            field: 'participant_email_id',
            sortable: true,
            filter: true,
            transformValue: false
          },
          {
            header: 'Mobile',
            field: 'participant_contact_number',
            sortable: true,
            filter: true,
          },
          {
            header: 'Certificate Sent',
            field: 'certificate_sent',
            sortable: true,
            body: certificateSentBadge,
          },
          {
            header: 'Certificate Eligible',
            field: 'certificate_eligible',
            sortField: "SortingDisabled",
            body: overallCertificateSentBadge,
          },
          {
            header: 'Sessions Attended',
            field: 'sessions_attended',
            sortable: true,
            filter: false,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge
          },
        ],

        actionBtnOptions: [
          {
            type: 'overallParticipant',
            icon: "pi pi-send remove-icon",
            className: "p-mr-2 p-button-icon-only",
            title: "Generate Certificate",
            visibilityCheck: rowData => rowData.certificate_eligible === 1,
            onClick: (ev, rowdata) => {
              this.generateCertificate(rowdata.participant_id, rowdata.attended_participant_ids) 
            },
            visibility: (getUserType() === "CS") ? false: true
          },
          {
            type: 'overallParticipant',
            icon: "pi pi-download view-icon",
            className: "p-mr-2 p-button-icon-only",
            title: "Download Certificate",
            visibilityCheck: rowData => rowData.certificate_eligible === 1,
            onClick: (ev, rowdata) => {
              this.downloadCertificate(rowdata.participant_id)
            },
            visibility: (getUserType() === "CS") ? false: true
          }
        ],

        toolBarBtnOptions: {
          title: 'Participant List',
          rightBtnsOptions: [
            {
              visibility: false
            }
          ]
        }

      },

      // datatables 

    }
    // state management end
  }

  // Generate Certificate section start
  generateCertificate = async (id, session_ids) => {
    let apiResponse, apiResponseData;
    let data = {
      cart_id: this.props.programID,
      participant_id: id,
      session_ids: session_ids
    }
    apiResponse = await response.add({
      service: this.participantService,
      method: 'generateParticipantCertificate',
      data: { item: data },
      dataTable: this.participantTable,
      toasterMessage: false
    })
    if (apiResponse && apiResponse.data) {
      apiResponseData = apiResponse.data;
      const responseMessage = getResponseMessage(apiResponseData);
      if (!apiResponseData.isError) {
        toaster.success(responseMessage || "Certificate Generated and Dispatched Successfully")
      } else {
        toaster.error(responseMessage || "Unable to Generate Certificate")
      }
    }
  }
  // Generate Certificate section end

  // Download Certificate section start
  downloadCertificate = async (id) => {
    let apiResponse, apiResponseData;
    let data = {
      cart_id: this.props.programID,
      participant_id: id
    }
    apiResponse = await response.add({
      service: this.participantService,
      method: 'downloadParticipantCertificate',
      data: { item: data },
      toasterMessage: false
    })
    if (apiResponse && apiResponse.data) {
      apiResponseData = apiResponse.data;
      const responseMessage = getResponseMessage(apiResponseData);
      if (!apiResponseData.isError) {
        /* const url = window.URL.createObjectURL(new Blob([apiResponseData.data]));
        const link = document.createElement('a');
        link.href = url;
        var fileName = apiResponseData.data.substring(apiResponseData.data.lastIndexOf('/') + 1);
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click(); */
        var fileName = apiResponseData.data.substring(apiResponseData.data.lastIndexOf('/') + 1);
        const downloadLink = apiResponseData.data;
        if (fileName) {
          downloadFile(downloadLink, fileName);
        }
        toaster.success(responseMessage || "Certificate Downladed Successfully")
      } else {
        toaster.error(responseMessage || "Unable to Download Certificate")
      }
    }
  }
  // Generate Certificate section end

  trainerAssigend = async () => {
    try{
      let apiResponse, apiResponseData;

      apiResponse = await response.get({
        service: this.sessionService,
        method: 'getSession',
        data: { itemId: this.props.sessionID },
      })
      if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
        apiResponseData = apiResponse.data.data;
        if (apiResponseData.user_info_id === null) {
          this.setState({ backtoSession: true })
        }
      }
    }catch(err){
      console.log(err)
    }
  }
  backToSessionList = () => {
    const { collegeID, programID } = this.props
    this.props.history.push(`/college/${collegeID}/program/${programID}/session`)
  }
  componentDidMount() {
    this.trainerAssigend();
  }

  render() {
    const footer = (
      <Button
        label="Back to session list"
        icon=""
        className='p-button-primary p-mr-2'
        onClick={() => { this.backToSessionList() }}
      />)
    return (
      <div>
        <HFNDataTable ref={this.participantTable} options={this.state.options} />
        {
          this.state.backtoSession &&
          <Dialog
            showHeader={true}
            footer={footer}
            header="Trainer not assigned"
            onHide={()=> {}}
            visible={true}>
            <p>Please assign a trainer before adding participants</p>
          </Dialog>
        }
      </div>
    );
  }
}

export default withRouter(OverallParticipantListing);