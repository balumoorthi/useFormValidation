import React, { Component } from "react";

import { connect } from "react-redux";

// components 
// prime components 
import { Button } from 'primereact/button';

import { Dropdown } from 'primereact/dropdown';

import { confirmDialog } from 'primereact/confirmdialog';

// import { InputText } from 'primereact/inputtext';

import { InputNumber } from 'primereact/inputnumber';

// utils 
import { response } from "utils/response";

import { getResponseMessage, getUserName, getUserRole } from "utils/common";

import { toaster } from "utils/toaster";

import { isEmpty, isString } from "lodash";

import moment from 'moment';

import { modalPopup } from "utils/modalPopup";

// config
import config from 'assets/config';

// constants
const certificate_folder = "digital-asset";

// services 
import SessionService from 'services/session/session.service';

import ProgramService from 'services/college/program.service';

// Shared Components
import HFNModalPopup from 'shared-components/modalPopup';

import HFNLoading from 'shared-components/lazyLoading/Loading';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class Certificate extends Component {

  constructor(props) {

    super(props);

    // variable init start 
    this.sessionService = new SessionService()
    this.programService = new ProgramService()
    // variable init end

    localStorage.setItem('moduleName', 'dispatch');

    // State Management Starts
    this.state = {
      confirmDispatch: "",
      participantConfigType: "",
      participantConfigValue: "",
      totalNoOfSessions: "",
      configText:"",
      loader: false,
      certificateTemplate : "",
      programName: "",
      sessionStartDate: new Date(),
      sessionEndDate: new Date(),
      certificateIssueDate: new Date(),
      certificateLevel: "",
      collegeName: "",
      collegeCity: "",
      collegeState: "",
      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['dispatch'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      }
    }
    // State Management Ends
  }

  // Participant Config Section Start
  participantConfiguration = async () => {
    let apiResponse, apiResponseData;
    let data = {
      cart_id: this.props.programID,
      participant_config_type: this.state.participantConfigType,
      participant_config_value: this.state.participantConfigValue,
      updated_by: getUserName()
    }
    try {
      apiResponse = await response.add({
        service: this.sessionService,
        method: 'participantConfig',
        data: { item: data },
        toasterMessage: false
      })

      if (apiResponse && apiResponse.data) {
        apiResponseData = apiResponse.data;
        const responseMessage = getResponseMessage(apiResponseData);

        if (!apiResponseData.isError) {
          toaster.success(responseMessage || "Participation Configuration Configured successfully")
        }
        else {
          toaster.error(responseMessage || "Participation Configuration not configured successfully")
        }
      }
    }  catch (err) {
      console.log(err)
    }
  }
  // Participant Config Section End

  // Certificate Preview section start
  previewCertificate = async () => {
    this.setState({ fileName: '' })
    try {
      let dateErrors = [];
      if (isEmpty(this.state.certificateTemplate)) {
        dateErrors.push({
          item_name: 'Certificate Template',
          message: `Certificate Template not uploaded.`
        });
      }

      if (dateErrors.length === 0) {
        let data = {
          template_url: config.mediaURL + certificate_folder + "/" + this.state.certificateTemplate,
          session_start_date: moment(this.state.sessionStartDate).format("YYYY-MM-DD"),
          session_end_date: moment(this.state.sessionEndDate).format("YYYY-MM-DD"),
          certificate_issue_date: moment(this.state.certificateIssueDate).format("YYYY-MM-DD"),
          program_name: this.state.programName,
          certificate_level: this.state.certificateLevel,
          certificate_college_name: this.state.collegeName,
          certificate_college_city: this.state.collegeCity,
          certificate_college_state: this.state.collegeState
        }
        let apiResponse;
        let previewData;

        apiResponse = await response.add({
          service: this.programService,
          method: 'previewCertificate',
          data: { item: data },
          toasterMessage: {
            success: "Certificate is Ready to Preview",
            error: "Unable to preview the certificate"
          }
        })
        if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
          previewData = apiResponse.data.data;
          if (isString(previewData)) {
            var fileName = previewData.substring(previewData.lastIndexOf('/') + 1);
            this.setState({
              imageSrc: previewData,
              fileName: fileName
            },() => {
              modalPopup.toggle(true)
              modalPopup.custom({ header: 'Preview Certificate', className: 'cms-popup' })
            })

          }
        }
      } else {
        toaster.custom({ severity: "error", summary: dateErrors[0].item_name, detail: dateErrors[0].message });
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // Certificate Preview section end

  // certificate dispatch section start
  dispatchCertificate = async () => {
    this.setState({ loader: true})
    let apiResponse, apiResponseData;
    let data = {
      cart_id: this.props.programID,
      // session_id: this.props.sessionID,
      created_by: getUserName()
    }
    try {

      apiResponse = await response.add({
        service: this.sessionService,
        method: 'dispatchCertificate',
        data: { item: data },
        toasterMessage: false
      })

      if (apiResponse && apiResponse.data) {
        this.setState({ loader: false})
        apiResponseData = apiResponse.data;
        const responseMessage = getResponseMessage(apiResponseData);

        if (!apiResponseData.isError) {
          this.setState({
            certificateDispatched: 1
          })
          toaster.success(responseMessage || "Certificate has been dispatched successfully")
        }
        else {
          toaster.error(responseMessage || "Unable to dispatch certificate")
        }
      }
    } catch (err) {
      console.log(err)
    }
  }
  // certificate dispatch section end

  // get program info start
  getProgram = async () => {
    let apiResponse, apiResponseData, totalSessions;

    apiResponse = await response.get({
      service: this.programService,
      method: 'getProgram',
      data: { itemId: this.props.programID },
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      apiResponseData = apiResponse.data.data;
      totalSessions = apiResponseData.sessions.length;
      this.setState({ totalNoOfSessions: apiResponseData.sessions.length });
      (apiResponseData.participant_config_type === "percentage") ? this.setState({ configText: "%"}) : this.setState({ configText: "sessions out of "+this.state.totalNoOfSessions});
      if (apiResponseData && apiResponseData.certificate_template) {
        this.setState({
          participantConfigType: apiResponseData.participant_config_type !== null ? apiResponseData.participant_config_type : "",
          participantConfigValue: apiResponseData.participant_config_value !== null ? apiResponseData.participant_config_value : "",
          certificateDispatched: apiResponseData.certificate_dispatched,
          certificateTemplate: apiResponseData.certificate_template !== null ? apiResponseData.certificate_template : "",
          programName: apiResponseData.program_name !== null ? apiResponseData.program_name : apiResponseData.cart_name,
          sessionStartDate: apiResponseData.session_start_date !== null ? new Date(apiResponseData.session_start_date) : new Date(apiResponseData.sessions[0].event_start_date),
          sessionEndDate: apiResponseData.session_end_date !== null ? new Date(apiResponseData.session_end_date) : new Date(apiResponseData.sessions[totalSessions-1].event_end_date),
          certificateLevel: apiResponseData.certificate_level !== null ? apiResponseData.certificate_level : "",
          collegeName: apiResponseData.certificate_college_name !== null ? apiResponseData.certificate_college_name : apiResponseData.colleges.label,
          collegeCity: apiResponseData.certificate_college_city !== null ? apiResponseData.certificate_college_city : apiResponseData.colleges.city,
          collegeState: apiResponseData.certificate_college_state !== null ? apiResponseData.certificate_college_state : apiResponseData.colleges.state,
          certificateIssueDate: apiResponseData.certificate_issue_date !== null ? apiResponseData.certificate_issue_date : new Date()  
        });
      }
    }
    else {
      toaster.error(getResponseMessage(apiResponseData) || "Unable to get program info")
    }
  }
  // get program info end

  updateParticipantConfigValue = (e) => {
    this.setState({ participantConfigType: e.value })
    if(e.value === "percentage") {
      this.setState({ configText: "%"})
      this.setState({ error: 0 })
    } else if(e.value === "session") {
      this.setState({ configText: "sessions out of "+this.state.totalNoOfSessions})
      this.setState({ error: 0 })
    } else {
      this.setState({ error: 1 })
    }
  }

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    this.getProgram()
  }

  render() {
    return (
      <div>
        <div className="p-d-flex p-flex-wrap p-col-12">
          <div className="p-col-12 p-d-flex p-flex-wrap p-md-6 certificate-upload-form">
            <div className="p-ml-3 p-col-12 p-text-left">
              <div>
                <label className="p-col-1">Type: </label>
                <Dropdown 
                  value={this.state.participantConfigType} 
                  options={this.props.ld.participantConfigType} 
                  onChange={(e) => { this.updateParticipantConfigValue(e) }}
                  optionLabel="label" filter showClear filterBy="label" 
                />
              </div>
              <div>
                <label className="p-col-1">Value: </label>
                <InputNumber
                  inputStyle={{width:'165px'}}
                  className="p-my-3"
                  placeholder="Config Value"
                  value={this.state.participantConfigValue} 
                  onChange={(e) => {
                    if(e.value === 0 || e.value === null) {
                      this.setState({ error: 1 })
                      toaster.custom({ 
                        severity: "error", 
                        summary: "Participation Config Value", 
                        detail: "Participation Config Value should be greater than 0" 
                      });
                    }else if(e.value > this.state.totalNoOfSessions && this.state.participantConfigType === 'session') {
                      this.setState({ error: 1 })
                      toaster.custom({ 
                        severity: "error", 
                        summary: "Participation Config Value", 
                        detail: "Participation Config Value should not be greater than total sessions" 
                      });
                    }else if(e.value > 100 && this.state.participantConfigType === 'percentage') {
                      this.setState({ error: 1 })
                      toaster.custom({ 
                        severity: "error", 
                        summary: "Participation Config Value", 
                        detail: "Participation Config Value should not be greater than 100" 
                      });
                    } else { 
                      this.setState({ error: 0 })
                      this.setState({
                        participantConfigValue: e.value
                      })
                    }
                  }}
                />
                <span id="totalSessions" className="p-ml-3 p-mt-3">{this.state.configText}</span>
              </div>
            </div>
            <div className="p-ml-3 p-col-12 p-text-left">  
              <Button
                type="button"
                className='p-button p-button-primary p-mx-1 p-my-3 participationConfig'
                label="Participant Configuration"
                onClick={() => { this.participantConfiguration() }}
                disabled={(this.state.error === 1) || (!this.state.participantConfigType && this.state.participantConfigType === '') || (!this.state.participantConfigValue && this.state.participantConfigValue === '')}
              />
            </div>
          </div>
          <div className="certificate-gallery-button-group p-col-12 p-md-6 certificate-upload-form">
            <div className="p-m-3 p-text-center">
              <Button
                type="button"
                className='p-button p-button-primary p-mx-2 p-my-3 p-p-4 dispatchCert'
                label="Dispatch Certificate"
                // onClick={() => { this.dispatchCertificate() }}
                onClick={() => { this.previewCertificate() }}
                disabled={(this.state.certificateDispatched === 1) || (this.state.error === 1) || (!this.state.participantConfigType && this.state.participantConfigType === '') || (!this.state.participantConfigValue && this.state.participantConfigValue === '')}
              />
              <div className="p-ml-2 p-mt-3">Once you click on this button certificate will dispatch</div>
            </div>
          </div>
          {this.state.loader === true ? <HFNLoading /> : <></>}
          {
            this.state.fileName !== '' ?
            <HFNModalPopup>
              <div className="p-d-flex p-flex-wrap p-my-3">
                <div className="p-col-12 p-d-flex p-flex-wrap p-mx-5">
                  <iframe width="1050" height="800" src={this.state.imageSrc}></iframe>
                </div>
                <div className="form-button-group">
                <Button 
                  type="button" 
                  className='p-button p-button-primary p-mr-2' 
                  label="Ok" 
                  onClick={() => { 
                    this.setState(() => { modalPopup.toggle(false) })
                    confirmDialog({
                      message: `This is an one time process, are you sure want to proceed?`,
                      header: "Confirm",
                      className: 'module-confirm-popup',
                      accept: () => {
                        this.dispatchCertificate()
                      }
                    });
                  }} 
                />
                <Button 
                  type="button" 
                  className='p-button p-button-secondary p-mr-2' 
                  label="Cancel" 
                  onClick={() => { modalPopup.toggle(false) }} 
                />
                </div>
              </div>
            </HFNModalPopup> : null
          }
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  ld: state.dropdownDetails
});

export default connect(mapStateToProps)(Certificate);