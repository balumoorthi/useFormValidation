import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils
import buildBreadcrumb from "utils/breadcrumb";

import { getModuleAccess, getUserType } from 'utils/common';

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

// components
// import ParticipantCertificate from 'components/college/collegeDetails/program/participant/ParticipantCertificate';

import Participants from 'components/college/collegeDetails/program/participant/ParticipantListing';

// prime components
import { TabView, TabPanel } from 'primereact/tabview';

// services
import CollegeService from "services/college/college.service";

class Participant extends Component {

  constructor(props) {

    super(props);

    // variable init start 
    this.collegeService = new CollegeService();

    const module = getModuleAccess("PARTICIPANTS") || {};
    this.moduleAccess = module.access || [];
    // variable init end

    // state management start

    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Participant", url: "", },
      ],

      collegeID: this.props.match.params.collegeID,

      programID: this.props.match.params.programID,

      sessionID: this.props.match.params.sessionID,

      participantUploadForm: {
        isEditable: false,
        initValue: this.participantUploadFormInitValue
      }
    }

    // state management end
  }

  getCollegeDetail = async () => {
    let collegeID = this.state.collegeID;
    let programID = this.state.programID;
    try {
      if (collegeID && programID) {
        const apiResponse = await response.get(
          {
            service: this.collegeService,
            method: 'getCollege',
            data: { itemId: collegeID }
          });

        if (apiResponse && apiResponse.data) {
          const apiResponseData = apiResponse.data;

          if (!apiResponseData.isError) {

            if (apiResponseData.data) {
              const breadCrub = [
                { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
                { label: "College List", url: "college/listing" },
                { label: `${apiResponseData.data.label ? apiResponseData.data.label : "College"}`, url: `college/details/${collegeID}` },
                { label: "Session", url: `college/${collegeID}/program/${programID}/session` },
                { label: "Participant", url: "" },
              ];
              if (getUserType() === "CS") {
                breadCrub.shift();
              }
              let participantBreadcrumbs = breadCrub;
              buildBreadcrumb(this.props, participantBreadcrumbs)
            }

          }
        }
      }
    } catch (err) {
      console.log(err)
    }

  }

  componentDidMount() {
    let programID = this.state.programID, participantBreadcrumbs;

    if (this.props.match.path === '/college/:collegeID/program/:programID/session/:sessionID/participant') {
      this.getCollegeDetail();
    }
    if (programID && (this.props.match.path === '/program/:programID/session/:sessionID/participant')) {
      const breadCrub = [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Program List", url: "program/listing" },
        { label: "Session", url: `program/${programID}/session` },
        { label: "Participant", url: "" },
      ];
      if (getUserType() === "CS") {
        breadCrub.shift();
      }
      participantBreadcrumbs = breadCrub;
      buildBreadcrumb(this.props, participantBreadcrumbs)
    }
    else if (programID && (this.props.match.path === '/mycollege/program/:programID/session/:sessionID/participant')) {
      const breadCrub = [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "My College", url: "mycollege" },
        { label: "Session", url: `mycollege/program/${programID}/session` },
        { label: "Participant", url: "" }
      ]
      if (getUserType() === "CS") {
        breadCrub.shift();
      }
      participantBreadcrumbs = breadCrub;

      buildBreadcrumb(this.props, participantBreadcrumbs)
    }
    else {
      buildBreadcrumb(this.props, this.state.breadcrumbs);
    }

    dropdown.participantConfigType();
  }

  render() {
    return (
      <div className='p-card'>
        <div className='tab-section'>
          {
            ((getUserType() !== "U") || this.moduleAccess.includes("dispatcher"))
              ?
              <TabView>
                <TabPanel header="Participant upload">
                  <Participants sessionID={this.state.sessionID} collegeID={this.state.collegeID} programID={this.state.programID}/>
                </TabPanel>
                {/* <TabPanel header="Dispatch Certificates">
                  <ParticipantCertificate programID={this.state.programID} sessionID={this.state.sessionID} />
                </TabPanel> */}
              </TabView>
              :
              <TabView>
                <TabPanel header="Participant upload">
                  <Participants />
                </TabPanel>
              </TabView>
          }
        </div>
      </div>
    )
  }
}

export default withRouter(connect()(Participant));

