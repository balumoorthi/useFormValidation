import React, { Component } from 'react';

import { withRouter } from 'react-router';
// utils 
import { response } from "utils/response";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { certificateSentBadge, createdDateBadge } from "utils/badgeTemplate";

import { getModuleAccess, getUserType, getUserRole } from 'utils/common';

// components
import ParticipantForm from 'components/college/collegeDetails/program/participant/ParticipantForm';

import ParticipantUploadForm from 'components/college/collegeDetails/program/participant/ParticipantUploadForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import ParticipantService from 'services/college/participant.service';

import { Dialog } from 'primereact/dialog';

import { Button } from 'primereact/button';

import SessionService from 'services/session/session.service';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class ParticipantListing extends Component {

  constructor(props) {

    super(props);

    // variable init start 
    this.participantService = new ParticipantService();

    this.sessionService = new SessionService();

    this.participantTable = React.createRef(null);

    this.participantFormInitValue = {
      participant_name: null,
      participant_contact_number: null,
      participant_email_id: null,
      certificate_sent: null,
      photo: null,
      session_id: this.props.sessionID
    }

    const module = getModuleAccess("PARTICIPANTS") || {};
    this.moduleAccess = module.access || [];
    // variable init end

    localStorage.setItem('moduleName', 'participant');

    // state management start
    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['participant'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      participantForm: {
        isEditable: false,
        initValue: this.participantFormInitValue,
      },

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("PARTICIPANTS"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
        },

        url: this.participantService,

        method: 'getParticipantList',

        params: {
          session_id: this.props.sessionID
        },

        columns: [
          {
            header: 'Name',
            field: 'participant_name',
            sortable: true,
            filter: true
          },
          {
            header: 'Email',
            field: 'participant_email_id',
            sortable: true,
            filter: true,
            transformValue: false
          },
          {
            header: 'Mobile',
            field: 'participant_contact_number',
            sortable: true,
            filter: true,
          },
          {
            header: 'Certificate Sent',
            field: 'certificate_sent',
            sortable: true,
            body: certificateSentBadge,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'bulkUpload',
            onClick: this.editParticipant
          },
          {
            type: 'bulkUpload',
            onClick: (ev, rowdata) => {
              let participantID = rowdata.participant_id;
              if (participantID) {
                confirmDialog.toggle(true)
                confirmDialog.custom({
                  message: "Are you sure you want to delete this participant?",
                  accept: () => { this.removeParticipant(rowdata.participant_id) }
                });
              }
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Participant List',
          rightBtnsOptions: [
            {
              type: 'bulkUpload',
              onClick: this.setparticipantFormInitValue,
              classNames: "addParticipant"
            }
          ]
        }

      },

      // datatables 

    }
    // state management end
  }

  setparticipantFormInitValue = () => {
    this.setState({
      participantForm: {
        ...this.state.participantForm,
        initValue: this.participantFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Add Participant', className: "sdm-popup" })
      })
  }

  editParticipant = (ev, rowdata) => {
    this.setState({
      participantForm: {
        ...this.state.participantForm,
        initValue: {
          participant_id: rowdata.participant_id,
          participant_name: rowdata.participant_name,
          participant_contact_number: rowdata.participant_contact_number,
          participant_email_id: rowdata.participant_email_id,
          certificate_sent: rowdata.certificate_sent,
          session_id: rowdata.session_id
        },
        isEditable: true
      }
    }, () => {
      modalPopup.toggle(true)
      modalPopup.custom({ header: 'Update Participant', className: "sdm-popup" })
    })
  }

  removeParticipant = async (id) => {
    if (id) {
      await response.remove({
        service: this.participantService,
        method: 'removeParticipant',
        data: { itemId: id },
        dataTable: this.participantTable,
      })
    }
  }

  trainerAssigend = async () => {
    try{
    let apiResponse, apiResponseData;

    apiResponse = await response.get({
      service: this.sessionService,
      method: 'getSession',
      data: { itemId: this.props.sessionID },
    })
    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      apiResponseData = apiResponse.data.data;
      if (apiResponseData.trainers.length === 0) {
        this.setState({ backtoSession: true })
      }
    }
  }catch(err){
    console.log(err)
  }
  }
  backToSessionList = () => {
    const { collegeID, programID } = this.props
    this.props.history.push(`/college/${collegeID}/program/${programID}/session`)
  }
  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    this.trainerAssigend();
  }

  render() {
    const footer = (
      <Button
        label="Back to session list"
        icon=""
        className='p-button-primary p-mr-2'
        onClick={() => { this.backToSessionList() }}
      />)
    return (
      <div>
        {
          ((getUserType() !== "U") || this.moduleAccess.includes("bulkUpload"))
            ?
            <ParticipantUploadForm dataTableRef={this.participantTable} sessionID={this.props.sessionID} />
            :
            <></>
        }
        <HFNDataTable ref={this.participantTable} options={this.state.options} />
        <HFNModalPopup>
          <ParticipantForm initialValue={this.state.participantForm} dataTableRef={this.participantTable} />
        </HFNModalPopup>
        {
          this.state.backtoSession &&
          <Dialog
            showHeader={true}
            footer={footer}
            header="Trainer not assigned"
            onHide={()=> {}}
            visible={true}>
            <p>Please assign a trainer before adding participants</p>
          </Dialog>
        }
      </div>
    );
  }
}

export default withRouter(ParticipantListing);