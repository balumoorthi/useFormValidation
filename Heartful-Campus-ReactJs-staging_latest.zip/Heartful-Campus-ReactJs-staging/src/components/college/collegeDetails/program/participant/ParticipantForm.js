import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from 'utils/common';

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import ParticipantService from 'services/college/participant.service';

const ParticipantForm = props => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const participantService = new ParticipantService()
  // variable init end

  // state management start

  // validations start
  const [formFields] = useState({
    participant_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    participant_email_id: {
      properties: {
        type: 'InputText',
        label: 'Email',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
          pattern: validations.email,
        }
      }
    },
    participant_contact_number: {
      properties: {
        type: 'PhoneInput',
        label: 'Mobile',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {},
        validations: {
          required: validations.required,
        }
      }
    },
    photo: {
      properties: {
        type: 'FileUpload',
        label: 'Photo',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
          accept: ".png, .jpeg, .jpg"
        },
      }
    },
  });
  // validations end

  // state management end

  // Participant form section start 

  // form submit section start

  const participantFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      formData = getUserName(isEditable, formData)
      addUpdateParticipant(formData)
    }
  }

  // form submit section end

  // add new and update Participant section start
  const addUpdateParticipant = async (data) => {

    const formData = new FormData();

    Object.keys(data).forEach(key => {
      (!isEditable && key === "photo") ? formData.append(key, data[key][0] || null) : formData.append(key, data[key]);
    });

    if (isEditable) {
      formData.append("_method", "PUT");
    }


    if (!isEditable) {
      await response.add({
        service: participantService,
        method: 'addParticipant',
        data: { item: formData },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: participantService,
        method: 'updateParticipant',
        data: { itemId: initValue.participant_id, item: formData },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update Participant section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={formFields} onFormSubmit={participantFormOnsubmit} />
    </div>
  );
}

export default ParticipantForm;
