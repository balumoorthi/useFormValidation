import React, { useState } from "react";

// components 
// prime components 
import { Button } from 'primereact/button';

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { isEmpty } from 'lodash';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getUserName } from 'utils/common';

// services 
import ParticipantService from 'services/college/participant.service';

import csvIcon from 'assets/images/csv-file-icon.jpg';

const ParticipantUploadForm = (props) => {

  // variable init start 
  const initValue = {
    csv_file: null
  };

  const participantService = new ParticipantService()
  // variable init end

  // state management start
  // validations start
  const [participantFormFields] = useState({
    csv_file: {
      properties: {
        type: 'FileUpload',
        label: 'File Name',
        fieldWrapperClassNames: 'p-col-12 bulkUpload',
        primeFieldProps: {
          accept: ".csv"
        },
        validations: {
          required: validations.required,
        }
      }
    }
  });
  // validations end
  // state management end

  const [participantUploadFormConfig] = useState({
    formClassName: 'p-d-flex p-flex-wrap p-col-12 participantUploadForm',
    formSectionClassName: 'p-col-12 p-md-6'
  });

  // form submit section start
  const formSubmitButtonGroup = () => {
    return (
      <div className="report-button-group p-col-12 p-md-6">
        <Button type="submit" label="Save" className="p-button p-button-primary" />
      </div>
    )
  }
  // form submit section end

  // Participant form section start 
  const participantFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      uploadParticipants(formData)
    }
  }

  // add new and update Participant section start
  const uploadParticipants = async (data) => {
    const formData = new FormData();

    data.session_id = props.sessionID;
    data.created_by = getUserName();

    Object.keys(data).forEach(key => {
      (key === "csv_file") ? formData.append(key, data[key][0]) : formData.append(key, data[key]);
    });
    await response.add({
      service: participantService,
      method: 'uploadParticipantList',
      data: { item: formData },
      toasterMessage: {
        success: "File uploaded successfully",
        error: "Error in uploading file. Please try again"
      }
    });

    if (props.dataTableRef && props.dataTableRef.current) {
      props.dataTableRef.current.loadData()
    }
  }
  // add new and update Participant section end
  // Participant form section end 

  return (
    <>
      {/* <h4> Upload participants </h4>
      <br /> */}
      <p><a href="/data/sample-upload-participants.csv" download><img src={csvIcon} alt="" width="40px" height="20px" /></a> Click on the icon to download the sample CSV for import. Fill in all the required fields and upload the CSV file.</p>
      <div>
        <HFNDynamicForm
          formConfig={participantUploadFormConfig}
          initialValues={initValue}
          fields={participantFormFields}
          onFormSubmit={participantFormOnsubmit}
          submitButtonGroup={formSubmitButtonGroup}
        />
      </div>
    </>
  )
}

export default ParticipantUploadForm;