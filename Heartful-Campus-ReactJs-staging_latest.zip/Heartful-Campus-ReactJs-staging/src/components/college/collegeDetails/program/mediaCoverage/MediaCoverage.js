import React, { Component } from 'react';

// components
import MediaForm from 'components/college/collegeDetails/program/mediaCoverage/MediaForm';

// shared components
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// utils 
import { downloadFile, getUserRole } from "utils/common";

import { response } from "utils/response";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { imagetypeBadge } from "utils/badgeTemplate";

// services
import ProgramService from 'services/college/program.service';

// config
import config from 'assets/config';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

// constants
const mediaFolder = "program-media";

class MediaCoverage extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.programService = new ProgramService();

    this.mediaImageTable = React.createRef(null);

    this.mediaFormInitValue = {
      cart_id: this.props.programID,
    }
    // variable init end

    localStorage.setItem('moduleName', 'media');

    // state management start
    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['media'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      mediaForm: {
        isEditable: false,
        initValue: this.mediaFormInitValue,
      },

      // datatables

      options: {

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
        },

        url: this.programService,

        params: {
          cart_id: this.props.programID
        },

        method: 'programdocuments',

        columns: [
          {
            header: 'Image',
            field: 'document_name',
            sortField: "SortingDisabled",
            body: imagetypeBadge,
            headerStyle: {
              width: '50px',
              height: '50px'
            }
          },
        ],

        actionBtnOptions: [
          {
            icon: "pi pi-download view-icon",
            className: "p-mr-2 p-button-icon-only",
            title: "Download Media",
            onClick: this.onDownload
          },
          {
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this media?",
                accept: () => { this.removeMedia(rowData.event_doc_id) }
              })
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Media Image List',
          rightBtnsOptions: [
            {
              onClick: this.setmediaFormInitValue,
              label: 'Upload Media',
              icon: 'pi pi-plus',
              classNames: 'p-button-primary uploadMedia'
            }
          ]
        }
      }
      // datatables 

    }
    // state management end
  }

  // upload media section start
  setmediaFormInitValue = () => {
    this.setState({
      mediaForm: {
        ...this.state.mediaForm,
        initValue: this.mediaFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Upload Image', className: 'sdm-popup' })
      })
  }
  // upload media section end

  // download section start
  onDownload = (e, rowData) => {
    try {
      const downloadLink = config.mediaURL + mediaFolder + "/" + rowData.document_name;
      if (rowData.document_name) {
        downloadFile(downloadLink, rowData.document_name);
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // download section end

  // remove media section start
  removeMedia = async (id) => {
    await response.remove({
      service: this.programService,
      method: 'removeProgramdocuments',
      data: { itemId: id },
      dataTable: this.mediaImageTable,
    })
  }
  // remove media section end

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.mediaImageTable} options={this.state.options} />
        <HFNModalPopup>
          <MediaForm initialValue={this.state.mediaForm} dataTableRef={this.mediaImageTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default MediaCoverage;
