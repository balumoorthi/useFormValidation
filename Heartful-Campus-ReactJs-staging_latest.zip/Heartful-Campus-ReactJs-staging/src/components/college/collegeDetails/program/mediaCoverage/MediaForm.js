import React, { useState } from "react";

// components
// shared components
import HFNDynamicForm from "shared-components/hfn-form";

// utils
import { isEmpty } from 'lodash';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// services
import ProgramService from 'services/college/program.service';

// config
import config from 'assets/config';

const MediaUploadForm = (props) => {
  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue } = initialValue;
  // props destructure end

  // variable init start
  const programService = new ProgramService();
  // variable init end

  // state management start
  const [mediaFormFields] = useState({
    file_name: {
      properties: {
        type: 'FileUpload',
        label: 'File Name',
        fieldWrapperClassNames: 'p-col-12',
        hint: `Maximum allowed file size is ${config.maxAllowedFileSize}MB. Allowed types are jpg, jpeg and png`,
        primeFieldProps: {
          accept: ".png, .jpeg, .jpg",
        },
        validations: {
          required: validations.required
        }
      }
    }
  });
  // state management end

  // form submit section start
  const mediaFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      uploadMedia(formData)
    }
  }
  // form submit section end

  // media upload section start
  const uploadMedia = async (data) => {
    const formData = new FormData();
    formData.append("document_type", data.file_name[0].type);
    formData.append("created_by", getUserName());
    formData.append("document_name", data.file_name[0])
    formData.append("cart_id", data.cart_id)

    await response.add({
      service: programService,
      method: 'programdocumentsUpload',
      data: { item: formData },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "File uploaded successfully",
        error: "Error in uploading file. Please try again"
      }
    })
  }
  // media upload section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={mediaFormFields} onFormSubmit={mediaFormOnsubmit} />
    </div>
  )
}

export default MediaUploadForm;
