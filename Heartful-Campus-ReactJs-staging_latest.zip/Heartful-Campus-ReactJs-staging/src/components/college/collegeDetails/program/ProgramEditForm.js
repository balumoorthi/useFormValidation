import React, { useState } from "react";

// components 
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

// services 
import ProgramService from 'services/program/program.service';

import HFNLoading from "shared-components/lazyLoading/Loading";

const ProgramEditForm = props => {
  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;

  const [loading, setLoading] = useState(false)
  // props destructure end

  // variable init start 
  const programService = new ProgramService();
  // variable init end

  // state management start
  // validations start
  const [programEditFields] = useState({
    cart_name: {
      properties: {
        type: 'InputText',
        label: 'Program Name',
        visibility: isEditable,
        validations: {
          required: validations.required
        }
      }
    }
  });
  // validations end
  // state management end

  // form submit section start
  const programFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      editProgram(formData)
    }
  }

  // update session section start
  const editProgram = async (formData) => {
    setLoading(true)
    await response.update({
      service: programService,
      method: 'updateProgramName',
      data: { itemId: initValue.cart_id, item: formData },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Progam Updated Successfully",
        error: "Unable to update program"
      }
    })
    setLoading(false)
  }
  // update session section end
  // form submit section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={programEditFields} onFormSubmit={programFormOnsubmit} />
      {loading ? <HFNLoading /> : null}
    </div>
  )
}

export default ProgramEditForm;