import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { getModuleAccess, getUserType } from 'utils/common';

import { dropdown } from "utils/dropdown";

// components
import Sessions from 'components/college/collegeDetails/program/session/SessionListing';

import MediaCoverage from 'components/college/collegeDetails/program/mediaCoverage/MediaCoverage';

import Certificate from 'components/college/collegeDetails/program/session/Certificate';

import ParticipantCertificate from 'components/college/collegeDetails/program/participant/ParticipantCertificate';

import OverallParticipants from 'components/college/collegeDetails/program/participant/OverallParticipantListing';

// prime components
import { TabView, TabPanel } from 'primereact/tabview';

// services
import CollegeService from "services/college/college.service";

class Session extends Component {

  constructor(props) {

    super(props);

    // variable init start 
    this.collegeService = new CollegeService();

    const module = getModuleAccess("PROGRAM") || {};

    this.moduleAccess = module.access || [];

    const participantModule = getModuleAccess("PARTICIPANTS") || {};

    this.participantModuleAccess = participantModule.access || [];
    // variable init end

    // state management start

    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Session", url: "" },
      ],

      programID: this.props.match.params.programID,

      collegeID: this.props.match.params.collegeID
    }

    // state management end
  }

  getCollegeDetail = async () => {
    const collegeID = this.state.collegeID;
    const programID = this.state.programID;

    if (collegeID && programID) {
      const apiResponse = await response.get(
        {
          service: this.collegeService,
          method: 'getCollege',
          data: { itemId: collegeID }
        });

      if (apiResponse && apiResponse.data) {
        const apiResponseData = apiResponse.data;

        if (!apiResponseData.isError) {

          if (apiResponseData.data) {
            let participantBreadcrumbs = [
              { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
              { label: "College List", url: "college/listing" },
              { label: `${apiResponseData.data.label ? apiResponseData.data.label : "College"}`, url: `college/details/${collegeID}` },
              { label: "Session", url: `college/${collegeID}/program/${programID}/session` },
              { label: "Participant", url: "" },
            ];
            buildBreadcrumb(this.props, participantBreadcrumbs)
          }

        }
      }
    }

  }

  getCollegeDetail = async () => {
    const collegeID = this.state.collegeID;
    try {
      if (collegeID) {
        const apiResponse = await response.get({
          service: this.collegeService,
          method: 'getCollege',
          data: { itemId: collegeID }
        });

        if (apiResponse && apiResponse.data) {
          const apiResponseData = apiResponse.data;

          if (!apiResponseData.isError) {
            if (apiResponseData.data) {
              let pageBreadcrumbs = [
                { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
                { label: "College List", url: "college/listing" },
                { label: `${apiResponseData.data.label ? apiResponseData.data.label : "College"}`, url: `college/details/${collegeID}` },
                { label: "Sessions", url: "" },
              ];
              buildBreadcrumb(this.props, pageBreadcrumbs)
            }
          }
        }
      }
    } catch (err) {
      console.log(err)
    }
  }

  componentDidMount() {
    let pageBreadcrumbs;
    if (this.props.match.path === '/college/:collegeID/program/:programID/session') {
      this.getCollegeDetail();
    }
    if (this.props.match.path === '/program/:programID/session') {
      const breadCrub = [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Program List", url: "program/listing" },
        { label: "Sessions", url: "" }
      ]

      if (getUserType() === "CS") {
        breadCrub.shift()
      }
      pageBreadcrumbs = breadCrub
      buildBreadcrumb(this.props, pageBreadcrumbs)
    }
    else if (this.props.match.path === '/mycollege/program/:programID/session') {

      const breadCrub = [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "My College", url: "mycollege" },
        { label: "Sessions", url: "" }
      ]

      if (getUserType() === "CS") {
        breadCrub.shift()
      }

      pageBreadcrumbs = breadCrub;
      buildBreadcrumb(this.props, pageBreadcrumbs)
    }
    else {
      buildBreadcrumb(this.props, this.state.breadcrumbs);
    }
    dropdown.assetCategory();
    dropdown.fontFamily();
    dropdown.certificateLevel();
    dropdown.participantConfigType();
  }

  render() {
    return (
      <div className='p-card'>
        <div className='tab-section'>
          {
            ((getUserType() !== "U") || (this.moduleAccess.includes("mediaUpload") && this.moduleAccess.includes("certificateUpload") && this.participantModuleAccess.includes("dispatcher"))) 
            ?
              <TabView>
                <TabPanel header="Sessions">
                  <Sessions collegeID={this.state.collegeID} programID={this.state.programID} />
                </TabPanel>
                <TabPanel header="Media Coverage">
                  <MediaCoverage programID={this.state.programID} />
                </TabPanel>
                <TabPanel header="Certificate">
                  <Certificate programID={this.state.programID} />
                </TabPanel>
                <TabPanel header="Dispatch Certificates">
                  <ParticipantCertificate programID={this.state.programID} />
                </TabPanel>
                {(getUserType() === "CS") || (this.participantModuleAccess.includes("overallParticipant")) 
                ?
                <TabPanel header="Participants">
                  <OverallParticipants programID={this.state.programID}/>
                </TabPanel>
                :
                <></>
                }
              </TabView>
            :
            ((getUserType() !== "U") || (this.moduleAccess.includes("mediaUpload") && this.moduleAccess.includes("certificateUpload")))
              ?
              <TabView>
                <TabPanel header="Sessions">
                  <Sessions collegeID={this.state.collegeID} programID={this.state.programID} />
                </TabPanel>
                <TabPanel header="Media Coverage">
                  <MediaCoverage programID={this.state.programID} />
                </TabPanel>
                <TabPanel header="Certificate">
                  <Certificate programID={this.state.programID} />
                </TabPanel>
              </TabView>
              :
              <>
                {
                  (this.moduleAccess.includes("mediaUpload") || this.moduleAccess.includes("certificateUpload"))
                    ?
                    <TabView>
                      <TabPanel header="Sessions">
                        <Sessions collegeID={this.state.collegeID} programID={this.state.programID} />
                      </TabPanel>
                      {
                        (this.moduleAccess.includes("mediaUpload"))
                          ?
                          <TabPanel header="Media Coverage">
                            <MediaCoverage programID={this.state.programID} />
                          </TabPanel>
                          :
                          <TabPanel header="Certificate">
                            <Certificate programID={this.state.programID} />
                          </TabPanel>
                      }
                    </TabView>
                    :
                    <TabView>
                      <TabPanel header="Sessions">
                        <Sessions collegeID={this.state.collegeID} programID={this.state.programID} />
                      </TabPanel>
                    </TabView>
                }
              </>
          }
        </div>
      </div>
    )
  }
}

export default withRouter(connect()(Session));