import React, { Component } from 'react';

import { withRouter } from "react-router";

// components
import SessionForm from 'components/college/collegeDetails/program/session/SessionForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// utils 
import { response } from "utils/response";

import { sessionDateBadge, createdDateBadge, gotoPage, participantCountBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { getModuleAccess, getUserType, getUserRole } from 'utils/common';

import { dropdown } from 'utils/dropdown';

import { toaster } from "utils/toaster";

// services 
import SessionService from 'services/session/session.service';

import ProgramService from 'services/college/program.service';

import SessionEditForm from './SessionEditForm';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class Sessions extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.sessionService = new SessionService();

    this.programService = new ProgramService();

    this.sessionTable = React.createRef(null);

    const moduleAccess = getModuleAccess("SESSION") || {};
    const enableViewLink = Array.isArray(moduleAccess.access) ? moduleAccess.access.includes("view") : false;
    // variable init end

    localStorage.setItem('moduleName', 'session');

    // state management start
    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['session'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      sessionForm: {
        initValue: {},
        isEditable: true
      },
      sessionEdit: {
        initValue: {
        },
        isEditable: true
      },
      bulkUpload: false,

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("SESSION")
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
          frozenColumns: 9
        },

        url: this.sessionService,

        method: 'getSessions',

        params: {
          cart_id: this.props.programID
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'modules.module_name',
            filterField: "module_id",
            sortField: "SortingDisabled",
            filter: true,
            filterElementOptions: {
              type: 'Dropdown',
              value: "moduleList",
              primeFieldProps: {
                className: "p-inputtext-sm",
                filter: true,
              }
            },
            headerStyle: {
              width: '200px'
            },
            body: enableViewLink ? (rowData, { field }) => { return gotoPage(rowData, field, this.viewParticipants) } : null
          },
          {
            header: 'Program',
            field: 'cart_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'College',
            field: 'college_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Participants',
            field: 'participant_count',
            sortable: true,
            body: participantCountBadge,
            headerStyle: {
              width: '175px'
            }
          },
          {
            header: 'Start Date',
            field: 'event_start_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat: "YYYY-MM-DD",
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge
          },
          {
            header: 'End Date',
            field: 'event_end_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat: "YYYY-MM-DD",
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge
          },
          {
            header: 'Trainer',
            field: 'trainer_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '120px'
            },
            body: createdDateBadge
          }
        ],

        actionBtnOptions: [
          {
            type: 'delete',
            onClick: this.editSessionDate,
            visibilityCheck: rowData => (new Date(rowData.event_end_date) < new Date()) ? true : false,
            visibility: (getUserType() === "U") ? "true" : false
          },
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-mr-2 p-button-icon-only",
            title: "View Participants",
            onClick: this.viewParticipants
          },
          {
            type: 'create',
            icon: "pi pi-user edit-icon",
            className: "p-mr-2 assignTrainer",
            title: 'Assign Trainer',
            onClick: this.editSessionTrainer,
            visibilityCheck: rowData => ((new Date() > new Date(rowData.event_end_date)) || (rowData.user_info_id === null && rowData.status.status_slug === "completed") || (rowData.user_info_id === null && new Date() < new Date(rowData.event_end_date) ) ? true : false),
            visibility: (getUserType() === "U" || getUserType() === "POC") ? "true" : false
          },
          {
            type: 'create',
            icon: "pi pi-user-plus edit-icon",
            className: "p-mr-2",
            title: 'Add Participant Count',
            onClick: this.addParticipantCount,
            visibilityCheck: rowData => (this.state.bulkUpload || rowData.status.status_slug !== "completed") ? false : true,
            visibility: (getUserType() === "U") ? "true" : false
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            className: "p-mr-23",
            title: 'Delete Session',
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true)
              confirmDialog.custom({
                message: "Are you sure you want to delete this session?",
                accept: () => { this.removeSession(rowdata.session_id) }
              })
            },
            visibility: (getUserType() === "U") ? "true" : false
          }
        ],

        toolBarBtnOptions: {
          title: 'Session List',
          rightBtnsOptions: [
            {
              className: "p-text-right",
              classNames: "sessionCreation",
              title: 'Add Sessions',
              onClick: this.addSession
            }
          ]
        }
      },
      // datatables 

      program: null

    }
    // state management start
  }


  editSessionDate = (ev, rowdata) => {
    this.setState({
      sessionOpen:true,
      sessionEdit: {
        ...this.state.sessionEdit,
        initValue: {
          event_start_date: new Date(rowdata.event_start_date),
          event_end_date: new Date(rowdata.event_end_date),
          session_id: rowdata.session_id,
        },
        isEditable: true
      }
    }, () => {
      modalPopup.toggle(true)
      modalPopup.custom({ header: 'Update Session', className: "sdm-popup" })
    })
  }
  // get program details section start
  getProgram = async () => {
    const programID = this.props.programID;

    try {
      if (programID) {
        const apiResponse = await response.get({
          service: this.programService,
          method: 'getProgram',
          data: { itemId: programID }
        });

        if (apiResponse && apiResponse.data) {
          const apiResponseData = apiResponse.data;

          if (!apiResponseData.isError) {
            if (apiResponseData.data) {
              this.setState({ program: apiResponseData.data });
              this.setState({ session: apiResponseData.data.sessions});
              if(this.state.session.find(data => data.status_id === 12))
                this.setState({ bulkUpload: true});
              else
                this.setState({ bulkUpload: false});
            }
          }
        }
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // get program details section end

  // add session section start
  addSession = () => {
    if (!this.state.program) {
      toaster.error("Program details is being retieved or unavailable. Session can not be added now");
      return;
    }

    if ((this.state.program.status_id !== 2) && (this.state.program.status_id !== 3)) {
      toaster.info("Session can not be added to this Program");
      return;
    }

    dropdown.sessionModule(this.props.programID);
    this.setState({
      sessionForm: {
        ...this.state.sessionForm,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'add session', className: 'sdm-popup' });
      })
  }
  // add session section end

  // view session section start
  viewParticipants = (ev, rowdata) => {
    let collegeID = rowdata.college_id || this.props.collegeID;
    let programID = this.props.programID;
    let sessionID = rowdata.session_id;
    if (rowdata.user_info_id === null) {
      toaster.info("Please assign a trainer before adding participants")
      return
    }
    if (getUserType() === "CS") {
      if (sessionID && programID)
        this.props.history.push(`/mycollege/program/${programID}/session/${sessionID}/participant`);
    }
    else {
      if (this.props.match.path === '/college/:collegeID/program/:programID/session') {
        if (collegeID && programID && sessionID)
          this.props.history.push(`/college/${collegeID}/program/${programID}/session/${sessionID}/participant`);
      }
      else if (this.props.match.path === '/program/:programID/session') {
        if (programID && sessionID)
          this.props.history.push(`/program/${programID}/session/${sessionID}/participant`);
      }
    }
  }
  // view session section end

  // edit session section start
  editSessionTrainer = (ev, rowdata) => {
    this.setState({sessionOpen:false})
    let data;
    if(rowdata.status.status_slug === "completed"){
      // data={ user_id: rowdata.user_info_id }
    } else{
      data={ user_id: rowdata.user_info_id, session_id: rowdata.session_id }
      dropdown.trainer(data);
    }
    this.setState({
      sessionForm: {
        initValue: {
          session_id: rowdata.session_id,
          user_info_id: rowdata.user_info_id
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Assign Trainer', className: "sdm-popup trainer-assign" });
      }
    )
  }
  // edit session section end

  // add participant section start
  addParticipantCount = (ev, rowdata) => {
    this.setState({sessionOpen:true})
    this.setState({
      sessionEdit: {
        initValue: {
          session_id: rowdata.session_id,
          manual_participant_count: rowdata.manual_participant_count
        },
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Add Participant Count', className: "sdm-popup" });
      }
    )
  }
  // add participant section end

  // remove session section start
  removeSession = async (id) => {
    await response.remove({
      service: this.sessionService,
      method: 'removeSession',
      data: { itemId: id },
      dataTable: this.sessionTable
    })
  }
  // remove session section end

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    dropdown.moduleList();
    dropdown.trainer({});
    this.getProgram();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.sessionTable} options={this.state.options} bulk={this.state.bulkUpload}/>
        <HFNModalPopup>
          {this.state.sessionOpen ? 
          <SessionEditForm  initialValue={this.state.sessionEdit} dataTableRef={this.sessionTable}/>:
          <SessionForm initialValue={this.state.sessionForm} programID={this.props.programID} dataTableRef={this.sessionTable} />}
        </HFNModalPopup>
      </div>
    )
  }
}

export default withRouter(Sessions);
