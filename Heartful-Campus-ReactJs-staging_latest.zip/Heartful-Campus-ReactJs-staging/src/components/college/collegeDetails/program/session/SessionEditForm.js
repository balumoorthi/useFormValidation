import React, { useState } from "react";

// components 
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import moment from 'moment';

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { toaster } from 'utils/toaster';

// services 
import SessionService from 'services/session/session.service';

import HFNLoading from "shared-components/lazyLoading/Loading";

const SessionEditForm = props => {
  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;

  const [loading, setLoading] = useState(false)
  // props destructure end

  // variable init start 
  const sessionService = new SessionService();
  // variable init end

  // state management start
  // validations start
  const [sessionEditFields] = useState({
    event_start_date: {
      properties: {
        type: 'Calendar',
        label: 'Start Date',
        visibility: isEditable,
        primeFieldProps: {
          showTime: true,
          hourFormat: "12",
          maxDate: new Date()
        },
        validations: {
          required: validations.required
        }
      }
    },
    event_end_date: {
      properties: {
        type: 'Calendar',
        label: 'End Date',
        visibility: isEditable,
        primeFieldProps: {
          showTime: true,
          hourFormat: "12",
          maxDate: new Date()
        },
        validations: {
          required: validations.required
        }
      }
    },
    manual_participant_count: {
      properties: {
        type: 'InputText',
        label: 'Add Participant Count',
        visibility: !isEditable,
        validations: {
          required: validations.required,
          pattern: validations.number
        }
      }
    }
  });
  // validations end
  // state management end

  // form submit section start
  const sessionFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      if (isEditable === true) {
        editSession(formData)
      } else {
        if (formData.session_id !== '' && formData.session_id !== undefined) {
          addParticipantCountSession(formData)
        } else {
          addParticipantCountProgram(formData)
        }
      }
    }
  }

  // update session section start
  const editSession = async (formData) => {
    const checkDate = (start, end) => {
      var mStart = moment(start);
      var mEnd = moment(end);
      return mStart.isBefore(mEnd);
    }

    let isValidDate = checkDate(formData.event_start_date, formData.event_end_date);

    if (!isValidDate) {
      toaster.error(`The end date should be greater than start date`);
      return;
    }

    setLoading(true)
    await response.update({
      service: sessionService,
      method: 'updateSession',
      data: { itemId: initValue.session_id, item: formData },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Session Updated Successfully",
        error: "Unable to assign trainer"
      }
    })
    setLoading(false)
  }
  // update session section end

  // add participant count start
  const addParticipantCountSession = async (formData) => {
    setLoading(true)
    const data = {
      manual_participant_count: formData.manual_participant_count
    }
    await response.update({
      service: sessionService,
      method: 'updateSession',
      data: { itemId: initValue.session_id, item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Successfully participant count added",
        error: "Unable to add participant count"
      }
    })
    setLoading(false)
  }

  const addParticipantCountProgram = async (formData) => {
    setLoading(true)
    const data = {
      cart_name: formData.cart_name,
      manual_participant_count: formData.manual_participant_count
    }
    await response.update({
      service: sessionService,
      method: 'updateProgram',
      data: { itemId: initValue.cart_id, item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Successfully participant count added",
        error: "Unable to add participant count"
      }
    })
    setLoading(false)
  }
  // add participant count end
  // form submit section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={sessionEditFields} onFormSubmit={sessionFormOnsubmit} />
      {loading ? <HFNLoading /> : null}
    </div>
  )
}

export default SessionEditForm;