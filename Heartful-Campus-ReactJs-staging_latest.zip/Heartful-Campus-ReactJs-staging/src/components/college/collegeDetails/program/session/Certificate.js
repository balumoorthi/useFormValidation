import React, { Component } from "react";

// state 
import { connect } from "react-redux";

// components 
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// prime components 
import { Button } from 'primereact/button';

import { InputText } from 'primereact/inputtext';

import { Dropdown } from 'primereact/dropdown';

import { Calendar } from 'primereact/calendar';

// utils
import { isEmpty, isString } from 'lodash';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getResponseMessage, getUserName, getUserRole } from "utils/common";

import { toaster } from "utils/toaster";

import { galleryPopup } from "utils/galleryPopup";

import moment from 'moment';

// services 
import ProgramService from 'services/college/program.service';

// config
import config from 'assets/config';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

// constants
const certificate_folder = "digital-asset";

class Certificate extends Component {

  constructor(props) {

    super(props);

    // variable init start 
    this.programService = new ProgramService()

    this.certificateRef = React.createRef();
    // variable init end

    localStorage.setItem('moduleName', 'certificate');

    // state management start
    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['certificate'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      formConfig: {
        formClassName: "p-col-12 p-md-6 certificate-upload-form",
      },
      fileName: '',

      certificateFormFields: {
        certificate_template: {
          properties: {
            type: 'FileUpload',
            label: 'Certificate Template',
            fieldWrapperClassNames: 'p-col-12 certificate-upload-box',
            hint: `Maximum allowed file size is ${config.maxAllowedFileSize}MB. Allowed types are jpg, jpeg and png`,
            primeFieldProps: {
              accept: ".jpg,.png,.jpeg"
            },
            validations: {
              required: validations.required,
            }
          }
        }
      },

      programData: {},

      position: {
        x: "",
        y: ""
      },
      selectedFontFamily: null,
      selectedFont: null,
      selectedFontFamilyColor: null,
      openPreview: false,
      loader: false,
      programName: "",
      sessionStartDate: new Date(),
      sessionEndDate: new Date(),
      certificateIssueDate: new Date(),
      certificateLevel: "",
      collegeName: "",
      collegeCity: "",
      collegeState: "",
      hiddenCertificateLevel: ""
    }
    // state management end
  }

  // get program info start
  getProgram = async () => {
    let apiResponse, apiResponseData, totalSessions;

    apiResponse = await response.get({
      service: this.programService,
      method: 'getProgram',
      data: { itemId: this.props.programID },
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      apiResponseData = apiResponse.data.data;
      if (apiResponseData && apiResponseData.certificate_template) {
        totalSessions = apiResponseData.sessions.length;
        this.setState({
          programData: apiResponseData,
          selectedFontFamily: apiResponseData.cert_font !== null ? apiResponseData.cert_font : "",
          selectedFontFamilyColor: apiResponseData.cert_font_color !== null ? (apiResponseData.cert_font_color.slice(1)) : "",
          selectedFont: apiResponseData.cert_font_size !== null ? apiResponseData.cert_font_size : "",
          programName: apiResponseData.program_name !== null ? apiResponseData.program_name : 'HELM',
          sessionStartDate: apiResponseData.session_start_date !== null ? new Date(apiResponseData.session_start_date) : new Date(apiResponseData.sessions[0].event_start_date),
          sessionEndDate: apiResponseData.session_end_date !== null ? new Date(apiResponseData.session_end_date) : new Date(apiResponseData.sessions[totalSessions-1].event_end_date),
          certificateLevel: apiResponseData.certificate_level !== null ? apiResponseData.certificate_level : "",
          collegeName: apiResponseData.certificate_college_name !== null ? apiResponseData.certificate_college_name : apiResponseData.colleges.label,
          collegeCity: apiResponseData.certificate_college_city !== null ? apiResponseData.certificate_college_city : apiResponseData.colleges.city,
          collegeState: apiResponseData.certificate_college_state !== null ? apiResponseData.certificate_college_state : apiResponseData.colleges.state,
          certificateIssueDate: apiResponseData.certificate_issue_date !== null ? new Date(apiResponseData.certificate_issue_date) : new Date() 
        }, () => {
          let dropdownOptions = this.props.ld.certificateLevel;
          var result = dropdownOptions.filter(options => options.value === apiResponseData.certificate_level);
          if(result.length === 0) {
            this.setState({
              certificateLevel: 'Others', 
              hiddenCertificateLevel: apiResponseData.certificate_level
            })
          }
        });
      }
    }
    else {
      toaster.error(getResponseMessage(apiResponseData) || "Unable to get program info")
    }
  }
  // get program info end

  // form submit section start

  formSubmitButtonGroup = () => {
    return (
      <div className="certificate-button-group">
        <Button type="submit" label="Save" className="p-button p-button-primary" />
      </div>
    )
  }

  certificateFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      this.uploadCertificate(data)
    }
  }

  // form submit section end

  // select certificate from gallery section start
  selectFromGallery = (ev, rowData) => {
    this.setState({ processingModule: rowData },
      () => {
        galleryPopup.toggle(true);
        galleryPopup.custom({ onAttachmentCopy: (attachment) => { this.attachCertificate(attachment) } })
      })
  }

  attachCertificate = async (attachment) => {
    let certificateData = {
      id: this.props.programID,
      certificate_template: attachment.file_name,
      upload_from_gallery: true,
      updated_by: getUserName()
    };

    let apiResponse = await response.add({
      service: this.programService,
      method: 'attchCertificateFromGallery',
      data: { item: certificateData },
      toasterMessage: {
        success: "File uploaded successfully",
        error: "Error in uploading file. Please try again"
      }
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      const programData = apiResponse.data.data;
      let totalSessions;
      if (programData && programData.certificate_template) {
        totalSessions = programData.sessions.length;
        this.setState({ 
          programData: programData,
          programName: programData.program_name !== null ? programData.program_name : 'HELM',
          sessionStartDate: programData.session_start_date !== null ? new Date(programData.session_start_date) : new Date(programData.sessions[0].event_start_date),
          sessionEndDate: programData.session_end_date !== null ? new Date(programData.session_end_date) : new Date(programData.sessions[totalSessions-1].event_end_date),
          certificateLevel: programData.certificate_level !== null ? programData.certificate_level : "",
          collegeName: programData.certificate_college_name !== null ? programData.certificate_college_name : programData.colleges.label,
          collegeCity: programData.certificate_college_city !== null ? programData.certificate_college_city : programData.colleges.city,
          collegeState: programData.certificate_college_state !== null ? programData.certificate_college_state : programData.colleges.state 
        })
      }
      galleryPopup.toggle(false);
    }
  }
  // select certificate from gallery section end

  // add new and update certificate section start
  uploadCertificate = async (data) => {
    const formData = new FormData();

    Object.keys(data).forEach(key => {
      (key === "certificate_template") ?
        formData.append(key, data[key][0]) : formData.append(key, data[key]);
    });
    formData.set('id', this.props.programID)
    formData.set('upload_from_gallery', false)
    formData.append("_method", "PUT");

    let apiResponse = await response.add({
      service: this.programService,
      method: 'uploadCertificate',
      data: { item: formData, itemId: this.props.programID },
      toasterMessage: {
        success: "File uploaded successfully",
        error: "Error in uploading file. Please try again"
      }
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      const programData = apiResponse.data.data;
      if (programData && programData.certificate_template) {
        this.setState({ programData: programData })
      }
    }
  }
  // add new and update certificate section end

  // certificate position update section start
  // position update on cick section start
  getPosition = (e) => {
    if (this.certificateRef && this.certificateRef.current && e.nativeEvent) {
      const exactWidth = this.certificateRef.current.naturalWidth;
      const exactHeight = this.certificateRef.current.naturalHeight;
      const currentWidth = this.certificateRef.current.offsetWidth;
      const currentHeight = this.certificateRef.current.offsetHeight;

      if (exactWidth && exactHeight && currentWidth && currentHeight) {
        const currentX = parseInt(e.nativeEvent.offsetX) ? parseInt(e.nativeEvent.offsetX) : null;
        const currentY = parseInt(e.nativeEvent.offsetY) ? parseInt(e.nativeEvent.offsetY) : null;

        if (currentX && currentY && /^\d+$/.test(currentX) && /^\d+$/.test(currentY)) {
          const exactX = (exactHeight / currentHeight) * currentX
          const exactY = (exactWidth / currentWidth) * currentY
          const positionLeft = (exactX / exactWidth) * 100;
          const positionTop = (exactY / exactHeight) * 100;

          this.setState({
            position: {
              ...this.state.position,
              x: Math.ceil(exactX),
              y: Math.ceil(exactY),
              positionLeft: (positionLeft > 0 && positionLeft < 100) ? positionLeft : "",
              positionTop: (positionTop > 0 && positionTop < 100) ? positionTop : ""
            }
          })
        }
      }
    }
  }
  // position update on cick section end

  // position update on image load section start
  setPosition = () => {
    if (this.certificateRef && this.certificateRef.current) {
      let positionX, positionY, positionLeft, positionTop;
      const programData = this.state.programData;
      const exactWidth = this.certificateRef.current.naturalWidth;
      const exactHeight = this.certificateRef.current.naturalHeight;

      if ((programData.cert_x_position || programData.cert_x_position === 0) && (programData.cert_y_position || programData.cert_y_position === 0)) {
        positionX = programData.cert_x_position;
        positionY = programData.cert_y_position;
        if (exactWidth && exactHeight) {
          positionLeft = (positionX / exactWidth) * 100;
          positionTop = (positionY / exactHeight) * 100;
        }
      }
      this.setState({
        position: {
          x: positionX || "",
          y: positionY || "",
          exactWidth: exactWidth || "",
          exactHeight: exactHeight || "",
          positionLeft: (positionLeft > 0 && positionLeft < 100) ? positionLeft : "",
          positionTop: (positionTop > 0 && positionTop < 100) ? positionTop : ""
        }
      })
    }
  }
  // position update on image load section end

  // position update on textbox input section start
  setXYPosition = (x, y) => {
    if (x || x === "0" || x === "") {
      const positionLeft = (x !== "0" && x !== "") ? ((x / this.state.position.exactWidth) * 100) : 0;
      this.setState({
        position: {
          ...this.state.position,
          x: x,
          positionLeft: (positionLeft > 0 && positionLeft < 100) ? positionLeft : "",
        }
      })
    }
    else if (y || y === "0" || y === "") {
      const positionTop = (y !== "0" && y !== "") ? ((y / this.state.position.exactHeight) * 100) : 0;
      this.setState({
        position: {
          ...this.state.position,
          y: y,
          positionTop: (positionTop > 0 && positionTop < 100) ? positionTop : ""
        }
      })
    }
  }
  // position update on textbox input section end

  // save position section start
  savePosition = async () => {
    try {
      let dateErrors = [];
      const checkDate = (start, end) => {
        var mStart = moment(start);
        var mEnd = moment(end);
        return mStart.isBefore(mEnd);
      }
      let startDate, endDate, isValidDate;

      startDate = moment(new Date(this.state.sessionStartDate)).isValid();
      endDate = moment(new Date(this.state.sessionEndDate)).isValid();
      isValidDate = checkDate(this.state.sessionStartDate, this.state.sessionEndDate);
      if (!startDate || !endDate) {
        dateErrors.push({
          item_name: 'Save Position',
          message: `The start date and duration is required for this module`
        })
      }
      else if (!isValidDate) {
        dateErrors.push({
          item_name: 'Save Position',
          message: `The end date should be greater than start date`
        });
      }
      if (dateErrors.length === 0) {
        let data = {
          cart_id: this.props.programID,
          certificate_template: this.state.programData.certificate_template,
          cert_x_position: this.state.position.x,
          cert_y_position: this.state.position.y,
          cert_font: this.state.selectedFontFamily,
          cert_font_size: this.state.selectedFont,
          cert_font_color: "#" + this.state.selectedFontFamilyColor,
          program_name: this.state.programName,
          session_start_date: moment(this.state.sessionStartDate).format("YYYY-MM-DD"),
          session_end_date: moment(this.state.sessionEndDate).format("YYYY-MM-DD"),
          certificate_issue_date: moment(this.state.certificateIssueDate).format("YYYY-MM-DD"),
          certificate_level: (this.state.hiddenCertificateLevel === '')?this.state.certificateLevel:this.state.hiddenCertificateLevel,
          certificate_college_name: this.state.collegeName,
          certificate_college_city: this.state.collegeCity,
          certificate_college_state: this.state.collegeState,
          updated_by: getUserName()
        }
        await response.add({
          service: this.programService,
          method: 'saveCertificatePosition',
          data: { item: data },
          toasterMessage: {
            success: "Position has been saved successfully",
            error: "Unable to save position"
          }
        })
      } else {
        toaster.custom({ severity: "error", summary: dateErrors[0].item_name, detail: dateErrors[0].message });
      }
    }
    catch (e){
      console.log("Something went wrong.");
    }
  }

  // save position section end
  // preview position section start
  previewCertificate = async () => {
    this.setState({ loader: true, fileName: '' })
    try {
      let dateErrors = [];
      const checkDate = (start, end) => {
        var mStart = moment(start);
        var mEnd = moment(end);
        return mStart.isBefore(mEnd);
      }
      let startDate, endDate, isValidDate;

      startDate = moment(new Date(this.state.sessionStartDate)).isValid();
      endDate = moment(new Date(this.state.sessionEndDate)).isValid();
      isValidDate = checkDate(this.state.sessionStartDate, this.state.sessionEndDate);
      if (!startDate || !endDate) {
        dateErrors.push({
          item_name: 'Preview Certificate',
          message: `The start date and duration is required for this module`
        })
      }
      else if (!isValidDate) {
        dateErrors.push({
          item_name: 'Preview Certificate',
          message: `The end date should be greater than start date`
        });
      }
      if (dateErrors.length === 0) {
        let data = {
          template_url: config.mediaURL + certificate_folder + "/" + this.state.programData.certificate_template,
          cert_x_position: this.state.position.x,
          cert_y_position: this.state.position.y,
          cert_font: this.state.selectedFontFamily,
          cert_font_size: this.state.selectedFont,
          cert_font_color: "#" + this.state.selectedFontFamilyColor,
          session_start_date: moment(this.state.sessionStartDate).format("YYYY-MM-DD"),
          session_end_date: moment(this.state.sessionEndDate).format("YYYY-MM-DD"),
          certificate_issue_date: moment(this.state.certificateIssueDate).format("YYYY-MM-DD"),
          program_name: this.state.programName,
          certificate_level: (this.state.hiddenCertificateLevel === '')?this.state.certificateLevel:this.state.hiddenCertificateLevel,
          certificate_college_name: this.state.collegeName,
          certificate_college_city: this.state.collegeCity,
          certificate_college_state: this.state.collegeState,
        }
        let apiResponse;
        let previewData;

        apiResponse = await response.add({
          service: this.programService,
          method: 'previewCertificate',
          data: { item: data },
          toasterMessage: {
            success: "Certificate is Ready to Preview",
            error: "Unable to save position"
          }
        })
        if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
          previewData = apiResponse.data.data;
          if (isString(previewData)) {
            var fileName = previewData.substring(previewData.lastIndexOf('/') + 1);
            setTimeout(() => {
              this.setState({
                imageSrc: previewData,
                fileName: fileName,
                loader: false
              })
            }, 10000);
          }
        } else {
          this.setState({ loader: false })
        }
      } else {
        toaster.custom({ severity: "error", summary: dateErrors[0].item_name, detail: dateErrors[0].message });
      }
    }
    catch {
      console.log("Something went wrong.");
    }
    // this.setState({ loader: false })
  }

  //color change start
  colorChange = (e) => {
    this.setState({
      ...this.state.selectedFontFamilyColor,
      selectedFontFamilyColor: e.target.value
    });
    e.preventDefault()
  }
  // color change end

  // preview position section end

  // certificate position update section end
  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    this.getProgram()
  }

  render() {
    return (
      <div>
        <div className="p-d-flex p-flex-wrap p-col-12">
          <HFNDynamicForm
            formConfig={this.state.formConfig}
            initialValues={{ certificate_template: null }}
            fields={this.state.certificateFormFields}
            onFormSubmit={this.certificateFormOnsubmit}
            submitButtonGroup={this.formSubmitButtonGroup}
          />
          <div className="p-col-12 p-md-6 p-text-center p-d-flex certificate-gallery-button-group p-p-2">
            <Button label="Select From Gallery" onClick={this.selectFromGallery} className="p-button p-button-primary certTemplate" />
          </div>
        </div>
        {
          (this.state.programData && this.state.programData.certificate_template)
            ?
            <div className="p-mt-6">
              <h3 className="p-my-3">Set Position</h3>
              <div className="certificate-image">
                <img
                  ref={this.certificateRef}
                  src={config.mediaURL + certificate_folder + "/" + this.state.programData.certificate_template}
                  alt="heartful-campus-certificate"
                  onLoad={this.setPosition}
                  onClick={this.getPosition}
                />
                {
                  (this.state.position.positionLeft && this.state.position.positionTop)
                    ?
                    <div
                      className="certificate-position"
                      style={{
                        left: ("calc(" + this.state.position.positionLeft + "% - 7px)"),
                        top: ("calc(" + this.state.position.positionTop + "% - 7px)")
                      }}
                    >
                      <i className="pi pi-plus"></i>
                    </div>
                    :
                    <></>
                }
              </div>

              <div className="p-d-flex p-flex-wrap p-my-6 p-mx-2">
                <div className="certificate-postion-label p-d-flex p-col-4 p-flex-wrap p-mr-4">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">College Name: </div>
                  <InputText
                    className="col1Input"
                    placeholder="College Name"
                    value={this.state.collegeName} 
                    onChange={(e) => {
                      this.setState({
                        collegeName: e.target.value
                      })
                    }}
                  />
                </div>

                <div className="certificate-postion-label p-d-flex p-col-3 p-flex-wrap p-mr-2">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">College City: </div>
                  <InputText
                    className="col1Input"
                    placeholder="College City"
                    value={this.state.collegeCity} 
                    onChange={(e) => {
                      this.setState({
                        collegeCity: e.target.value
                      })
                    }}
                  />
                </div>

                <div className="certificate-postion-label p-d-flex p-col-3 p-flex-wrap p-mr-2">
                  <div className="p-ml-2 p-mr-2">College State: </div>
                  <InputText
                    className="col1Input"
                    placeholder="College State"
                    value={this.state.collegeState} 
                    onChange={(e) => {
                      this.setState({
                        collegeState: e.target.value
                      })
                    }}
                  />
                </div>
              </div>  

              <div className="p-d-flex p-flex-wrap p-my-6 p-mx-2">
                {/* <div className="certificate-postion-label p-d-flex p-jc-center p-flex-wrap p-ml-2 p-mr-3">
                  <div className="p-ml-2 p-mr-2">X Postion: </div>
                  <InputText
                    keyfilter="pint"
                    placeholder="x"
                    value={this.state.position.x}
                    onChange={(e) => this.setXYPosition(e.target.value)}
                  />
                </div>
                <div className="certificate-postion-label p-d-flex p-jc-center p-flex-wrap p-mr-3">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Y Postion: </div>
                  <InputText
                    keyfilter="pint"
                    placeholder="y"
                    value={this.state.position.y}
                    onChange={(e) => this.setXYPosition(null, e.target.value)}
                  />
                </div> */}

                <div className="certificate-postion-label p-d-flex p-col-4 p-flex-wrap p-mr-4">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Program Name: </div>
                  <InputText
                    className="col1Input"
                    placeholder="Program Name"
                    value={this.state.programName} 
                    onChange={(e) => {
                      this.setState({
                        programName: e.target.value
                      })
                    }}
                  />
                </div>

                <div className="certificate-postion-label p-d-flex p-col-3 p-flex-wrap p-mr-2">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Program Type: </div>
                  <Dropdown
                    className="col1Input" 
                    value={(this.state.certificateLevel === ' ')? 'Others' : this.state.certificateLevel} 
                    options={this.props.ld.certificateLevel} 
                    onChange={(e) => { 
                      if(e.value !== "Others")
                        this.setState({ certificateLevel: e.value, hiddenCertificateLevel: '' }) 
                      else
                        this.setState({ certificateLevel: " " })
                    }} 
                    optionLabel="label" filter showClear filterBy="label" 
                  />
                </div>
                {
                  (this.state.certificateLevel === ' ' || this.state.certificateLevel === 'Others') ?
                <div className="certificate-postion-label p-d-flex p-col-3 p-flex-wrap p-mr-2">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Program - Certificate Display Name: </div>
                  <InputText
                    className="col1Input p-mt-2"
                    placeholder="Certificate Level"
                    value={this.state.hiddenCertificateLevel} 
                    onChange={(e) => { this.setState({ hiddenCertificateLevel: e.target.value }) }} 
                  />
                </div> : <></> }
                <p style={{fontSize: "11px", marginLeft: "10px", position: "absolute", marginTop: "80px"}}>Program Name will change in certificate, Please verify before sending</p>
              </div>

              <div className="p-d-flex p-flex-wrap p-my-6 p-mx-2">
                <div className="certificate-postion-label p-d-flex p-col-4 p-flex-wrap p-mr-4">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Certificate Issue Date: </div>
                  <Calendar 
                    className="col1Input"
                    placeholder = "Certificate Issue Date"
                    dateFormat="dd/mm/yy"
                    value={this.state.certificateIssueDate} 
                    onChange={(e) => {
                      this.setState({
                        certificateIssueDate: e.target.value
                      })
                    }}>
                  </Calendar>
                </div>

                <div className="certificate-postion-label p-d-flex p-col-3 p-flex-wrap p-mr-2">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Session Start Date: </div>
                  <Calendar 
                    className="col1Input"
                    placeholder = "Session Start Date"
                    dateFormat="dd/mm/yy"
                    value={this.state.sessionStartDate} 
                    onChange={(e) => {
                      this.setState({
                        sessionStartDate: e.target.value
                      })
                    }}>
                  </Calendar>
                </div>

                <div className="certificate-postion-label p-d-flex p-col-3 p-flex-wrap p-mr-2">
                  <div className="p-mx-md-2 p-my-md-0 p-m-2">Session End Date: </div>
                  <Calendar 
                    className="col1Input"
                    placeholder = "Session End Date"
                    dateFormat="dd/mm/yy"
                    value={this.state.sessionEndDate} 
                    onChange={(e) => {
                      this.setState({
                        sessionEndDate: e.target.value
                      })
                    }}>
                  </Calendar>
                </div>
              </div>
              {/* <div className="p-d-flex p-flex-wrap p-my-6 p-mx-2">

                <div className="certificate-postion-label p-d-flex p-jc-center p-flex-wrap p-ml-2 p-mr-3">
                  <div className="p-ml-2 p-mr-2">Font Family: </div>
                  <Dropdown value={this.state.selectedFontFamily} options={this.props.ld.fontFamily} onChange={(e) => { this.setState({ selectedFontFamily: e.value }) }} optionLabel="label" filter showClear filterBy="label" />
                </div>

                <div className="certificate-postion-label p-d-flex p-jc-center p-flex-wrap p-ml-2 p-mr-3">
                  <div className="p-ml-2 p-mr-2">Font Color: </div>
                  <InputText placeholder="Enter Color Code Only like #00FF00" value={this.state.selectedFontFamilyColor} onChange={(e) => {
                    this.colorChange(e)
                  }} />
                </div>
                <div className="certificate-postion-label p-d-flex p-jc-center p-flex-wrap p-ml-2 p-mr-3">
                  <div className="p-ml-2 p-mr-2">Font Size: </div>
                  <Dropdown options={Array.from({ length: 85 }, (_, x) => x + 16)} onChange={(e) => { this.setState({ selectedFont: e.value }) }} value={this.state.selectedFont} />
                </div>
              </div> */}
              <div className="p-d-flex p-flex-wrap p-my-6 p-mx-2">
                <Button
                  type="button"
                  className='p-button p-button-primary p-ml-3 p-mr-2'
                  label="Save"
                  disabled={(!this.state.programName && this.state.programName === '') || (!this.state.collegeName && this.state.collegeName === '') || (!this.state.collegeCity && this.state.collegeCity === '') || (!this.state.collegeState && this.state.collegeState === '') || (!this.state.certificateIssueDate && this.state.certificateIssueDate !== '') || (!this.state.certificateLevel && this.state.certificateLevel === '') || (!this.state.sessionStartDate && this.state.sessionStartDate !== '') || (!this.state.sessionEndDate && this.state.sessionEndDate !== '')}
                  onClick={() => { this.savePosition() }}
                />
                <Button
                  type="button"
                  className='p-button p-button-primary p-ml-3 p-mr-2'
                  label="Preview"
                  onClick={(e) => this.previewCertificate(e)}
                  aria-haspopup aria-controls="overlay_panel"
                />
              </div>
            </div>
            :
            <></>
        }

        {
          this.state.loader
            ?
            <div className="p-my-3 p-mr-3"> <h4> Loading Preview... </h4> </div>
            :
            <></>
        }
        {
          this.state.fileName !== '' ?
            <div className="p-d-flex p-my-3">
              <label className="p-mr-2">Preview Certificate: </label><a href={this.state.imageSrc} rel="noreferrer" target="_blank">{this.state.fileName}</a>
            </div> : null
        }
      </div>
    )
  }
}
const mapStateToProps = (state) => ({
  ld: state.dropdownDetails
});

export default connect(mapStateToProps)(Certificate);
