import React, { useState } from "react";

// components 
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import moment from 'moment';

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName, sessionModuleTemplate } from 'utils/common';

import { toaster } from 'utils/toaster';

// services 
import SessionService from 'services/session/session.service';

import HFNLoading from "shared-components/lazyLoading/Loading";

const SessionForm = props => {

  // props destructure start
  const { initialValue, programID, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;

  const [loading, setLoading] = useState(false)
  // props destructure end

  // variable init start 
  const sessionService = new SessionService();
  // variable init end

  // state management start
  // validations start
  const [sessionFormFields] = useState({
    module_id: {
      properties: {
        type: 'Dropdown',
        label: 'Session',
        visibility: !isEditable,
        primeFieldProps: {
          filter: true,
          itemTemplate: sessionModuleTemplate
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "sessionModule"
      }
    },
    event_start_date: {
      properties: {
        type: 'Calendar',
        label: 'Start Date',
        visibility: !isEditable,
        primeFieldProps: {
          showTime: true,
          hourFormat: "12",
          readOnlyInput: true
        },
        validations: {
          required: validations.required
        }
      }
    },
    event_end_date: {
      properties: {
        type: 'Calendar',
        label: 'End Date',
        visibility: !isEditable,
        primeFieldProps: {
          showTime: true,
          hourFormat: "12",
          readOnlyInput: true
        },
        validations: {
          required: validations.required
        }
      }
    },
    user_info_id: {
      properties: {
        // type: 'Dropdown',
        type: 'MultiSelectDropdown',
        label: 'Trainer',
        visibility: isEditable, 
        primeFieldProps: {
          filter: true, showClear: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "trainer"
      }
    }
  });
  // validations end
  // state management end

  // form submit section start
  const sessionFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      if (isEditable === true) {
        assignTrainer(formData)
      }
      else
        addSession(formData)
    }
  }

  // add session section start
  const addSession = async (formData) => {
    const checkDate = (start, end) => {
      var mStart = moment(start);
      var mEnd = moment(end);
      return mStart.isBefore(mEnd);
    }

    let isValidDate = checkDate(formData.event_start_date, formData.event_end_date);

    if (!isValidDate) {
      toaster.error(`The end date should be greater than start date`);
      return;
    }

    const data = {
      cart_id: programID,
      module_id: formData.module_id,
      event_start_date: formData.event_start_date,
      event_end_date: formData.event_end_date,
      created_by: getUserName()
    }
    await response.add({
      service: sessionService,
      method: 'addSession',
      data: { item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Successfully added session",
        error: "Unable to add session"
      }
    })
  }
  // add session section end

  // update session section start
  const assignTrainer = async (formData) => {
    setLoading(true)
    const data = {
      user_info_id: formData.user_info_id,
      updated_by: getUserName()
    }
    await response.update({
      service: sessionService,
      method: 'assignTrainer',
      data: { itemId: initValue.session_id, item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Successfully assigned trainer",
        error: "Unable to assign trainer"
      }
    })
    setLoading(false)
  }
  // update session section end
  // form submit section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={sessionFormFields} onFormSubmit={sessionFormOnsubmit} />
      {loading ? <HFNLoading /> : null}
    </div>
  )
}

export default SessionForm;