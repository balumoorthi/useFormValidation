import React, { Component } from 'react';

import { withRouter } from 'react-router';

// state 
import { connect } from "react-redux";

// components
import POC from 'components/college/collegeDetails/poc';

import Staff from 'components/college/collegeDetails/staff';

import MOU from 'components/college/collegeDetails/mou/MOUForm';

import Program from 'components/college/collegeDetails/program';

// prime components
import { TabView, TabPanel } from 'primereact/tabview';

import { Accordion, AccordionTab } from 'primereact/accordion';

import { Button } from 'primereact/button';

// utils
import { response } from "utils/response";

import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from 'utils/dropdown';

import { toaster } from 'utils/toaster';

import { getUserType, getModuleAccess, getUserRole } from 'utils/common';

// services
import CollegeService from "services/college/college.service";

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class CollegeDetails extends Component {

  constructor(props) {

    super(props);

    // variables init start
    this.collegeService = new CollegeService();

    const programModuleAccess = getModuleAccess("PROGRAM") || {};
    // variables init end

    localStorage.setItem('moduleName', 'college');

    // state management start
    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['college'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "College List", url: "college/listing" },
        { label: "College", url: "" },
      ],

      collegeInfo: null,

      enableCreateProgram: programModuleAccess.access ? programModuleAccess.access.includes("create") : false,

      collegeID: this.props.match.params.id,

      activeIndex: null
    }
    // state management end
  }

  getCollegeDetail = async () => {

    const apiResponse = await response.get(
      {
        service: this.collegeService,
        method: 'getCollege',
        data: { itemId: this.state.collegeID }
      });

    if (apiResponse && apiResponse.data) {
      const apiResponseData = apiResponse.data;

      if (!apiResponseData.isError) {

        if (apiResponseData.data) {
          this.setState({ collegeInfo: apiResponseData.data })
          let pageBreadcrumbs = [
            { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
            { label: "College List", url: "college/listing" },
            { label: `${apiResponseData.data.label ? apiResponseData.data.label : "College"}`, url: "" },
          ];
          buildBreadcrumb(this.props, pageBreadcrumbs)
        }

      } else {
        toaster.error(apiResponseData.message || "Error in fetching college information")
      }
    }

  }

  gotoCartPage = () => {
    this.props.history.push(`/college/cart/${this.state.collegeID}`);
  }

  // list tabs based on privilege start
  listVisibleTabs = () => {
    let tabs = [
      {
        component: <Program collegeID={this.state.collegeID} />,
        header: "Programs"
      },
      {
        component: <POC collegeID={this.state.collegeID} />,
        header: "POC",
        slug: "view",
        module: "COLLEGE POC"
      },
      {
        component: <Staff collegeID={this.state.collegeID} />,
        header: "Staffs",
        slug: "view",
        module: "COLLEGE STAFF"
      },
      {
        component: <MOU collegeID={this.state.collegeID} collegeInfo={this.state.collegeInfo} />,
        header: "MOU / Permission letter"
      }
    ]

    if (getUserType() === "U") {
      tabs = tabs.filter(tab => {
        if (tab.slug) {
          const moduleAccess = getModuleAccess(tab.module) || {};
          return Array.isArray(moduleAccess.access) ? moduleAccess.access.includes(tab.slug) : false;
        }
        return true;
      });
    }

    return tabs.map(tab => <TabPanel key={tab.header} header={tab.header}>{tab.component}</TabPanel>)
  }
  // list tabs based on privilege end

  componentDidMount = () => {
    tourGuideSteps(this.props,this.state.joyDetails);
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    let staffIndex = 0;

    if (this.props.location.search === "?action=reg") {
      let tabs = [
        {
          header: "Programs"
        },
        {
          header: "POC",
          slug: "view",
          module: "COLLEGE POC"
        },
        {
          header: "Staffs",
          slug: "view",
          module: "COLLEGE STAFF"
        },
        {
          header: "MOU / Permission letter"
        }
      ];


      if (getUserType() === "U") {
        tabs = tabs.filter(tab => {
          if (tab.slug) {
            const moduleAccess = getModuleAccess(tab.module) || {};
            return Array.isArray(moduleAccess.access) ? moduleAccess.access.includes(tab.slug) : false;
          }
          return true;
        });
      }
      staffIndex = tabs.findIndex(tab => tab.header === "Staffs");
    }
    this.setState({ activeIndex: staffIndex });

    this.getCollegeDetail();
    dropdown.programStatus();
    dropdown.zone();
    dropdown.generalStatus();
  }

  render() {
    // state and props destructure start
    const { label, address, city, state, country, zone_id, status, discipline, upload_documents } = { ...this.state.collegeInfo };
    const zone = this.props.zones.find(value => value.value === zone_id);
    // state and props destructure end

    return (
      <>
        <div className='p-card college-details p-mt-4'>

          <Accordion activeIndex={null} >
            <AccordionTab header="College Details" headerClassName="college-details-header">

              <div className="p-d-flex p-flex-wrap">

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Name</b>
                  </p>
                  <span>{label}</span>
                </div>
                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Discipline</b>
                  </p>
                  <span>{discipline ? discipline.discipline_name : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Country</b>
                  </p>
                  <span>{country ? country.country_name : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Address</b>
                  </p>
                  <span>{address ? address : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>City</b>
                  </p>
                  <span>{city ? city : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>State</b>
                  </p>
                  <span>{state ? state : '-'}</span>
                </div>

                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Zone</b>
                  </p>
                  <span>{(zone && zone.label) ? zone.label : '-'}</span>
                </div>
                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>Status</b>
                  </p>
                  <span>{status ? status.status_name : '-'}</span>
                </div>
                <div className="p-col-md-4 p-col-6 p-mb-3">
                  <p className="p-mb-2">
                    <b>MOU Signed</b>
                  </p>
                  <span>{upload_documents !== null ? 'Yes' : 'No'}</span>
                </div>

              </div>

            </AccordionTab>
          </Accordion>

        </div>

        {
          ((getUserType() !== "U") || this.state.enableCreateProgram)
            ?
            <div className="p-card p-my-3 p-p-4">
              <div className="p-d-flex p-jc-between p-ai-center">

                {
                  (this.state.collegeInfo && this.state.collegeInfo.draft_status)
                    ?
                    <div className="p-my-2">Please finalize the cart in draft before creating a new cart</div>
                    :
                    <></>
                }

                <div className="college-create-program">
                  <Button
                    className="p-button p-button-primary programCreation"
                    style={{ minWidth: '125px', marginLeft: "10px" }}
                    label="Create Program"
                    disabled={!this.state.collegeInfo || (this.state.collegeInfo && this.state.collegeInfo.draft_status === true) ? true : false}
                    onClick={() => { this.gotoCartPage() }}
                  />
                </div>

              </div>
            </div>
            :
            <></>
        }

        <div className='tab-section'>

          <TabView activeIndex={this.state.activeIndex} onTabChange={(e) => this.setState({ activeIndex: e.index })}>
            {this.listVisibleTabs()}
          </TabView>
        </div>
      </>
    )
  }
}

const mapStateToProps = (state) => ({
  zones: state.dropdownDetails.zone,
});

export default withRouter(connect(mapStateToProps)(CollegeDetails));