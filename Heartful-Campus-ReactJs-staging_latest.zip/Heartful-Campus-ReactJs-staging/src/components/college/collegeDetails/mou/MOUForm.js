import React, { useEffect, useState } from "react";

// components 

// prime components 
import { Button } from 'primereact/button';

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { isEmpty } from 'lodash';

import { downloadFile } from "utils/common";

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getUserName, getUserRole } from "utils/common";

// services 
import CollegeService from 'services/college/college.service';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

// config
import config from 'assets/config';

// constants
const mouFolder = "college-mou";

const MOU = (props) => {

  // variable init start 
  const collegeService = new CollegeService();

  const initValue = { upload_documents: null };
  // variable init end

  // state management start

  // validations start
  localStorage.setItem('moduleName', 'mou');

  const [mouFormFields] = useState({
    upload_documents: {
      properties: {
        type: 'FileUpload',
        label: 'MOU / Permission letter',
        fieldWrapperClassNames: 'p-col-12 mouUpload',
        primeFieldProps: {
          accept: ".jpg,.jpeg,.png,.doc,.docx,.pdf",
        },
        hint: `Maximum allowed file size is ${config.maxAllowedFileSize}MB. Allowed types are jpg, jpeg, png. doc, docx and pdf`,
        validations: {
          required: validations.required
        }
      }
    }
  });

  const [joyDetails] = useState({
    run: true,
    steps: StepsInnerPage[getUserRole()]['mou'],
    stepIndex: 0,
    loadSet:Math.random(),
    continuous: true,
    loading: false
  });

  // validations end

  const [loader, setLoader] = useState(false);

  const [mou, setMOU] = useState("");

  // state management end

  // College form section start 

  // form submit section start

  const formSubmitButtonGroup = () => {
    return (
      <div className="report-button-group">
        <Button type="submit" label="Save" disabled={loader} className="p-button p-button-primary" />
      </div>
    )
  }

  const mouFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      setLoader(true);
      let formData = { ...initValue, ...data }
      uploadMOU(formData)
    }
  }

  // form submit section end

  // upload college mou section start
  const uploadMOU = async (data) => {
    try {
      let formData = new FormData(), apiResponse;

      data.updated_by = getUserName();

      Object.keys(data).forEach(key => {
        (key === "upload_documents") ? formData.append(key, data[key][0]) : formData.append(key, data[key]);
      });

      apiResponse = await response.update({
        service: collegeService,
        method: 'updateCollegeMOU',
        data: { itemId: props.collegeID, item: formData },
        toasterMessage: {
          success: "MOU has been uploaded successfuly",
          error: 'Error in uploading file'

        }
      });

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        setMOU(apiResponse.data.data.upload_documents || "")
      }
    }
    catch {
      console.log("Something went wrong.");
    }

    setLoader(false);
  }
  // upload college mou section end

  const onMOUDownload = () => {
    const mouLink = config.mediaURL + mouFolder + "/" + (mou || props.collegeInfo.upload_documents);
    if (!loader) {
      downloadFile(mouLink, mou || props.collegeInfo.upload_documents);
    }
  }

  useEffect(() => {
    tourGuideSteps(props,joyDetails);
  }, []);

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={mouFormFields}
        onFormSubmit={mouFormOnsubmit}
        submitButtonGroup={formSubmitButtonGroup}
      />
      {
        loader
          ?
          <div className="p-my-3 p-mr-3"> <h4> Uploading... </h4> </div>
          :
          <></>
      }
      {
        ((props.collegeInfo && props.collegeInfo.upload_documents) || mou)
          ?
          <div className="p-d-flex p-my-3">
            <label className="mou-download-label p-mr-3"> Uploaded Document: </label>
            <Button label=""
              icon="pi pi-download"
              title={mou || props.collegeInfo.upload_documents}
              className={"p-py-2 p-pr-2 p-pl-3 " + (loader ? "p-button-secondary" : "p-button-success")}
              onClick={() => onMOUDownload()}
              disabled={loader}
            />
          </div>
          :
          <></>
      }
    </div>
  )
}

export default MOU;
