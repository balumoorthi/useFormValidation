import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName, POCTemplate } from 'utils/common';

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import POCService from 'services/college/poc.service';

const POCForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const pocService = new POCService()
  // variable init end

  // state management start

  // validations start
  const [pocFormFields] = useState({
    user_id: {
      properties: {
        type: 'Dropdown',
        label: 'POC',
        primeFieldProps: {
          filter: true,
          itemTemplate: POCTemplate
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "volunteerUsers"
      }
    }
  });
  // validations end

  // state management end

  // form submit section start
  const pocFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      formData = getUserName(isEditable, formData)
      addPOC(formData)
    }
  }
  // form submit section end

  // add new POC section start
  const addPOC = async (data) => {
    await response.add({
      service: pocService,
      method: 'addPOC',
      data: { item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "POC has been added successfully",
        error: "Error in adding POC"
      }
    });
  }
  // add new POC section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={pocFormFields} onFormSubmit={pocFormOnsubmit} />
    </div>
  )
}

export default POCForm;
