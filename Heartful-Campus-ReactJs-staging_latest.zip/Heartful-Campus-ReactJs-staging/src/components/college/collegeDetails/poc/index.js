import React, { Component } from 'react';

// components
import POCForm from 'components/college/collegeDetails/poc/POCForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// utils 
import { response } from "utils/response";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { createdDateBadge } from "utils/badgeTemplate";

import { getModuleAccess, getUserType, getUserRole } from 'utils/common';

import { dropdown } from "utils/dropdown";

// services 
import pocService from 'services/college/poc.service';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class POC extends Component {

  constructor(props) {

    super(props);

    // variable init starts
    this.pocService = new pocService();

    this.pocTable = React.createRef(null);

    this.pocFormInitValue = {
      college_id: this.props.collegeID,
      user_id: null
    }
    // variable init end

    localStorage.setItem('moduleName', 'poc');

    // state management start
    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['poc'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      pocForm: {
        isEditable: false,
        initValue: this.pocFormInitValue,
      },

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("COLLEGE POC"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true
        },

        url: this.pocService,

        method: 'getPOCList',

        params: {
          college_id: this.props.collegeID
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'name',
            sortable: true,
            filter: true
          },
          {
            header: 'Email',
            field: 'email_address',
            sortable: true,
            filter: true,
            transformValue: false
          },
          {
            header: 'Mobile',
            field: 'mobile',
            sortable: true,
            filter: true,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        enableActionColumn: (getUserType() === "U") ? true : false,

        actionBtnOptions: [
          {
            visibility: false
          },
          {
            type: 'delete',
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true)
              confirmDialog.custom({
                message: "Are you sure you want to delete this POC?",
                accept: () => { this.removePOC(rowdata.college_poc_id) }
              })
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'POC List',
          rightBtnsOptions: [
            {
              onClick: this.setpocFormInitValue,
              classNames:"pocCreation",
              visibility: (getUserType() === "U") ? "true" : false
            }
          ]
        }
      }
    }
    // state management end
  }

  // POC Form Init Value variable starts
  setpocFormInitValue = () => {
    dropdown.collegePOC({ college_id: this.props.collegeID });
    this.setState({
      pocForm: {
        ...this.state.pocForm,
        initValue: this.pocFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Add POC', className: "sdm-popup" })
      })
  }
  // POC Form Init Value variable end

  // Remove POC section starts
  removePOC = async (id) => {
    await response.remove({
      service: this.pocService,
      method: 'removePOC',
      data: { itemId: id },
      dataTable: this.pocTable,
    })
  }
  // Remove POC section end

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.pocTable} options={this.state.options} />
        <HFNModalPopup>
          <POCForm initialValue={this.state.pocForm} dataTableRef={this.pocTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default POC;
