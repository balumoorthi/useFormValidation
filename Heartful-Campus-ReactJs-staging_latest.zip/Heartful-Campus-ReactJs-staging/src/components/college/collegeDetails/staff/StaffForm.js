import React, { useState, useEffect } from "react";

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { dropdown } from 'utils/dropdown';

import { cityAutoCompleteTemplate, getUserName } from "utils/common";

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import StaffService from 'services/college/staff.service';

const StaffForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const staffService = new StaffService()
  // variable init end

  // state management start

  // validations start
  const [staffFormFields] = useState({
    name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    email_address: {
      properties: {
        type: 'InputText',
        label: 'Email',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
          readOnly: isEditable ? true : false
        },
        validations: {
          required: validations.required,
          pattern: validations.email,
        }
      }
    },
    contact_number: {
      properties: {
        type: 'PhoneInput',
        label: 'Mobile',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {},
        validations: {
          required: validations.required,
        }
      }
    },
    designation: {
      properties: {
        type: 'InputText',
        label: 'Designation',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required
        }
      }
    },
    address: {
      properties: {
        type: 'InputTextarea',
        label: 'Address',
        visibility: isEditable,
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        }
      },
    },
    city: {
      properties: {
        type: 'CityAutoComplete',
        label: 'City',
        visibility: isEditable,
        fieldWrapperClassNames: 'p-md-12',
        searchField: 'name',
        fieldLabel: 'name',
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        },
        stateField: {
          label: 'State',
          fieldName: 'state',
          visibility: isEditable,
          fieldWrapperClassNames: 'p-md-12',
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required,
          }
        },
        countryField: {
          label: 'Country',
          fieldName: 'country_id',
          visibility: isEditable,
          fieldWrapperClassNames: 'p-md-12',
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required,
          },
          dropdownOptions: "country"
        }
      },
    },
    pincode: {
      properties: {
        type: 'InputText',
        label: 'Pincode',
        visibility: isEditable,
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          keyfilter: 'alphanum'
        },
        validations: {
          required: validations.required,
        }
      }
    },
    zone_id: {
      properties: {
        type: 'SelectDropdown',
        label: 'Zone',
        visibility: isEditable,
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          isSearchable: true,
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "zone"

      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        visibility: (isEditable) ? true : false,
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: 'generalStatus'
      }
    },
  });
  // validations end

  // state management end

  // Staff form section start 

  // form submit section start

  const staffFormOnsubmit = (data, error) => {

    let formdata = { ...initValue, ...data }

    if (isEmpty(error)) {
      formdata = getUserName(isEditable, data);
      addUpdateStaff(formdata)
    }

  }

  // form submit section end

  // add new and update Staff section start
  const addUpdateStaff = async (formData) => {
    if (!isEditable) {
      await response.add({
        service: staffService,
        method: 'addStaff',
        data: { item: formData },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: staffService,
        method: 'updateStaff',
        data: { itemId: initValue.user_id, item: formData },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update Staff section end

  useEffect(() => {
    dropdown.zone();
    dropdown.country();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={staffFormFields}
        onFormSubmit={staffFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default StaffForm;
