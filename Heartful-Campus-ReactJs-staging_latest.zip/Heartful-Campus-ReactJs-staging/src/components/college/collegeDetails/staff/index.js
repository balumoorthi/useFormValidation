import React, { Component } from 'react';

// utils 
import { response } from "utils/response";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { createdDateBadge, staffStatusBadge } from "utils/badgeTemplate";

import { getUserType, getModuleAccess, getUserRole } from 'utils/common';

// components
import StaffForm from 'components/college/collegeDetails/staff/StaffForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import staffService from 'services/college/staff.service';

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class Staff extends Component {

  constructor(props) {

    super(props);
    // variable init starts
    this.staffService = new staffService();

    this.staffTable = React.createRef(null);

    this.staffFormInitValue = {
      college_id: this.props.collegeID
    }
    // variable init end

    localStorage.setItem('moduleName', 'staff');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['staff'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      staffForm: {
        isEditable: false,
        initValue: this.staffFormInitValue,
      },

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("COLLEGE STAFF"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
        },

        url: this.staffService,

        method: 'getStaffList',

        params: {
          college_id: this.props.collegeID
        },

        columns: [
          {
            header: 'Name',
            field: 'user.name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: "200px"
            }
          },
          {
            header: 'Email',
            field: 'user.email_address',
            sortField: "SortingDisabled",
            transformValue: false,
            headerStyle: {
              width: "250px"
            }
          },
          {
            header: 'Mobile',
            field: 'user.contact_number',
            sortField: "SortingDisabled",
            headerStyle: {
              width: "175px"
            }
          },
          {
            header: 'Designation',
            field: 'user.designation',
            sortField: "SortingDisabled",
            headerStyle: {
              width: "200px"
            }
          },
          {
            header: 'Status',
            field: 'user.status_id',
            sortField: "SortingDisabled",
            body: staffStatusBadge,
            headerStyle: {
              width: "120px"
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        enableActionColumn: (getUserType() === "U") ? true : false,

        actionBtnOptions: [
          {
            type: 'update',
            onClick: this.editStaff
          },
          {
            type: 'delete',
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true)
              confirmDialog.custom({
                message: "Are you sure you want to delete this Staff?",
                accept: () => { this.removeStaff(rowData.user.user_id) }
              })
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Staff List',
          rightBtnsOptions: [
            {
              onClick: this.setstaffFormInitValue,
              classNames:"staffCreation",
              visibility: (getUserType() === "U") ? "true" : false
            }
          ]
        }

      },

      // datatables 

    }
  }

  setstaffFormInitValue = () => {
    this.setState({
      staffForm: {
        ...this.state.staffForm,
        initValue: this.staffFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'ADD Staff', className: "sdm-popup" })
      })
  }

  editStaff = (ev, rowData) => {
    this.setState({
      staffForm: {
        ...this.state.staffForm,
        initValue: {
          college_staff_id: rowData.user.user_id,
          user_id: rowData.user.user_id,
          name: rowData.user.name,
          email_address: rowData.user.email_address,
          contact_number: rowData.user.contact_number,
          designation: rowData.user.designation,
          address: rowData.user.address,
          state: rowData.user.state,
          city: rowData.user.city,
          country_id: rowData.user.country_id,
          pincode: rowData.user.pincode,
          zone_id: rowData.user.zone_id,
          status_id: rowData.user.status_id,
          role_id: rowData.user.role_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'UPDATE Staff', className: "sdm-popup" })
      })
  }

  removeStaff = async (id) => {
    await response.remove({
      service: this.staffService,
      method: 'removeStaff',
      data: { itemId: id },
      dataTable: this.staffTable,
    })
  }

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.staffTable} options={this.state.options} />
        <HFNModalPopup>
          <StaffForm initialValue={this.state.staffForm} dataTableRef={this.staffTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default Staff;
