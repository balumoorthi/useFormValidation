import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <div>
        <h4>Heartful Campus © {new Date().getFullYear()} – All Rights Reserved</h4>
      </div>
    );
  }
}

export default Footer;