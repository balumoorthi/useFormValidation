import React, { Component } from 'react';

import { Route, Switch, Redirect } from "react-router-dom";

// state 
import { connect } from 'react-redux';

// components
import AuthGuard from 'auth-guard/index';

import Header from 'components/layouts/Header';

import Sidebar from 'components/layouts/Sidebar';

import Footer from 'components/layouts/Footer';

// shared components 
import HFNLoader from 'shared-components/lazyLoading';

import HFNBreadCrumb from "shared-components/breadcrumb";

// utils 
import lazy from 'utils/lazy';

import Steps from 'shared-components/tourGuide/Steps';
import { getUserRole } from 'utils/common';
import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';
import tourGuideSteps from 'utils/tourGuideSteps';

import { Cookies, withCookies } from "react-cookie";
import { instanceOf } from "prop-types";

const lazyDelay = 500;

// lazy components 
const Dashboard              = lazy('dashboard'         , lazyDelay);
const AssetsManagement       = lazy('assets'            , lazyDelay);
const College                = lazy('college'           , lazyDelay);
const User                   = lazy('user'              , lazyDelay);
const Trainer                = lazy('trainer'           , lazyDelay);
const MyPrograms             = lazy('trainer/myprograms', lazyDelay);
const Module                 = lazy('module'            , lazyDelay);
const CMS                    = lazy('cms'               , lazyDelay);
const FAQ                    = lazy('faq'               , lazyDelay);
const Configurations         = lazy('configurations'    , lazyDelay);
const StandardDataManagement = lazy('standardData'      , lazyDelay);
const Statistics             = lazy('statistics'        , lazyDelay);
const Program                = lazy('program'           , lazyDelay);
const AccountEdit            = lazy('account'           , lazyDelay);
const Privileges             = lazy('privilege'         , lazyDelay);
const MyCollege              = lazy('college/myCollege' , lazyDelay);
const FAQView                = lazy('faqView'           , lazyDelay);
const HelpView               = lazy('helpView'          , lazyDelay);
const TrainerAvailability    = lazy('trainer/trainerAvailability', lazyDelay);
class DashboardContainer extends Component {

  static propTypes = {
    cookies: instanceOf(Cookies).isRequired
  };
  constructor(props) {
    super(props);
    this.state = {
      run: true,
      steps: Steps[getUserRole()],
      stepIndex: 0,
      continuous: true,
      loading: false,
      loadSet:Math.random(),
      tourGuidance: localStorage.getItem('tourGuidance')
      // tourGuidance: this.props.cookies.get("tourGuidance")
    };
  }

  startTour = async () => {
    const { cookies } = this.props;
    const loadCount=this.state.loadSet
    let tourPath = localStorage.getItem('moduleName');
    localStorage.setItem('tourGuidance', 0);
    if(this.props.cookies.get("tourRequired") === 'no')
      cookies.set("tourGuidance", 2, { path: "/" })
    else
      cookies.set("tourGuidance", 0, { path: "/" })
    await this.setState({
      steps: this.props.location.pathname === "/dashboard" ? Steps[getUserRole()] : StepsInnerPage[getUserRole()][tourPath],
      loadSet:loadCount +1,
      disableBeacon: true,
      tourGuidance: localStorage.getItem('tourGuidance'),
      tourGuidance1: this.props.cookies.get("tourGuidance") // set the cookie
    })
    tourGuideSteps(this.props,this.state)
  };
  componentDidMount(){
    tourGuideSteps(this.props,this.state)
  }

  render() {

    return (
      <div className={`app-wrapper ${this.props.ad.isSidebarOpen ? "open" : ""}`}>

        <div className="sidebar-wrapper">
          <Sidebar />
        </div>

        <div className="layout">

          <div className="header">
            <Header getHelpers= {this.startTour} tourGuidance={this.state.tourGuidance} />
          </div>

          <div className="main-wrapper">

            <div className="main-container">

              <div className="breadcrums-section">
                <HFNBreadCrumb />
              </div>

              <HFNLoader>
                <Switch>
                  <AuthGuard path='/dashboard'                  component={Dashboard             } />
                  <AuthGuard path='/assets'                     component={AssetsManagement      } />
                  <AuthGuard path='/college'                    component={College               } />
                  <AuthGuard path='/user'                       component={User                  } />
                  <AuthGuard path='/trainer'                    component={Trainer               } />
                  <AuthGuard path='/myprograms'                 component={MyPrograms            } />
                  <AuthGuard path='/module'                     component={Module                } />
                  <AuthGuard path='/cms'                        component={CMS                   } />
                  <AuthGuard path='/faq'                        component={FAQ                   } />
                  <AuthGuard path='/configurations'             component={Configurations              } />
                  <AuthGuard path='/standard-data'              component={StandardDataManagement} />
                  <AuthGuard path='/statistics'                 component={Statistics            } />
                  <AuthGuard path='/program'                    component={Program               } />
                  <AuthGuard path='/account'                    component={AccountEdit           } />
                  <AuthGuard path='/privilege'                  component={Privileges            } />
                  <AuthGuard path='/mycollege'                  component={MyCollege             } />
                  <AuthGuard path='/frequently-asked-questions' component={FAQView               } />
                  <AuthGuard path='/help'                       component={HelpView              } />
                  <AuthGuard path='/notify-unavailability'        component={TrainerAvailability   } />
                  <Route exact path="/">
                    <Redirect to="/dashboard" />
                  </Route>
                </Switch>
              </HFNLoader>

            </div>

            <div className="footer-section">
              <Footer />
            </div>

          </div>
        </div>
      </div>
    );
  }
}

// export default Login
const mapStateToProps = (state) => ({
  ld: state.loginDetails,
  ad: state.appDetails
});

export default withCookies(connect(mapStateToProps)(DashboardContainer));
