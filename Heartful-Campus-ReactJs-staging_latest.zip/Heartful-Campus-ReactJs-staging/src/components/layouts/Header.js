import React, { Component } from 'react';

import { withRouter } from "react-router";

import { Link } from 'react-router-dom';

// import { signOut } from '@heartfulnessinstitute/react-hfn-profile';

// state 
import { connect } from 'react-redux';

import { OPENSIDEBAR } from 'store/actions/type/app';

// components

// prime components
import { Menu } from 'primereact/menu';

import { confirmDialog } from 'primereact/confirmdialog';

import { Button } from 'primereact/button';

// storage 
import { lStorage } from 'utils/storage';

import { createImageFromInitials, getRandomColor } from 'utils/badgeTemplate';

const mediaPath = "user-avatar/"

// utils 
import { response } from "utils/response";

import { getResponseMessage, getUserRole } from "utils/common";

import { toaster } from "utils/toaster";

// config
import config from "assets/config";

import { Dropdown } from 'primereact/dropdown';

import NotifyMe from 'react-notification-timeline';

// services 
import UserService from 'services/user/user.service';

import { isEmpty } from 'lodash';

import tourGuide from 'assets/images/tour-guide.png';

import { Cookies, withCookies } from "react-cookie";
import { instanceOf } from "prop-types";

class Header extends Component {
  static propTypes = {
    cookies: instanceOf(Cookies).isRequired
  };
  constructor(props) {

    super(props);

    this.userService = new UserService();

    // state management start
    this.state = {
      tourGuidance1 : this.props.cookies.get("tourGuidance"),
      tourRequired : this.props.cookies.get("tourRequired"),
      userValue: null,
      userMenuItems: [
        {
          items: [
            {
              label: 'My Account', icon: 'uil uil-user', command: () => {
                this.openAccount()
              }
            },
            {
              label: 'Logout', icon: 'uil uil-sign-out-alt', command: () => {
                this.logout()
              }
            },
          ]
        }
      ],
      userDetails: {},
      notificationData : [],
      notifyfirstCall : '',
      tourGuidance: this.props.tourGuidance
    }
    // state management end

  }

  // user Log out section starts
  logout = () => {
    lStorage.clear();
    this.props.history.push('/login');
    //signOut();
  }
  // user Log out section end

  // user Account edit section starts
  openAccount = () => {
    this.props.history.push('/account')
  }
  // user Account edit section end

  // user Update the configuration settings section starts
  openSettings = () => {
    this.props.history.push('/configurations')
  }
  // user Update the configuration settings section end

  openSidebar = () => {
    if (this.props.ad.isSidebarOpen) {
      this.props.dispatch({ type: OPENSIDEBAR, payload: false })
    } else {
      this.props.dispatch({ type: OPENSIDEBAR, payload: true })
    }
  }

  userChange = async () => {
    console.log("data")
    const userDetails = lStorage.get('authInfo');
    let changeUser = userDetails.user_type === "T" ? "U" :"T"
    this.setState({ userValue: changeUser })
    let values = lStorage.get("authInfo")
    var userInfo = values;
    const trainerData = userInfo;
    trainerData['user_type'] = changeUser;
    lStorage.set('authInfo', trainerData);
    this.props.history.push('/dashboard')
    window.location.reload()
  }

  // get notifications info start
  getNotifications = async () => {
    const userDetails = lStorage.get('authInfo');
    let apiResponse, apiResponseData;
    if(!isEmpty(userDetails)) {
      apiResponse = await response.get({
        service: this.userService,
        method: 'getNotification',
        data: { itemId: userDetails.id },
      })

      if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
        apiResponseData = apiResponse.data.data;
        (apiResponse.data.message === 'Notification Box Full' && this.state.notifyfirstCall === '') ? toaster.error("Notification is full, kindly clear notification to recieve further notification") : '';
        this.setState({ 
          notificationData: apiResponseData,
          notifyfirstCall: 'sent'
        })
      }
      else {
        toaster.error(getResponseMessage(apiResponseData) || "Unable to get notifications")
      }
    } else {
      this.props.history.push('/login');
    }
  }
  // get notifications info end

  customMarkAsRead = async () => {
    confirmDialog({
      message: `Are you sure want to mark all notification as read? Once it's done can't see again.`,
      header: "Confirm",
      className: 'module-confirm-popup',
      accept: () => {
        this.markAsReadCustom()
      }
    });
  }

  markAsReadCustom = async () => {
    const userDetails = lStorage.get('authInfo');
    let apiResponse, apiResponseData;
    let data = {
      user_id: userDetails.id
    }
    apiResponse = await response.add({
      service: this.userService,
      method: 'markallNotifications',
      data: { item: data },
      toasterMessage: false
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      apiResponseData = apiResponse.data.data;
      this.setState({ 
        notificationData: apiResponseData 
      })
      toaster.success("Notifications Updated Successfully")
    }
    else {
      toaster.error(apiResponseData.message || "Unable to get notifications")
    }
  }

  componentDidUpdate() {
    if((localStorage.getItem('tourGuidance') != this.state.tourGuidance)) {
      this.setState({ tourGuidance: localStorage.getItem('tourGuidance')})
    }
  }

  componentDidMount() {
    const userDetails = lStorage.get('authInfo');
    this.setState({ userValue: userDetails.user_type })

    if ((userDetails.user_type === "U") && ((userDetails.role === "Superadmin") || (userDetails.role === "Admin"))) {
      const userMenuItems = [
        {
          items: [
            {
              label: 'My Account', icon: 'uil uil-user', command: () => {
                this.openAccount()
              }
            },
            {
              label: 'Configurations', icon: 'uil uil-cog', command: () => {
                this.openSettings()
              }
            },
            {
              label: 'Logout', icon: 'uil uil-sign-out-alt', command: () => {
                this.logout()
              }
            },
          ]
        }
      ];

      
      this.setState({
        userDetails: userDetails,
        userMenuItems: userMenuItems
      });
    }else if(userDetails.secondary_user_type === "T"){
      const userMenuItems = [
        {
          items: [
            {
              label: 'My Account', icon: 'uil uil-user', command: () => {
                this.openAccount()
              }
            },
            {
              label: `Switch to ${userDetails.user_type !== "T" ? "Trainer" :  userDetails.role}`,
              icon: "uil uil-users-alt",
              template: (item,options) => {
                return (
                    <a className="p-menuitem-link swith-display-mo" target={item.target} onClick={this.userChange}>
                        <span  className={(options.iconClassName, 'p-menuitem-icon uil uil-users-alt')}></span>
                        <span className="p-menuitem-text">{item.label}</span>
                    </a>
                );
            }
            },
            {
              label: 'Logout', icon: 'uil uil-sign-out-alt', command: () => {
                this.logout()
              }
            },
          ]
        }
      ];
      this.setState({
        userDetails: userDetails,
        userMenuItems: userMenuItems
      });
    }
    else {
      this.setState({ userDetails: userDetails });
    }
    this.getNotifications()
    if(!isEmpty(userDetails)) {
      this.interval = setInterval(() => {
        this.getNotifications()
      }, 50000)
    }
  }

  render() {

    const { userDetails } = this.state;
    const { cookies } = this.props;
    let typeRole = "";
    if (userDetails.user_type === "U") {
      typeRole = userDetails.role
    }
    else {
      const userType = config.userTypes.find(type => type.value === userDetails.user_type)
      typeRole = userType ? userType.label : "";
    }
    return (
      
      <nav className="header-nav">

        <div className="menu-toggler" onClick={this.openSidebar}>
          <i className="uil uil-bars projects"><span className="list" onClick={this.props.tourClick}></span></i>
        </div>

        {userDetails && <div className="left-menu">
          {userDetails.secondary_user_type === "T" ? <div className="swith-display">
            <label>Switch user &nbsp;&nbsp;</label>
            <Dropdown options={
              [{
                label: userDetails.role,
                value: "U"
              },
              {
                label: "Trainer",
                value: "T"
              }]}
              value={this.state.userValue}
              onChange={(e) => this.userChange(e)}
            />
          </div> : null}

          <div className="helper-links faq help">
            {(getUserRole() === "Volunteer" || getUserRole() === "Zone Coordinator" || getUserRole()=== "State Coordinator" || getUserRole()=== "Trainer" || getUserRole()=== "College Staff") ?
            <>
            {(this.props.cookies.get("tourGuidance") == 1 || this.props.cookies.get("tourRequired") === 'no') ? 
            <Link onClick={this.props.getHelpers}>
                <img src={tourGuide} alt="tour guide" title='take a tour' width="20px" height="20px" />
            </Link>
            : ""}
            {(this.props.cookies.get("tourGuidance") == 0 && this.props.cookies.get("tourRequired") === 'yes') ? 
            <Button 
              label="Stop Tour" 
              className="p-button-primary" 
              onClick={() => { 
                  localStorage.setItem('tourGuidance', 1);
                  this.setState({ tourGuidance: 1});
                  cookies.set("tourGuidance", 1, { path: "/" }); // set the cookie
                  cookies.set("tourRequired", 'no', { path: "/" }); // set the cookie
              }} 
              disabled={(this.state.tourGuidance == 1) ? true : false} />: ""}</>:
            null}
            <Link to="/frequently-asked-questions" className="faqlist list" title="frequently-asked-questions">
              <i className="uil uil-comment-alt-question faq"></i>
              <span>FAQ</span>
            </Link>
            <Link to="/help" className="helplistq listq" title="help">
              <i className="uil uil-question-circle help"></i>
              <span>Help</span>
            </Link>
            <NotifyMe
              data={this.state.notificationData}
              storageKey='notific_key'
              notific_key='timestamp'
              notific_value='update'
              heading='Notification Alerts'
              sortedByKey={true}
              showDate={false}
              size={24}
              color="#2196F3"
              markAsReadFn={() => this.customMarkAsRead()}
            />
          </div>

          <div className="user-info profile" onClick={(event) => this.menu.toggle(event)}>
            <span className="avator">
              <img id='preview' style={{ borderRadius: '23px' }}
                src={
                  userDetails.avatar === "Noimage.png"
                    ? createImageFromInitials(500, userDetails.name, getRandomColor())
                    : config.mediaURL + mediaPath + userDetails.avatar
                }
                alt='' />
            </span>
            <span className="user-name">
              <span className="name"> {userDetails.name} </span>
              <span className="role"> {typeRole} </span>
            </span>
          </div>

          <Menu className="user-menu" model={this.state.userMenuItems} popup ref={el => this.menu = el} />

        </div>
        }
      </nav>
    )
  }
}

// export default Login
const mapStateToProps = (state) => ({
  ad: state.appDetails
});

export default withRouter(withCookies((connect(mapStateToProps)(Header))));