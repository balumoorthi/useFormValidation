import React, { Component } from 'react';

class Statistics extends Component {
  render() {
    return (
      <div>
        <h2>Statistics</h2>
      </div>
    );
  }
}

export default Statistics;
