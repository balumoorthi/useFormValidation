import React, { Component } from 'react';

// routes 
import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from 'utils/dropdown';

import { modalPopup } from "utils/modalPopup";

import { getUserType } from "utils/common";

// prime react components
import { Accordion, AccordionTab } from 'primereact/accordion';

import { Dropdown } from 'primereact/dropdown';

// services 
import FaqService from 'services/faq/faq.service';

// config
import config from 'assets/config';

// shared Components
import HFNLoading from 'shared-components/lazyLoading/Loading';

import HFNModalPopup from 'shared-components/modalPopup';

//import ReactPlayer from 'react-player/youtube';

import { Button } from 'primereact/button';

// constants
const certificate_folder = "faq-docs";


class FAQView extends Component {

  constructor(props) {

    super(props);

    this.faqService = new FaqService();
    const breadCrumb = [
      { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
      { label: "FAQs", url: "frequently-Asked-Questions", },
    ];

    if (getUserType() === "CS") {
      breadCrumb.shift()
    }

    this.state = {

      breadcrumbs: breadCrumb,

      faqViewData: [],

      activeIndex: 0,
      faqCategory: '',
    };
  }

  onClick(itemIndex) {

    let activeIndex = this.state.activeIndex ? [...this.state.activeIndex] : [];

    if (activeIndex.length === 0) {
      activeIndex.push(itemIndex);
    }
    else {

      const index = activeIndex.indexOf(itemIndex);

      if (index === -1) {
        activeIndex.push(itemIndex);
      }
      else {
        activeIndex.splice(index, 1);
      }
    }

    this.setState({ activeIndex });

  }

  loadFaqView = async (id) => {
    try {
      const apiResponse = await this.faqService.getFaqViewList(id, { user_type: getUserType() })

      if (apiResponse && apiResponse.data) {

        const faqViewData = apiResponse.data.data;

        this.setState({
          faqViewData: faqViewData
        });

      }
    } catch (err) {
      console.log(err)
    }

  }
  onCategoryChange = (e) => {
    this.setState({ faqCategory: e.target.value })
    let id = e.target.value
    this.loadFaqView(id);
  }

  loadDropdownData = async () => {
    this.setState({ loading: true })
    await dropdown.faqCategoryList({ user_type: getUserType() })
    let id = this.props.fcl
    let faqId = (id.faqCategoryList[0] !== undefined && id.faqCategoryList !== []) ? id.faqCategoryList[0].value : ''
    this.setState({ faqCategory: faqId })
    await this.loadFaqView(faqId);
    this.setState({ loading: false })
  }
  openModal = (data) => {
    this.setState({
      mediaUrl: data,
      loading: true
    }, () => {
      modalPopup.toggle(true)
      modalPopup.custom({
        header: 'Media Player',
        className: 'media-player',
        blockScroll: true,
        footer: (
          <div className="p-text-right">
            <Button type="button" className='p-button p-button-secondary p-mr-2' label="Close" onClick={() => { modalPopup.toggle(false); }} />
          </div>
        )
      })
    })
    this.setState({
      loading: false
    })
  }
  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    this.loadDropdownData()
  }
  render() {
    const faqData = this.props.fcl
    return (
      <>
        {this.state.loading === true ? <HFNLoading /> : <></>}
        <div className="faq-view p-mt-3 p-mb-4">
          <div className="p-card">
            <div className="p-card-body">
              <h3 className="card-title-section">Frequently Asked Questions</h3>
              <div className='select-category'>
                <span>Select Category</span>&nbsp; : &nbsp;&nbsp; <Dropdown optionLabel="label" value={this.state.faqCategory} options={faqData.faqCategoryList} onChange={(e) => this.onCategoryChange(e)} placeholder="Select Category Type" filter filterBy="label" />
              </div>
              <br />
              <br />
              <div>
                {(this.state.faqCategory !== '' && this.state.faqViewData.length > 0) ?
                  <div>
                    {this.state.faqViewData.map((data, index) => {
                      return (
                        <Accordion key={index} activeIndex={index} >
                          <AccordionTab className="p-mb-2" header={data.question}>
                            <div >
                            <div dangerouslySetInnerHTML={{ __html: data.answer}}></div>
                              {data.faq_document !== null || (data.faq_video_link !== null && data.faq_video_link !== "") ?
                                <div className="top-adjust">
                                  {data.faq_document !== null ? <p className="answerWidth"> <span className="pi pi-file-o"></span> &nbsp; <a className="faqview-document" href={config.mediaURL + certificate_folder + "/" + data.faq_document} rel="noreferrer" target="_blank" >Attachment</a></p> : null}
                                  {(data.faq_video_link !== null && data.faq_video_link !== "") ? <i
                                    className="pi pi-youtube youtube-icon"
                                    onClick={() => this.openModal(data.faq_video_link)}
                                  ></i> : null}
                                </div> : null}
                            </div>
                          </AccordionTab>
                        </Accordion>
                      )
                    })}
                  </div> :
                  <h4>No data found</h4>}
              </div>
            </div>
          </div>
        </div>
        <HFNModalPopup >
          <div className="responsive-frame">
            <iframe src={config.videoUrlEmbed + this.state.mediaUrl}
              className="responsive-iframe"
              frameBorder='0'
              allow='autoplay; encrypted-media'
              allowFullScreen
              title="Youtube Player"
            />
          </div>
        </HFNModalPopup>
      </>
    );
  }

}
const mapStateToProps = (state) => ({
  ad: state.appDetails,
  fcl: state.dropdownDetails,
});

export default withRouter(connect(mapStateToProps)(FAQView));