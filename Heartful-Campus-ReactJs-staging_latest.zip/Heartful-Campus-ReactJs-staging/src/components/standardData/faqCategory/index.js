import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { dropdown } from 'utils/dropdown';

import { getModuleAccess , getUserName} from "utils/common";

import { bulk } from "utils/bulk";

// components
import FaqCategoryForm from 'components/standardData/faqCategory/FaqCategoryForm';

// prime components 

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import FaqCategoryService from 'services/faqCategory/faqCategory.service'


class FAQCategory extends Component {

  constructor(props) {

    super(props);

    // variable init starts
    this.faqCategoryService = new FaqCategoryService();

    this.faqCategoryTable = React.createRef(null);

    this.faqFormInitValue = {
      category: null,
      sort_order: 1,
      status_id: null,
    }
    // variable init end

    this.state = {

      faqForm: {
        isEditable: true,
        initValue: this.faqFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "FAQ Category", url: "faqcategory", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.faqCategoryService,
        

        method: 'getFAQCategoryList',

        lazyParams: {
         // sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Faq Category',
            field: 'category',
            sortable: true,
            filter: true,
            headerStyle: {
              minWidth: '200px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            headerStyle: {
              width: '200px'
            },
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: 'generalStatus'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '200px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'update',
            onClick: this.editFAQCategory
          },
          {
            type: 'delete',
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true)
              confirmDialog.accept(() => { this.removeFAQCategory(rowdata.faq_category_id) });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'FAQ Category List',
          selection: {
            field: {
              options: "generalStatus"
            },
          updateBtnsOptions: {
            onClick: ({ selections, status }) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({ message: "You are about to mass update the status of FAQ Categories?" });
              confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
            }
          },
          deleteBtnsOptions: {
            onClick: ({ selections }) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({ message: "Are you sure you want to delete these FAQ Categories? This may affect other screens" });
              confirmDialog.accept(() => { this.bulkDelete(selections) });
            }
          },
        },
          rightBtnsOptions: [
            { onClick: this.setFAQFormInitValue }
          ]
        },
        enableSelection: true,
      }

      // datatables 

    }
  }

  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "FaqCategory",
        name: "faq_category_id",
        value: selections.map(value => { return value.faq_category_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.faqCategoryTable,
    })
  }

  // bulk status update end

  // bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "FaqCategory",
        name: "faq_category_id",
        value: selections.map(value => { return value.faq_category_id }),
        deleted_by: getUserName()
      },
      dataTable: this.faqCategoryTable,
    })
  }

  // bulk delete end

  
  // FAQ Form Inti Starts
  setFAQFormInitValue = () => {
    this.setState({
      faqForm: {
        ...this.state.faqForm,
        initValue: this.faqFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'ADD FAQ Category' })
      })
  }
  // FAQ Form Inti end

  // Edit FAQ start
  editFAQCategory = (ev, rowdata) => {
    this.setState({
      faqForm: {
        ...this.state.faqForm,
        initValue: {
          category: rowdata.category,
          faq_category_id: rowdata.faq_category_id,
          sort_order: rowdata.sort_order,
          status_id: rowdata.status_id
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'UPDATE FAQ Category' })
      })
  }
  // Edit FAQ end

  // Remove FAQ start
  removeFAQCategory = async (id) => {
    await response.remove({
      service: this.faqCategoryService,
      method: 'removeFAQCategory',
      data: { itemId: id },
      dataTable: this.faqCategoryTable,
    })
  }
  // Remove FAQ end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.faqCategoryTable} options={this.state.options} />
        <HFNModalPopup>
          <FaqCategoryForm initialValue={this.state.faqForm} dataTableRef={this.faqCategoryTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(FAQCategory));