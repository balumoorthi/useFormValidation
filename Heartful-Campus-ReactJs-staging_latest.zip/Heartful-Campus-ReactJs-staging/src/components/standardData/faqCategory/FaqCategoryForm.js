import React, { useState } from "react";

// state 

// storage 

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// prime components 

// services 

import FaqCategoryService from 'services/faqCategory/faqCategory.service';

const FaqCategoryForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const faqCategoryService = new FaqCategoryService()
  // variable init end

  // state management start

  // validations start
  const [FaqFormFields] = useState({
    category: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {
          options: [
            { label: "Active", value: 1 },
            { label: "In Active", value: 2 },
          ]
        },
        validations: {
          required: validations.required,
        }
      }
    },
  });
  // validations end

  // state management end

  // faq form section start 

  // form submit section start

  const FaqFormOnsubmit = (data, error) => {
    let Formdata = { ...initValue, ...data }
    if (isEmpty(error)) {
      Formdata = getUserName(isEditable, Formdata);
      addUpdateFaq(Formdata)
    }
  }

  // form submit section end

  // add new and update faq section start
  const addUpdateFaq = async (data) => {

    if (!isEditable) {
      await response.add({
        service: faqCategoryService,
        method: 'addFAQCategory',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: faqCategoryService,
        method: 'updateFAQCategory',
        data: { itemId: initValue.faq_category_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update faq section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={FaqFormFields} onFormSubmit={FaqFormOnsubmit} >
      </HFNDynamicForm>
    </div>
  );

}

export default FaqCategoryForm;
