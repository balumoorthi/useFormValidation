import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { getUserName } from "utils/common";

import { isEmpty } from 'lodash';

import { response } from "utils/response";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import LanguageService from 'services/standard-data/language.service'

const LanguageForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const languageService = new LanguageService()
  // variable init end

  // state management start

  // validations start
  const [LanguageFormFields] = useState({
    language_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"

      }
    },
  });
  // validations end

  // state management end

  // language form section start 

  // form submit section start

  const LanguageFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      formData = getUserName(isEditable, formData)
      addUpdateLanguage(formData)
    }
  }

  // form submit section end

  // add new and update language section start
  const addUpdateLanguage = async (data) => {

    if (!isEditable) {
      await response.add({
        service: languageService,
        method: 'addLanguage',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: languageService,
        method: 'updateLanguage',
        data: { itemId: initValue.language_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update language section end

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={LanguageFormFields}
        onFormSubmit={LanguageFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default LanguageForm;
