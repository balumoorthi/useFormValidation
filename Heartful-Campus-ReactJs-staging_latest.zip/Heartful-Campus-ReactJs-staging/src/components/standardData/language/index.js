import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { getModuleAccess, getUserName } from "utils/common";

import { bulk } from "utils/bulk";

// components
import LanguageForm from 'components/standardData/language/LanguageForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import LanguageService from 'services/standard-data/language.service'

class Language extends Component {

  constructor(props) {

    super(props);
    // variable init start 
    this.languageService = new LanguageService();

    this.languageTable = React.createRef(null);

    this.languageFormInitValue = {
      language_name: null,
      status_id: null
    }
    // variable init end
    this.state = {

      languageForm: {
        isEditable: false,
        initValue: this.languageFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Language", url: "language", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
        },

        url: this.languageService,

        method: 'getLanguageList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'language_name',
            sortable: true,
            editable: true,
            filter: true,
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"

            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            body: createdDateBadge,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
          },
        ],

        actionBtnOptions: [
          {
            onClick: this.editLanguage
          },
          {
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this language? This may affect other screens",
                accept: () => { this.removeLanguage(rowdata.language_id) }
              });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Language List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of languages?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these languages? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setlanguageFormInitValue }
          ]
        },
        enableSelection: true,
      }

      // datatables 

    }
  }

  //bulk status update starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Language",
        name: "language_id",
        value: selections.map(value => { return value.language_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.languageTable,
    })
  }
  //bulk status update end

  //bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Language",
        name: "language_id",
        value: selections.map(value => { return value.language_id }),
        deleted_by: getUserName(),
      },
      dataTable: this.languageTable,
    })
  }
  //bulk delete end

  //add Language start
  setlanguageFormInitValue = () => {
    this.setState({
      languageForm: {
        ...this.state.languageForm,
        initValue: this.languageFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Add Language', className: 'sdm-popup' })
      })
  }
  //add Language end

  // edit language starts
  editLanguage = (ev, rowdata) => {
    this.setState({
      languageForm: {
        ...this.state.languageForm,
        initValue: {
          language_id: rowdata.language_id,
          language_name: rowdata.language_name,
          status_id: rowdata.status_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Update Language', className: 'sdm-popup' })
      })
  }
  // edit language end

  // remove language starts
  removeLanguage = async (id) => {
    await response.remove({
      service: this.languageService,
      method: 'removeLanguage',
      data: { itemId: id },
      dataTable: this.languageTable,
    })
  }
  // remove language end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();

  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.languageTable} options={this.state.options} />
        <HFNModalPopup>
          <LanguageForm initialValue={this.state.languageForm} dataTableRef={this.languageTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(Language));