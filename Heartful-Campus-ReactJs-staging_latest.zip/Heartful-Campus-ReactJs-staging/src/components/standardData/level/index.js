import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from "utils/dropdown";

import { response } from "utils/response";

import { statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { bulk } from "utils/bulk";

import { getModuleAccess, getUserName } from "utils/common";

// components
import LevelForm from 'components/standardData/level/LevelForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import LevelService from 'services/standard-data/level.service';

class Level extends Component {

  constructor(props) {

    super(props);

    //variable init starts
    this.levelService = new LevelService();

    this.levelTable = React.createRef(null);

    this.levelFormInitValue = {
      level_name: null,
      level_desc: null,
      status_id: null,
    }
    //variable init end

    this.state = {

      levelForm: {
        isEditable: false,
        initValue: this.levelFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Level", url: "level", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.levelService,

        method: 'getLevelList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'level_name',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Description',
            field: 'level_desc',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '250px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            onClick: this.editLevel
          },
          {
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true)

              confirmDialog.custom({
                message: "Are you sure you want to delete this level? This may affect other screens",

                header: "Confirmation",

                icon: "pi pi-exclamation-triangle",

              });
              confirmDialog.accept(() => { this.removeLevel(rowdata.level_id) });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Level List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of levels?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these levels? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setLevelFormInitValue }
          ]
        },
        enableSelection: true,
      }

      // datatables 

    }
  }

  //bulk level update starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Level",
        name: "level_id",
        value: selections.map(value => { return value.level_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.levelTable,
    })
  }
  //bulk level update end

  //bulk level delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Level",
        name: "level_id",
        value: selections.map(value => { return value.level_id }),
        deleted_by: getUserName()
      },
      dataTable: this.levelTable,
    })
  }
  //bulk level delete end

  // add level starts
  setLevelFormInitValue = () => {
    this.setState({
      levelForm: {
        ...this.state.levelForm,
        initValue: this.levelFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'ADD Level', className: 'sdm-popup' })
      })
  }
  // add level end

  // edit level starts
  editLevel = (ev, rowdata) => {
    this.setState({
      levelForm: {
        ...this.state.levelForm,
        initValue: {
          level_id: rowdata.level_id,
          level_name: rowdata.level_name,
          level_desc: rowdata.level_desc,
          status_id: rowdata.status_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'UPDATE Level', className: 'sdm-popup' })
      })
  }
  // edit level end

  // remove level starts
  removeLevel = async (id) => {
    await response.remove({
      service: this.levelService,
      method: 'removeLevel',
      data: { itemId: id },
      dataTable: this.levelTable,
    })
  }
  // remove level end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();

  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.levelTable} options={this.state.options} />
        <HFNModalPopup>
          <LevelForm initialValue={this.state.levelForm} dataTableRef={this.levelTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(Level));