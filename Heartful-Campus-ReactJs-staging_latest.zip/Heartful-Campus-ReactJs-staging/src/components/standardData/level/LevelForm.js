import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import LevelService from 'services/standard-data/level.service';

const LevelForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const levelService = new LevelService()
  // variable init end

  // state management start

  // validations start
  const [LevelFormFields] = useState({
    level_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    level_desc: {
      properties: {
        type: 'InputTextarea',
        label: 'Description',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"
      }
    },
  });
  // validations end

  // state management end

  // level form section start 

  // form submit section start

  const LevelFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      formData = getUserName(isEditable, formData)

      addUpdateLevel(formData)
    }
  }

  // form submit section end

  // add new and update level section start
  const addUpdateLevel = async (data) => {

    if (!isEditable) {
      await response.add({
        service: levelService,
        method: 'addLevel',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: levelService,
        method: 'updateLevel',
        data: { itemId: initValue.level_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update level section end

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={LevelFormFields}
        onFormSubmit={LevelFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default LevelForm;
