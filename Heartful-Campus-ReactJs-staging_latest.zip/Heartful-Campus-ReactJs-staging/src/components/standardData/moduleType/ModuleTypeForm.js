import React, { useState } from "react";

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// services 
import ModuleTypeService from 'services/standard-data/moduletype.service';

const ModuleTypeForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const moduleTypeService = new ModuleTypeService()
  // variable init end

  // state management start

  // validations start
  const [ModuleTypeFormFields] = useState({
    module_type_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    module_type_desc: {
      properties: {
        type: 'InputTextarea',
        label: 'Description',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"
      }
    }
  });
  // validations end

  // state management end

  // form submit section start

  const ModuleTypeFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      formData = getUserName(isEditable, formData)
      addUpdateModuleType(formData)
    }
  }

  // form submit section end

  // add new and update module type section start
  const addUpdateModuleType = async (data) => {

    if (!isEditable) {
      await response.add({
        service: moduleTypeService,
        method: 'addModuleType',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: moduleTypeService,
        method: 'updateModuleType',
        data: { itemId: initValue.module_type_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update module type section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={ModuleTypeFormFields} onFormSubmit={ModuleTypeFormOnsubmit} />
    </div>
  )
}

export default ModuleTypeForm;