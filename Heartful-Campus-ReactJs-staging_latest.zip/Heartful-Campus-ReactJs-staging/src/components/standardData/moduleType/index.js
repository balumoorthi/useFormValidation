import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { dropdown } from "utils/dropdown";

import { bulk } from "utils/bulk";

import { getModuleAccess, getUserName } from "utils/common";

// components
import ModuleTypeForm from 'components/standardData/moduleType/ModuleTypeForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import ModuleTypeService from 'services/standard-data/moduletype.service';

class ModuleType extends Component {

  constructor(props) {

    super(props);

    //variable init starts
    this.moduleTypeService = new ModuleTypeService();

    this.moduleTypeTable = React.createRef(null);

    this.moduleTypeFormInitValue = {
      module_type_name: null,
      module_type_desc: null,
      status_id: null,

    }
    //variable init end

    this.state = {

      moduleTypeForm: {
        isEditable: false,
        initValue: this.moduleTypeFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Module Type", url: "module", },
      ],

      // datatables 


      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.moduleTypeService,

        method: 'getModuleTypeList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'module_type_name',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Description',
            field: 'module_type_desc',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '300px'
            },
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"

            },
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            onClick: this.editModuleType
          },
          {
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this module type? This may affect other screens",
                accept: () => { this.removeModuleType(rowData.module_type_id) }
              });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Module Type List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of module types?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these module types? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setModuleTypeFormInitValue }
          ]
        },
        enableSelection: true,
      }

      // datatables 

    }
  }

  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "ModuleType",
        name: "module_type_id",
        value: selections.map(value => { return value.module_type_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.moduleTypeTable,
    })
  }

  // bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "ModuleType",
        name: "module_type_id",
        value: selections.map(value => { return value.module_type_id }),
        deleted_by: getUserName()
      },
      dataTable: this.moduleTypeTable,
    })
  }
  // bulk delete end

  // add module type starts
  setModuleTypeFormInitValue = () => {
    this.setState({
      moduleTypeForm: {
        ...this.state.moduleTypeForm,
        initValue: this.moduleTypeFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Add Module Type', className: 'sdm-popup' })
      })
  }
  // add module type end

  // edit module type starts
  editModuleType = (ev, rowdata) => {
    this.setState({
      moduleTypeForm: {
        ...this.state.moduleTypeForm,
        initValue: {
          module_type_id: rowdata.module_type_id,
          module_type_name: rowdata.module_type_name,
          module_type_desc: rowdata.module_type_desc,
          status_id: rowdata.status_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Update Module Type', className: 'sdm-popup' })
      })
  }
  // edit module type end

  // remove module type starts
  removeModuleType = async (id) => {
    await response.remove({
      service: this.moduleTypeService,
      method: 'removeModuleType',
      data: { itemId: id },
      dataTable: this.moduleTypeTable,
    })
  }
  // remove module type end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();

  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.moduleTypeTable} options={this.state.options} />
        <HFNModalPopup>
          <ModuleTypeForm initialValue={this.state.moduleTypeForm} dataTableRef={this.moduleTypeTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default withRouter(connect()(ModuleType));