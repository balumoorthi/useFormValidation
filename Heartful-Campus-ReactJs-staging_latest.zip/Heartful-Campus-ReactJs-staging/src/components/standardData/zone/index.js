import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { zoneStatusBadge } from "utils/badgeTemplate";

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// services 
import ZoneService from 'services/standard-data/zone.service';

class Zone extends Component {

  constructor(props) {

    super(props);

    // variable init starts
    this.zoneService = new ZoneService();
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Zone", url: "zone", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: false
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: false,
          sortField: "name",
          sortOrder: 1
        },

        url: this.zoneService,

        method: 'getZoneList',

        columns: [
          {
            header: 'Name',
            field: 'name',
            sortable: true,
            filter: true,
            filterMatchMode: 'contains'
          },
          {
            header: 'Complete Name',
            field: 'complete_name',
            sortable: true,
            filter: true,
            filterMatchMode: 'contains'
          },
          {
            header: 'Status',
            field: 'active',
            sortable: true,
            body: zoneStatusBadge,
          }
        ],

        enableActionColumn: false,

        toolBarBtnOptions: {
          title: 'Zone List',
          rightBtnsOptions: [{ visibility: false }]
        },
      }
      // datatables 
    }
    // state management end
  }

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
  }

  render() {
    return (
      <div>
        <HFNDataTable options={this.state.options} />
      </div>
    )
  }
}

export default withRouter(connect()(Zone));