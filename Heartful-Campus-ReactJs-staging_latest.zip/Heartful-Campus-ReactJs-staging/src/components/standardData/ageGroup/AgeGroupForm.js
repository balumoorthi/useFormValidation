import React, { useState } from "react";

// state 

// storage 

// utils 

import { validations } from 'utils/validations';

import { getUserName } from "utils/common";

import { isEmpty } from 'lodash';

import { response } from "utils/response";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// prime components 

// services 

import AgeGroupService from 'services/standard-data/ageGroup.service';

const AgeGroupForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const ageGroupService = new AgeGroupService()
  // variable init end

  // state management start

  // validations start
  const [AgeGroupFormFields] = useState({
    age_group_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"

      }
    },
  });
  // validations end

  // state management end

  // Age group form section start 

  // form submit section start

  const AgeGroupFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      formData = getUserName(isEditable, formData)
      addUpdateAgeGroup(formData)
    }
  }

  // form submit section end

  // add new and update Age Group section start
  const addUpdateAgeGroup = async (data) => {

    if (!isEditable) {
      await response.add({
        service: ageGroupService,
        method: 'addAgegroup',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: ageGroupService,
        method: 'updateAgegroup',
        data: { itemId: initValue.age_group_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update Age Group section end

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={AgeGroupFormFields}
        onFormSubmit={AgeGroupFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default AgeGroupForm;
