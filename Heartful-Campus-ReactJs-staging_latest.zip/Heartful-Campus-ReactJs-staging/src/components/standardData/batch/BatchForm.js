import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { getUserName } from "utils/common";

import { isEmpty } from 'lodash';

import { response } from "utils/response";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import BatchService from 'services/standard-data/batch.service';

const BatchForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const batchService = new BatchService()
  // variable init end

  // state management start

  // validations start
  const [BatchFormFields] = useState({
    batch_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"

      }
    },
  });
  // validations end

  // state management end

  // Batch form section start 

  // form submit section start

  const BatchFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      formData = getUserName(isEditable, formData)
      addUpdateBatch(formData)
    }
  }

  // form submit section end

  // add new and update Batch section start
  const addUpdateBatch = async (data) => {

    if (!isEditable) {
      await response.add({
        service: batchService,
        method: 'addBatch',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: batchService,
        method: 'updateBatch',
        data: { itemId: initValue.batch_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update Batch section end

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={BatchFormFields}
        onFormSubmit={BatchFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default BatchForm;
