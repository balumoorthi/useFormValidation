import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import ProgramService from 'services/standard-data/program.service';

const ProgramForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const programService = new ProgramService()
  // variable init end

  // state management start

  // validations start
  const [ProgramFormFields] = useState({
    program_type_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    program_type_desc: {
      properties: {
        type: 'InputTextarea',
        label: 'Description',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"

      }
    },
  });
  // validations end

  // state management end

  // program form section start 

  // form submit section start

  const ProgramFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      formData = getUserName(isEditable, formData)
      addUpdateProgram(formData)
    }
  }

  // form submit section end

  // add new and update program section start
  const addUpdateProgram = async (data) => {

    if (!isEditable) {
      await response.add({
        service: programService,
        method: 'addProgram',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: programService,
        method: 'updateProgram',
        data: { itemId: initValue.program_type_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update program section end

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={ProgramFormFields}
        onFormSubmit={ProgramFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default ProgramForm;
