import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";


import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { dropdown } from "utils/dropdown";

import { statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { bulk } from "utils/bulk";

import { getModuleAccess, getUserName } from "utils/common";

// components
import ProgramForm from 'components/standardData/programType/ProgramForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import ProgramService from 'services/standard-data/program.service';

class Program extends Component {

  constructor(props) {

    super(props);

    // variable init starts
    this.programService = new ProgramService();

    this.programTable = React.createRef(null);

    this.programFormInitValue = {
      program_type_name: null,
      program_type_desc: null,
      status_id: null

    }
    // variable init end
    this.state = {

      programForm: {
        isEditable: false,
        initValue: this.programFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Program Type", url: "standard-data/programtype" },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.programService,

        method: 'getProgramList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'program_type_name',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Description',
            field: 'program_type_desc',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '300px'
            },
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
          },
        ],

        actionBtnOptions: [
          {
            onClick: this.editProgram
          },
          {
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);

              confirmDialog.custom({
                message: "Are you sure you want to delete this program type? This may affect other screens",

                header: "Confirmation",

                icon: "pi pi-exclamation-triangle",

              });
              confirmDialog.accept(() => { this.removeProgram(rowdata.program_type_id) });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Program type List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of program types?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these program types? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setProgramFormInitValue }
          ]
        },
        enableSelection: true,
      }

      // datatables 

    }
  }

  //bulk status update starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "ProgramType",
        name: "program_type_id",
        value: selections.map(value => { return value.program_type_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.programTable,
    })
  }
  //bulk status update end

  //bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "ProgramType",
        name: "program_type_id",
        value: selections.map(value => { return value.program_type_id }),
        deleted_by: getUserName()
      },
      dataTable: this.programTable,
    })
  }
  //bulk delete end

  // add program starts
  setProgramFormInitValue = () => {
    this.setState({
      programForm: {
        ...this.state.programForm,
        initValue: this.programFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Add Program Type', className: 'sdm-popup' })
      })
  }
  // add program end

  // Edit program start
  editProgram = (ev, rowdata) => {
    this.setState({
      programForm: {
        ...this.state.programForm,
        initValue: {
          program_type_id: rowdata.program_type_id,
          program_type_name: rowdata.program_type_name,
          program_type_desc: rowdata.program_type_desc,
          status_id: rowdata.status_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Update Program Type', calssName: 'sdm-popup' })
      })
  }
  // Edit program end

  // Remove program start
  removeProgram = async (id) => {
    await response.remove({
      service: this.programService,
      method: 'removeProgram',
      data: { itemId: id },
      dataTable: this.programTable,
    })
  }
  // Remove program end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();

  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.programTable} options={this.state.options} />
        <HFNModalPopup>
          <ProgramForm initialValue={this.state.programForm} dataTableRef={this.programTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(Program));