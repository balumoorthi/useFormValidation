import React, { Component } from 'react';

import { Switch } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import Zone        from 'components/standardData/zone'       ;
import Country     from 'components/standardData/country'    ;
import Level       from 'components/standardData/level'      ;
import Discipline  from 'components/standardData/discipline' ;
import ModuleType  from 'components/standardData/moduleType' ;
import Unit        from 'components/standardData/unit'       ;
import Program     from 'components/standardData/programType';
import AgeGroup    from 'components/standardData/ageGroup'   ;
import Language    from 'components/standardData/language'   ;
import FAQCategory from 'components/standardData/faqCategory';
import Batch       from 'components/standardData/batch';

class StandardDataManagement extends Component {
  render() {
    return (
      <div>
        <Switch>
          <AuthGuard path='/standard-data/zone' component={Zone} />
          <AuthGuard path='/standard-data/country' component={Country} />
          <AuthGuard path='/standard-data/level' component={Level} />
          <AuthGuard path='/standard-data/discipline' component={Discipline} />
          <AuthGuard path='/standard-data/moduletype' component={ModuleType} />
          <AuthGuard path='/standard-data/unit' component={Unit} />
          <AuthGuard path='/standard-data/programtype' component={Program} />
          <AuthGuard path='/standard-data/agegroup' component={AgeGroup} />
          <AuthGuard path='/standard-data/language' component={Language} />
          <AuthGuard path='/standard-data/faqcategory' component={FAQCategory} />
          <AuthGuard path='/standard-data/batch' component={Batch} />
        </Switch>
      </div>
    )
  }
}

export default StandardDataManagement;