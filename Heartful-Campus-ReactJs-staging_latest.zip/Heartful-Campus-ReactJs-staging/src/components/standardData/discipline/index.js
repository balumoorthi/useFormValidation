import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { dropdown } from "utils/dropdown";

import { bulk } from "utils/bulk";

import { getModuleAccess, getUserName } from "utils/common";

// components
import DisciplineForm from 'components/standardData/discipline/DisciplineForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import DisciplineService from 'services/standard-data/discipline.service';

class Discipline extends Component {

  constructor(props) {

    super(props);

    this.disciplineService = new DisciplineService();

    this.disciplineTable = React.createRef(null);

    this.disciplineFormInitValue = {
      discipline_name: null,
      discipline_desc: null,
      status_id: null,
    }

    this.state = {

      disciplineForm: {
        isEditable: false,
        initValue: this.disciplineFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Discipline", url: "discipline", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.disciplineService,

        method: 'getDisciplineList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'discipline_name',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Description',
            field: 'discipline_desc',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '120px'
            },
            body: createdDateBadge,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
          },
        ],

        actionBtnOptions: [
          {
            onClick: this.editDiscipline
          },
          {
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);

              confirmDialog.custom({
                message: "Are you sure you want to delete this discipline? This may affect other screens",

                header: "Confirmation",

                icon: "pi pi-exclamation-triangle",

              });
              confirmDialog.accept(() => { this.removeDiscipline(rowdata.discipline_id) });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'Discipline List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of disciplines?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these disciplines? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setDisciplineFormInitValue }
          ]
        },
        enableSelection: true,
      },

      // datatables 

    }
  }

  // bulk status update starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Discipline",
        name: "discipline_id",
        value: selections.map(value => { return value.discipline_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.disciplineTable,
    })
  }
  // bulk status update end

  // bulk Delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Discipline",
        name: "discipline_id",
        value: selections.map(value => { return value.discipline_id }),
        deleted_by: getUserName()
      },
      dataTable: this.disciplineTable,
    })
  }
  // bulk Delete end

  // Add Discipline starts
  setDisciplineFormInitValue = () => {
    this.setState({
      disciplineForm: {
        ...this.state.disciplineForm,
        initValue: this.disciplineFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'ADD Discipline', className: 'sdm-popup' })
      })
  }
  // Add Discipline end

  // Edit Discipline starts
  editDiscipline = (ev, rowdata) => {
    this.setState({
      disciplineForm: {
        ...this.state.disciplineForm,
        initValue: {
          discipline_id: rowdata.discipline_id,
          discipline_name: rowdata.discipline_name,
          discipline_desc: rowdata.discipline_desc,
          status_id: rowdata.status_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'UPDATE Discipline', className: 'sdm-popup' })
      })
  }
  // Edit Discipline end

  // Remove Discipline starts
  removeDiscipline = async (id) => {
    await response.remove({
      service: this.disciplineService,
      method: 'removeDiscipline',
      data: { itemId: id },
      dataTable: this.disciplineTable,
    })
  }
  // Remove Discipline end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();

  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.disciplineTable} options={this.state.options} />
        <HFNModalPopup>
          <DisciplineForm initialValue={this.state.disciplineForm} dataTableRef={this.disciplineTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(Discipline));