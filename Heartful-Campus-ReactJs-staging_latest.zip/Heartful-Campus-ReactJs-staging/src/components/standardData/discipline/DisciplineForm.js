import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import DisciplineService from 'services/standard-data/discipline.service';

const DisciplineForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const disciplineService = new DisciplineService()
  // variable init end

  // state management start

  // validations start
  const [DisciplineFormFields] = useState({
    discipline_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    discipline_desc: {
      properties: {
        type: 'InputTextarea',
        label: 'Description',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"

      }
    },
  });
  // validations end

  // state management end

  // discipline form section start 

  // form submit section start

  const DisciplineFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      formData = getUserName(isEditable, formData)

      addUpdateDiscipline(formData)
    }
  }

  // form submit section end

  // add new and update discipline section start
  const addUpdateDiscipline = async (data) => {

    if (!isEditable) {
      await response.add({
        service: disciplineService,
        method: 'addDiscipline',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: disciplineService,
        method: 'updateDiscipline',
        data: { itemId: initValue.discipline_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update discipline section end

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={DisciplineFormFields}
        onFormSubmit={DisciplineFormOnsubmit}
      >
      </HFNDynamicForm>
    </div>
  );

}

export default DisciplineForm;
