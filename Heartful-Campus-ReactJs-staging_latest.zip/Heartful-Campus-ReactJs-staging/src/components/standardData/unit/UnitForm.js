import React, { useState } from "react";

// components
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { isEmpty } from 'lodash';

import { validations } from 'utils/validations';

import { getUserName } from "utils/common";

import { response } from "utils/response";

// services 
import UnitService from 'services/standard-data/unit.service';

const UnitForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const unitService = new UnitService()
  // variable init end

  // state management start
  // validation start
  const [UnitFormFields] = useState({
    unit_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    unit_desc: {
      properties: {
        type: 'InputTextarea',
        label: 'Description',
        primeFieldProps: {

        },
      }
    },
    module_id: {
      properties: {
        type: 'MultiSelect',
        label: 'Modules',
        primeFieldProps: {
          filter: true,
          showClear: true
        },
        dropdownOptions: "moduleList"
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"

      }
    },
  });
  // validation end
  // state management end

  // form submit section start
  const UnitFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      formData = getUserName(isEditable, formData)
      addUpdateUnit(formData)
    }
  }

  // add new and update unit section start
  const addUpdateUnit = async (data) => {
    if (!Array.isArray(data.module_id))
      data.module_id = [];
    if (!isEditable) {
      await response.add({
        service: unitService,
        method: 'addUnit',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: unitService,
        method: 'updateUnit',
        data: { itemId: initValue.unit_id, item: data },
        dataTable: dataTableRef,
      })
    }

  }
  // add new and update unit section end
  // form submit section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={UnitFormFields} onFormSubmit={UnitFormOnsubmit} />
    </div>
  )
}

export default UnitForm;