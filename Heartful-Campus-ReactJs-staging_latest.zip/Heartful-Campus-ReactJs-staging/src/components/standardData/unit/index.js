import React, { Component } from 'react';

// components
import UnitForm from 'components/standardData/unit/UnitForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

import HFNAttachments from 'shared-components/attachment';

// utils 
import { isEmpty } from 'lodash';

import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from "utils/dropdown";

import { response } from "utils/response";

import { multipleModuleBadge, statusBadge, createdDateBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { bulk } from "utils/bulk";

import { getModuleAccess, getUserName } from "utils/common";

import { galleryPopup } from "utils/galleryPopup";

import { validations } from 'utils/validations';

// services 
import UnitService from 'services/standard-data/unit.service';

// config
import config from 'assets/config';

class Unit extends Component {

  constructor(props) {

    super(props);

    //variable init starts
    this.unitService = new UnitService();

    this.unitTable = React.createRef(null);

    this.attachmentList = React.createRef(null);

    this.unitFormInitValue = {
      unit_name: null,
      unit_desc: null,
      module_id: null,
      status_id: null
    }
    //variable init end

    // state management start
    this.state = {

      unitForm: {
        isEditable: false,
        initValue: this.unitFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Unit", url: "unit", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("STANDARD DATA"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.unitService,

        method: 'getUnitList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'unit_name',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Description',
            field: 'unit_desc',
            sortable: true,
            editable: true,
            filter: true,
            headerStyle: {
              width: '250px'
            },
          },
          {
            header: 'Module',
            field: 'module_id',
            filterType: 'select',
            sortField: "SortingDisabled",
            filterElementOptions: {
              type: 'Dropdown',
              value: "moduleList",
              primeFieldProps: {
                filter: true
              }
            },
            body: multipleModuleBadge,
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
          },
        ],

        actionBtnOptions: [
          {
            type: 'update',
            title: 'Edit Unit',
            onClick: this.editUnit
          },
          {
            type: 'update',
            icon: "pi pi-paperclip",
            className: "p-mr-2 gallery-button",
            title: 'View Attachment',
            onClick: this.viewAttachments
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            className: "p-mr-2",
            title: 'Delete Unit',
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this unit? This may affect other screens",
                accept: () => { this.removeUnit(rowdata.unit_id) },
              });
            }
          },
        ],

        toolBarBtnOptions: {
          title: 'Unit List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "You are about to mass update the status of units?",
                  accept: () => { this.bulkStatusUpdate(selections, status) }
                });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these units? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setUnitFormInitValue }
          ]
        },
        enableSelection: true,

      },
      attachmentOptions: {

        service: this.unitService,

        method: 'listAttachments',

        onDelete: attachment => {
          confirmDialog.toggle(true);
          confirmDialog.custom({
            message: "Are you sure you want to delete this attachment?",
            accept: () => { this.removeAttachment(attachment) }
          });
        },

        noDataText: "No attachments assigned for this Unit",

        enableUpload: true,

        uploadFormOptions: {

          initialValues: {},

          fields: {
            document_name: {
              properties: {
                type: 'FileUpload',
                label: 'Attachment',
                fieldWrapperClassNames: 'p-col-12',
                hint: `Maximum allowed file size is ${config.maxAllowedFileSize}MB`,
                primeFieldProps: {
                },
                validations: {
                  required: validations.required,
                }
              }
            }
          },

          onSubmit: this.onAttachmentUpload

        }
      },
      viewAttachments: false,

      processingModule: null

      // datatables 
    }
    // state management end
  }

  // bulk edit section start
  // bulk update start
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Unit",
        name: "unit_id",
        value: selections.map(value => { return value.unit_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.unitTable,
    })
  }
  // bulk update end

  // bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Unit",
        name: "unit_id",
        value: selections.map(value => { return value.unit_id }),
        deleted_by: getUserName()
      },
      dataTable: this.unitTable,
    })
  }
  // bulk delete end
  // bulk edit section end

  // add unit start
  setUnitFormInitValue = () => {
    this.setState({
      viewAttachments: false,
      unitForm: {
        ...this.state.unitForm,
        initValue: this.unitFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Add Unit', className: 'sdm-popup' })
      })
  }
  // add unit end

  // edit unit start
  editUnit = (ev, rowData) => {
    this.setState({
      viewAttachments: false,
      unitForm: {
        ...this.state.unitForm,
        initValue: {
          unit_id: rowData.unit_id,
          unit_name: rowData.unit_name,
          unit_desc: rowData.unit_desc,
          module_id: !isEmpty(rowData.unitmodules) ? rowData.unitmodules.map(module => module.module_id) : null,
          status_id: rowData.status_id,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Update Unit', className: 'sdm-popup' })
      })
  }
  // edit unit end

  // remove unit start
  removeUnit = async (id) => {
    await response.remove({
      service: this.unitService,
      method: 'removeUnit',
      data: { itemId: id },
      dataTable: this.unitTable,
    })
  }
  // remove unit end

  // remove attachment start
  removeAttachment = async (attachment) => {
    if (this.state.processingModule) {
      await response.remove({
        service: this.unitService,
        method: 'removeAttachment',
        data: { itemId: attachment.units_document_id },
        toasterMessage: {
          success: 'Attachment has been removed successfully',
          error: 'Unable to remove attachment'
        },
        modalPopupHide: false
      })
    }
    if (this.attachmentList.current)
      this.attachmentList.current.loadData()
  }
  // remove attachment end

  // view attachment start
  viewAttachments = (ev, rowData) => {
    this.setState({
      viewAttachments: true,
      processingModule: rowData,
      attachmentOptions: {
        ...this.state.attachmentOptions,
        urlPath: rowData.unit_id
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Unit Attachments', className: 'attachment-popup' })
      }
    )
  }
  // view attachment end

  // view gallery starts
  viewGallery = (ev, rowData) => {
    this.setState({ processingModule: rowData },
      () => {
        galleryPopup.toggle(true);
        galleryPopup.custom({ onAttachmentCopy: (attachment) => { this.addAttachment(attachment) } })
      })
  }
  // view gallery end

  // add attachment starts
  addAttachment = async (attachment) => {
    let attachmentData = {
      unit_id: null,
      document_name: null,
      created_by: getUserName()
    };

    if (attachment.file_name && attachment.file_type)
      attachmentData.document_name = attachment.file_name;
    if (this.state.processingModule && this.state.processingModule.unit_id)
      attachmentData.unit_id = this.state.processingModule.unit_id

    let apiResponse = await response.add({
      service: this.unitService,
      method: 'addAttachment',
      data: { item: attachmentData },
      dataTable: this.dataTableRef,
      toasterMessage: {
        success: 'Attachment has been added successfully',
        error: 'Unable to add attachment'
      }
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      galleryPopup.toggle(false);
    }
  }
  // add attachment end

  // attachment direct upload section start
  onAttachmentUpload = async (data, error) => {
    try {
      if (isEmpty(error)) {
        const formData = new FormData();

        Object.keys(data).forEach(key => {
          (key === "document_name") ? formData.append(key, data[key][0]) : formData.append(key, data[key]);
        });
        formData.set('unit_id', this.state.processingModule.unit_id);
        formData.append("created_by", getUserName());

        await response.add({
          service: this.unitService,
          method: 'addAttachment',
          data: { item: formData },
          modalPopupHide: false,
          toasterMessage: {
            success: "Attachment uploaded successfully. Continue uploading more attachments",
            error: "Error in uploading attachment. Please try again"
          }
        })
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // attachment direct upload section end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();
    dropdown.moduleList();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.unitTable} options={this.state.options} />
        <HFNModalPopup>
          {
            this.state.viewAttachments
              ?
              <HFNAttachments ref={this.attachmentList} options={this.state.attachmentOptions} dataTableRef={this.unitTable} />
              :
              <UnitForm initialValue={this.state.unitForm} dataTableRef={this.unitTable} />}
        </HFNModalPopup>
      </div>
    )
  }
}

export default Unit;
