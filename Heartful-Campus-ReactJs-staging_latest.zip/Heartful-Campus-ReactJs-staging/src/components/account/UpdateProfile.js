import React, { useState, useEffect } from 'react';

// components
// prime components
import { Button } from 'primereact/button';

// shared components
import HFNDynamicForm from 'shared-components/hfn-form/index';

// utils
import { isEmpty, isObject } from 'lodash';

import { validations } from 'utils/validations'

import { dropdown } from 'utils/dropdown';

import { response } from 'utils/response';

import { cityAutoCompleteTemplate, getUser, getUserID } from 'utils/common';

// services 
import UserService from 'services/user/user.service';

// config
import config from 'assets/config';

const UpdateProfile = (props) => {

  // variable init start
  const userUpdate = new UserService();
  // variable init end

  // state management start
  const [registerFormConfig] = useState({
    formClassName: 'register-form-wrapper',
    formSectionClassName: 'register-form-section',
    autoComplete: 'off',
  });

  const [registerFormInitialValue] = useState({
    abhyasi_id: (props.data !== null && props.data !== undefined) ? props.data.abhyasi_id : null,
    name: (props.data !== null && props.data !== undefined) ? props.data.name : null,
    email_address: (props.data !== null && props.data !== undefined) ? props.data.email_address : null,
    contact_number: (props.data !== null && props.data !== undefined) ? props.data.contact_number : null,
    address: (props.data !== null && props.data !== undefined) ? props.data.address : null,
    state: (props.data !== null && props.data !== undefined) ? props.data.state : null,
    city: (props.data !== null && props.data !== undefined) ? props.data.city : null,
    country_id: (props.data !== null && props.data !== undefined) ? props.data.country_id : null,
    pincode: (props.data !== null && props.data !== undefined) ? props.data.pincode : null,
    photo: (props.data !== null && props.data !== undefined) ? null : null,
    zone_id: (props.data !== null && props.data !== undefined) ? props.data.zone_id : null,
    password: (props.data !== null && props.data !== undefined) ? props.data.password : null,
    role_id: (props.data !== null && props.data !== undefined) ? props.data.role_id : null,
    status_id: (props.data !== null && props.data !== undefined) ? props.data.status_id : null
  });

  const [registerFormFields, setRegisterFormFields] = useState({

    name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {},
        validations: {
          required: validations.required,
        }
      },
    },

    email_address: {
      properties: {
        type: 'InputText',
        label: 'Email',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          keyfilter: 'email',
          readOnly: true
        },
        validations: {
          required: validations.required,
          pattern: validations.email
        }
      },
    },

    abhyasi_id: {

      properties: {
        type: 'InputText',
        label: 'Abhyasi ID',
        fieldWrapperClassNames: 'p-md-6',
        validations: {
          pattern: validations.abhyasiId
        }
      },

    },
    contact_number: {
      properties: {
        type: 'PhoneInput',
        label: 'Contact Number',
        fieldWrapperClassNames: 'p-md-6',
        validations: {
          required: validations.required,
        }
      },
    },

    photo: {
      properties: {
        type: 'ProfileUpload',
        label: 'Photo',
        fieldWrapperClassNames: 'p-md-12',
        hint: `Maximum allowed file size is ${config.profileImageMaxFIleSize}MB. Allowed types are jpg, jpeg and png`,
        primeFieldProps: {
          accept: ".jpg,.jpeg,.png",
          onChange: (file) => {
            if (file.target.files.length !== 0) {
              setRegisterFormFields({
                ...registerFormFields,
                imageCrop: {
                  ...registerFormFields.imageCrop,
                  properties: {
                    ...registerFormFields.imageCrop.properties,
                    visibility: true
                  }
                },
                previewImage: {
                  ...registerFormFields.previewImage,
                  properties: {
                    ...registerFormFields.previewImage.properties,
                    visibility: true
                  }
                }
              })
            } else {
              setRegisterFormFields({
                ...registerFormFields,
                imageCrop: {
                  ...registerFormFields.imageCrop,
                  properties: {
                    ...registerFormFields.imageCrop.properties,
                    visibility: false
                  }
                },
                previewImage: {
                  ...registerFormFields.previewImage,
                  properties: {
                    ...registerFormFields.previewImage.properties,
                    visibility: false
                  }
                }
              })
            }
          }
        },
        validations: {
          required: validations.required,
        }
      }
    },
    imageCrop: {
      properties: {
        type: 'imageCrop',
        label: 'Selected Image',
        visibility: false,
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          accept: ".jpg, .jpeg, .png"
        },
      }
    },
    previewImage: {
      properties: {
        type: 'previewImage',
        label: 'Preview Image',
        visibility: false,
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          accept: ".jpg, .jpeg, .png"
        },
      }
    },

    address: {
      properties: {
        type: 'InputTextarea',
        label: 'Address',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        }
      },
    },

    city: {
      properties: {
        type: 'CityAutoComplete',
        label: 'City',
        fieldWrapperClassNames: 'p-md-6',
        searchField: 'name',
        fieldLabel: 'name',
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        },
        stateField: {
          label: 'State',
          fieldName: 'state',
          fieldWrapperClassNames: 'p-md-6',
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required
          }
        },
        countryField: {
          label: 'Country',
          fieldName: 'country_id',
          fieldWrapperClassNames: 'p-md-6',
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required
          },
          dropdownOptions: "country"
        }
      },
    },


    pincode: {
      properties: {
        type: 'InputText',
        label: 'Pincode',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          keyfilter: 'alphanum'
        },
        validations: {
          required: validations.required,
        }
      }
    },

    zone_id: {
      properties: {
        type: 'SelectDropdown',
        label: 'Zone',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          isSearchable: true,
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "zone"

      }
    },

  });
  // state management start

  useEffect(() => {
    dropdown.zone();
    dropdown.country();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // form button group section start
  const registerSubmitButtonGroup = () => {
    return (
      <div className="p-d-flex p-jc-end p-mt-3 p-pr-2">
        <Button type="Submit" label="Update" className="p-button-success" />
      </div>
    )
  };
  // form button group section end

  // form submit section start
  const registerFormOnsubmit = async (data, err) => {
    if (isEmpty(err)) {
      try {
        let formData = new FormData();

        formData.append("_method", "PUT");
        formData.append("updated_by", getUser().email);
        Object.keys(data).forEach(key => {
          if (key === "photo") {
            if (data[key][0]) {
              formData.append(key, data[key])
            }
          }
          else {
            formData.append(key, data[key])
          }
        });

        let apiResponse = await response.update({
          service: userUpdate,
          method: 'updateUserProfile',
          data: { itemId: getUserID(), item: formData },
          toasterMessage: {
            success: 'User updated successfully',
            error: 'User not updated'
          }
        });

        if (apiResponse && apiResponse.data && !apiResponse.data.isError && isObject(apiResponse.data.data)) {
          props.setuserInfo(apiResponse.data.data);
        }
      } catch (err) {
        console.log(err)
      }
    }

  };
  // form submit section start

  return (

    <div className='login-section register-section'>
      <div className="card-wrapper">
        <div className="register">
          <HFNDynamicForm
            formConfig={registerFormConfig}
            initialValues={registerFormInitialValue}
            fields={registerFormFields}
            onFormSubmit={registerFormOnsubmit}
            submitButtonGroup={registerSubmitButtonGroup}>
          </HFNDynamicForm>

        </div>

      </div>
    </div>
  )

}

export default UpdateProfile;
