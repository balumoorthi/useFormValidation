import React, { useState } from "react";

// utils
import { isEmpty } from 'lodash';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// components
// shared components
import HFNDynamicForm from "shared-components/hfn-form/index";

// services
import FaqService from 'services/faq/faq.service';

// config
import config from 'assets/config';

const FaqForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const faqService = new FaqService()
  // variable init end

  // state management start

  // validations start
  const [FaqFormFields] = useState({
    question: {
      properties: {
        type: 'InputText',
        label: 'Question',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        }
      }
    },
    answer: {
      properties: {
        type: 'RichTextEditor',
        label: 'Answer',
        primeFieldProps: {
          config: {
            toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'blockQuote', 'undo', 'redo']
          }
        },
        validations: {
          required: validations.required,
        }
      }
    },
    faq_category_id: {
      properties: {
        type: 'Dropdown',
        label: 'Category',
        primeFieldProps: {
          filter: true,
          showClear: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "faqCategoryList"
      }
    },
    faq_document: {
      properties: {
        type: 'FileUpload',
        label: 'File',
        visibility: !isEditable,
        hint: `Maximum allowed file size is ${config.maxAllowedFileSize}MB`,
        primeFieldProps: {
          accept: "application/pdf , application/msword ,.jpg ,.png, .jpeg",
        },
      }
    },
    faq_video_link: {
      properties: {
        type: 'InputText',
        label: 'Youtube video code (Embed)',
        primeFieldProps: {

        },
      }
    },
    faq_display_type: {
      properties: {
        type: 'Dropdown',
        label: 'Visibility type',
        primeFieldProps: {
          options: [
            {
              label: "General",
              value: "GENERAL"
            },
            {
              label: "College Staff",
              value: "COLLEGESTAFF"
            },
          ]
        },
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {
          options: [
            { label: "Active", value: 1 },
            { label: "In Active", value: 2 },
          ]
        },
        validations: {
          required: validations.required,
        }
      }
    }
  });
  // validations end

  // state management end

  // faq form section start 

  // form submit section start

  const FaqFormOnsubmit = (data, error) => {
    let Formdata = { ...initValue, ...data }
    if (isEmpty(error)) {
      Formdata = getUserName(isEditable, Formdata);
      addUpdateFaq(Formdata)
    }
  }

  // form submit section end

  // add new and update faq section start
  const addUpdateFaq = async (data) => {
    try {
      const formData = new FormData();

      Object.keys(data).forEach(key => {
        if (key === "faq_document") {
          if (data[key][0]) {
            formData.append(key, data[key][0])
          }
        }
        else
          formData.append(key, data[key])
      });

      if (isEditable) {
        formData.append("_method", "PUT");
        formData.delete('faq_document')
      }
      if (!isEditable) {
        await response.add({
          service: faqService,
          method: 'addFAQ',
          data: { item: formData },
          dataTable: dataTableRef,
        })
      } else {
        await response.update({
          service: faqService,
          method: 'updateFAQ',
          data: { itemId: initValue.faq_id, item: data },
          dataTable: dataTableRef,
        })
      }
    } catch {
      console.log("Something went wrong.");
    }


  }
  // add new and update faq section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={FaqFormFields} onFormSubmit={FaqFormOnsubmit} >
      </HFNDynamicForm>
    </div>
  );

}

export default FaqForm;
