import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { statusBadge, createdDateBadge, faqVisibilityBadge, htmlConvertor } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { dropdown } from 'utils/dropdown';

import { bulk } from "utils/bulk";

import { getModuleAccess, getUserName, getUserType } from "utils/common";

// components
import FaqForm from 'components/faq/FaqForm';

// prime components 

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import FaqService from 'services/faq/faq.service';


class FAQ extends Component {

  constructor(props) {

    super(props);

    // variable init starts
    this.faqService = new FaqService();

    this.faqTable = React.createRef(null);

    this.faqFormInitValue = {
      faq_id: null,
      question: null,
      answer: null,
      sort_order: 1,
      status_id: null,
      faq_category_id: null,
      faq_video_link: null,
      faq_display_type: "GENERAL"
    }
    // variable init end

    this.state = {

      faqForm: {
        isEditable: false,
        initValue: this.faqFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "FAQ", url: "faq", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("FAQ"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.faqService,

        method: 'getFAQList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Question',
            field: 'question',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Answer',
            field: 'answer',
            sortable: true,
            filter: true,
            body:htmlConvertor,
            headerStyle: {
              width: "200px"
            }
          },
          {
            header: 'Category',
            field: 'faqcategory.category',
            sortField: "SortingDisabled",
            headerStyle: {
              width: "150px"
            }
          },
          {
            header: 'Visibility',
            field: 'faq_display_type',
            sortable: true,
            filter: true,
            headerStyle: {
              width: "150px"
            },
            body: faqVisibilityBadge
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            headerStyle: {
              width: '140px'
            },
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: 'generalStatus'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '160px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'update',
            onClick: this.editFAQ
          },
          {
            type: 'delete',
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this FAQ?",
                accept: () => { this.removeFAQ(rowData.faq_id); }
              });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'FAQ List',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of FAQs?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these FAQs?" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setFAQFormInitValue }
          ]
        },
        enableSelection: true,
      }

      // datatables 

    }
  }

  // bulk status update starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Faq",
        name: "faq_id",
        value: selections.map(value => { return value.faq_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.faqTable,
    })
  }

  // bulk status update end

  // bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Faq",
        name: "faq_id",
        value: selections.map(value => { return value.faq_id }),
        deleted_by: getUserName()
      },
      dataTable: this.faqTable,
    })
  }

  // bulk delete end

  // FAQ Form Inti Starts
  setFAQFormInitValue = () => {
    this.setState({
      faqForm: {
        ...this.state.faqForm,
        initValue: this.faqFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Add FAQ' })
      })
  }
  // FAQ Form Inti end

  // Edit FAQ start
  editFAQ = (ev, rowdata) => {
    this.setState({
      faqForm: {
        ...this.state.faqForm,
        initValue: {
          faq_id: rowdata.faq_id,
          question: rowdata.question,
          answer: rowdata.answer,
          sort_order: rowdata.sort_order,
          status_id: rowdata.status_id,
          faq_category_id: rowdata.faq_category_id,
          faq_video_link: rowdata.faq_video_link,
          faq_display_type: rowdata.faq_display_type,
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Update FAQ' })
      })
  }
  // Edit FAQ end

  // Remove FAQ start
  removeFAQ = async (id) => {
    await response.remove({
      service: this.faqService,
      method: 'removeFAQ',
      data: { itemId: id },
      dataTable: this.faqTable,
    })
  }
  // Remove FAQ end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();
    dropdown.faqCategoryList({user_type:getUserType()});
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.faqTable} options={this.state.options} />
        <HFNModalPopup>
          <FaqForm initialValue={this.state.faqForm} dataTableRef={this.faqTable} />
        </HFNModalPopup>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(FAQ));