import React, { useState } from "react";

// state 

// storage 

// utils 

import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import TrainerService from "services/trainer/trainer.service";

const SessionForm = props => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue } = initialValue;
  // props destructure end

  // variable init start 
  const trainerService = new TrainerService()
  // variable init end

  // state management start

  // validations start
  const [sessionFormFields] = useState({
    comments: {
      properties: {
        type: 'InputText',
        label: 'Comments',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
          readOnly: true
        },
      }
    },
    event_start_date: {
      properties: {
        type: 'InputText',
        label: 'Start Date',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
          readOnly: true
        },
      }
    },
    event_end_date: {
      properties: {
        type: 'InputText',
        label: 'End Date',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
          readOnly: true
        },
      }
    },
    user_info_id: {
      properties: {
        // type: 'Dropdown',
        type: 'MultiSelectDropdown',
        label: 'Trainer',
        primeFieldProps: {
          filter: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "trainer"
      }
    },
  });
  // validations end

  // state management end  

  // form submit start

  const sessionFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      updateChangeRequest(formData)
    }
  }

  // form submit end

  // update Change Request start

  const updateChangeRequest = async (formData) => {
    const data = {
      request_id: formData.request_id,
      user_info_id: formData.user_info_id,
      session_id: formData.session_id,
      updated_by: getUserName()
    }

    await response.add({
      service: trainerService,
      method: 'updateChangeRequest',
      data: { item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Successfully assigned trainer",
        error: "Unable to assign trainer"
      }
    })
  }

  // update Change Request end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={sessionFormFields} onFormSubmit={sessionFormOnsubmit} />
    </div>
  );
}

export default SessionForm;