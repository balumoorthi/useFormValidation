import React, { Component } from 'react';

import { withRouter } from 'react-router';

// state 
import { connect } from "react-redux";

// components
import SessionForm from 'components/program/changeRequest/SessionForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// utils
import { modalPopup } from "utils/modalPopup";

import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from "utils/dropdown";

import { toaster } from "utils/toaster";

import { getUserRole } from "utils/common";

// services
import TrainerService from "services/trainer/trainer.service";

import { crStatusBadge, createdDateBadge , startDateValidate , sessionDateBadge} from "utils/badgeTemplate";

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

import moment from 'moment';

class ChangeRequest extends Component {

  constructor(props) {
    super(props);

    // variable init starts
    this.trainerService = new TrainerService();

    this.changeRequestTable = React.createRef(null);

    localStorage.setItem('moduleName', 'changerequest');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['changerequest'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Change Request", url: "program/changerequest", },
      ],

      sessionForm: {
        initValue: {},
      },
      // variable init end

      //datatables
      options: {

        privilege: {
          isActive: false,
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getChangeRequests',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'session_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Program',
            field: 'program_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'College',
            field: 'college_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Trainer',
            field: 'trainer_name',
            sortField: "SortingDisabled",
            filter: false,
            headerStyle: {
              width: '150px'
            },
          },
          {
            header: 'Comments',
            field: 'comments',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Start Date',
            field: 'event_start_date',
            sortField: "SortingDisabled",
            filter: false,
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'End Date',
            field: 'event_end_date',
            sortField: "SortingDisabled",
            filter: false,
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "programReportStatus"
            },
            headerStyle: {
              width: '150px'
            },
            body: crStatusBadge
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: false,
            headerStyle: {
              width: '150px'
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            type: 'update',
            icon: "pi pi-user-edit edit-icon",
            className: "p-mr-2 assignCRTrainer",
            title: 'Assign trainer to session',
            visibilityCheck: rowData => (rowData.status_id === 1 && startDateValidate(rowData.event_start_date)),
            onClick: this.editSessionAssignment
          },
          {
            visibility: false
          }
        ],

        toolBarBtnOptions: {
          title: 'Change Requests',
          rightBtnsOptions: [
            { visibility: false }
          ]
        }

      },
    }
  }

  // edit session section starts
  editSessionAssignment = (ev, rowData) => {

    if (rowData.status_id !== 1) {
      toaster.info("Change request has already been processed")
      return
    }

    /* let trainerSearchInput = {
      user_id: rowData.user_info_id,
      session_id: rowData.session_id
    }

    dropdown.trainer(trainerSearchInput); */
   let startDate = new Date(rowData.event_start_date)
   let endDate = new Date(rowData.event_end_date)
    this.setState({
      sessionForm: {
        initValue: {
          request_id: rowData.request_id,
          session_id: rowData.session_id,
          user_info_id: rowData.user_info_id,
          comments: rowData.comments,
          event_start_date: (!isNaN(startDate)) ? moment(startDate).format('MMM DD, YYYY hh:mm A') : "-",
          event_end_date: (!isNaN(endDate)) ? moment(endDate).format('MMM DD, YYYY hh:mm A') : "-",
        }
      },
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Assign Trainer', className: "sdm-popup trainer-assign" })
      })
  }
  // edit session section end

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.trainer({});
    dropdown.programReportStatus();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.changeRequestTable} options={this.state.options} />
        <HFNModalPopup>
          <SessionForm initialValue={this.state.sessionForm} dataTableRef={this.changeRequestTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default withRouter(connect()(ChangeRequest));