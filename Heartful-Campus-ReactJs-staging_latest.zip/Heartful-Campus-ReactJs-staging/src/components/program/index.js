import React, { Component } from 'react';

import { Switch, } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import ProgramListing from 'components/program/listing';

import ProgrameReports from 'components/program/reports';

import ChangeRequest from 'components/program/changeRequest';

import Participant from 'components/college/collegeDetails/program/participant';

import Session from 'components/college/collegeDetails/program/session';

// shared components 
import HFNLoader from 'shared-components/lazyLoading';

export default class Program extends Component {
  render() {
    return (
      <div>
        <HFNLoader>
          <Switch>
            <AuthGuard path='/program/listing' component={ProgramListing} />
            <AuthGuard path='/program/reports' component={ProgrameReports} />
            <AuthGuard exact path='/program/:programID/session' component={Session} />
            <AuthGuard path='/program/:programID/session/:sessionID/participant' component={Participant} />
            <AuthGuard path='/program/changerequest' component={ChangeRequest} />
          </Switch>
        </HFNLoader>
      </div>
    )
  }
}