import React, { Component } from "react";

// components
//shared-components
import ReportForm from "shared-components/report";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from "utils/dropdown";

// services
import ProgramService from "services/program/program.service";

class SessionReport extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.programService = new ProgramService();
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: "pi pi-home" },
        { label: "Session Report", url: "program/reports" }
      ],

      initialValues: {},

      options: {

        title: "Session Report",

        service: this.programService,

        method: "programReport",

        rows: 1000,

        timestampSuffix: "DDMMYYYY",

        fileName: "Session_Report",

        columns: [
          {
            label: "Country",
            key: "country"
          },
          {
            label: "State",
            key: "state"
          },
          {
            label: "City",
            key: "city"
          },
          {
            label: "College",
            key: "college_name"
          },
          {
            label: "Program",
            key: "cart_name"
          },
          {
            label: "Session",
            key: "module_name"
          },
          {
            label: "Trainer",
            key: "trainer_name"
          },
          {
            label: "Start Date",
            key: "event_start_date"
          },
          {
            label: "End Date",
            key: "event_end_date"
          },
          {
            label: "Count of Participant",
            key: "participant_count"
          }
        ]
      },

      formFields: {

        cart_name: {
          properties: {
            type: "InputText",
            label: "Program",
            fieldWrapperClassNames: "p-md-3"
          }
        },

        from_date: {
          properties: {
            type: "Calendar",
            label: "From Date",
            fieldWrapperClassNames: "p-md-3",
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          }
        },

        to_date: {
          properties: {
            type: "Calendar",
            label: "To Date",
            fieldWrapperClassNames: "p-md-3",
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          }
        },

        user_info_id: {
          properties: {
            // type: "Dropdown",
            type: "MultiSelect",
            label: "Trainer",
            fieldWrapperClassNames: "p-md-3",
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: "trainer"
          }
        },

        status: {
          properties: {
            type: "Dropdown",
            label: "Status",
            fieldWrapperClassNames: "p-md-3",
            primeFieldProps: {
              showClear: true,
              options: [
                { label: "Upcoming", value: "upcoming" },
                { label: "Completed", value: "completed" }
              ]
            }
          }
        }

      }      
    };
    // state management end
  }

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.trainer();
  }

  render() {
    return (
      <div>
        <ReportForm fields={this.state.formFields} initialValues={this.state.initialValues} options={this.state.options} />
      </div>
    )
  }
}

export default SessionReport;
