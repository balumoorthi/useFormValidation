import React, { Component } from "react";

// components 
import Module from "components/program/listing/draftProgram/module";

import Unit from "components/program/listing/draftProgram/unit";

// utils 
import { response } from "utils/response";

import { uniqBy } from "lodash";

// services 
import CollegeCartService from "services/college/cart.service";

class DraftProgram extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.cartService = new CollegeCartService();
    // variable init end

    // state management start
    this.state = {

      modules: [],

      units: []

    };
    // state management end
  }

  // get program data section start
  getProgramData = async () => {
    try {
      let apiResponse = await response.getList({
        service: this.cartService,
        method: "getCollegeStatus",
        params: { college_id: this.props.program.college_id }
      });

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        const programData = apiResponse.data.data;

        if (Array.isArray(programData.items) && programData.items[0] && programData.items[0].cart_details) {
          const programItems = JSON.parse(programData.items[0].cart_details);

          this.setState({
            modules: uniqBy(programItems.modules, "module_id").map(module => {
              if (!module.discipline_name && module.disciplines && module.disciplines.discipline_name)
                module.discipline_name = module.disciplines.discipline_name;
              if (!module.level_name && module.levels && module.levels.level_name)
                module.level_name = module.levels.level_name;
              if (!module.program_type_name && module.program_types && module.program_types.program_type_name)
                module.program_type_name = module.program_types.program_type_name;
              if (!module.unit_name && Array.isArray(module.unitmodules)) {
                const moduleUnit = module.unitmodules.find(unit => (unit.units && unit.units.unit_name));
                if (moduleUnit)
                  module.unit_name = moduleUnit.units.unit_name;
              }
              return module;
            }),
            units: programItems.units
          });
        }
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // get program data section end

  componentDidMount() {
    this.getProgramData();
  }

  render() {
    return (
      <>
        <div className="p-mb-4">
          <div className="p-toolbar">
            <div className="datatable-title">
              <h4>Modules</h4>
            </div>
          </div>
          <Module modules={this.state.modules} />
        </div>
        <div className="p-mb-4">
          <div className="p-toolbar">
            <div className="datatable-title">
              <h4>Units</h4>
            </div>
          </div>
          <Unit units={this.state.units} />
        </div>
      </>
    )
  }
}

export default DraftProgram;
