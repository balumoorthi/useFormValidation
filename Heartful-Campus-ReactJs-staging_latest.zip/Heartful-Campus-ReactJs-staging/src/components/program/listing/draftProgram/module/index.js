import React, { Component } from "react";

// components
// primereact components 
import { DataTable } from "primereact/datatable";

import { Column } from "primereact/column";

import { confirmDialog } from "primereact/confirmdialog";

// shared component 
import HFNDataTablePagination from "shared-components/datatable/HFNDataTablePagination";

// utils 
import { downloadFile } from "utils/common";

import { response } from "utils/response";

import { toaster } from "utils/toaster";

// services 
import ModuleService from "services/module/module.service";

// config
import config from "assets/config";

// constants

const assetFolder = "digital-asset";

class Module extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.moduleService = new ModuleService();
    // variable init end

    // state management start
    this.state = {

      lazyParams: {
        first: 0,
        rows: 5,
        page: 1,
        filters: {}
      },

      pagination: {

        prevPageLink: {
          isPrevPageLink: true,
          classNames: ""
        },

        nextPageLink: {
          isNextPageLink: true,
          classNames: ""
        },

        pageLinks: {
          isPageLinks: true,
          classNames: ""
        },

        rowsPerPageDropdown: {
          isRowPerPage: true,
          dropdownOptions: [
            { label: 5, value: 5 },
            { label: 10, value: 10 },
            { label: 20, value: 20 },
            { label: 50, value: 50 }
          ],
          classNames: ""
        },

        currentPageReport: {
          isPageResult: true,
          isPageNavigator: false,
          classNames: ""
        }

      }

    };
    // state management end

  }

  // datatable templates section start
  // default template section start
  defaultTemplate = (rowData, { field }) => {
    const fieldValue = field.split(".").reduce((o, k) => o && o[k], rowData);
    return fieldValue ? <div title={fieldValue}> {fieldValue} </div> : "-";
  }
  // default template section end

  // module template section start
  moduleTemplate = rowData => {
    return (
      <div className="info-section" title={rowData.module_name}>
        <span className="info">{rowData.module_name}</span>
        <span className="info-icon" onClick={() => { this.moduleInfo(rowData) }} > <i className="uil uil-info-circle"></i> </span>
      </div>
    )
  }
  // module template section end

  // download template section start
  downloadTemplate = rowData => {
    return (
      <p style={{ cursor: "pointer" }}>
        <u onClick={() => { this.downloadModuleAttachments(rowData) }}> Download </u>
      </p>
    );
  }
  // download template section end
  // datatable templates section end

  // module info popup section start
  moduleInfo = moduleInfo => {
    confirmDialog({
      message: moduleInfo.module_desc,
      header: moduleInfo.module_name,
      className: "module-confirm-popup mcp-desc"
    });
  }
  // module info popup section end

  // download module attachments section start
  downloadModuleAttachments = async (module) => {
    try {
      let apiResponse = await response.get({
        service: this.moduleService,
        method: "listAttachments",
        data: { itemId: module.module_id }
      });

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && Array.isArray(apiResponse.data.data)) {
        const apiResponseData = apiResponse.data.data;

        if (apiResponseData.length > 0) {
          apiResponseData.forEach(attachment => {
            downloadFile(config.mediaURL + assetFolder + "/" + attachment.document_name, attachment.document_name);
          });
        }
        else {
          toaster.info(`This "${module.module_name}" module does not have any attachments`)
        }
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // download module attachments section end

  render() {
    return (
      <div>
        <div className="hfn-datatable hfn-datatable-lazy">
          <DataTable
            value={this.props.modules}
            lazy={false}
            paginator
            paginatorTemplate={HFNDataTablePagination(this.state.pagination)}
            rows={this.state.lazyParams.rows}
            totalRecords={this.props.modules.length}
            autoLayout={true}
          >
            <Column field="module_name" header="Module" sortable filter filterMatchMode="contains" body={this.moduleTemplate} />
            <Column field="discipline_name" header="Discipline" body={this.defaultTemplate} sortable filter filterMatchMode="contains" />
            <Column field="level_name" header="Level" body={this.defaultTemplate} sortable filter filterMatchMode="contains" />
            <Column header="Downloads" body={this.downloadTemplate} sortable sortableDisabled style={{ minWidth: "100px" }} />
            <Column field="program_type_name" header="Program Type" body={this.defaultTemplate} sortable filter filterMatchMode="contains" style={{ minWidth: "240px" }} />
          </DataTable>
        </div>
      </div>
    )
  }
}

export default Module;
