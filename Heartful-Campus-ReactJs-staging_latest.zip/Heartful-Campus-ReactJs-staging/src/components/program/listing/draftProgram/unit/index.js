import React, { Component } from "react";

// components 
import UnitModuleListing from "components/college/cart/unitModuleListing";

// primereact components 
import { DataTable } from "primereact/datatable";

import { Column } from "primereact/column";

import { Dialog } from "primereact/dialog";

import { confirmDialog } from "primereact/confirmdialog";

// shared component 
import HFNDataTablePagination from "shared-components/datatable/HFNDataTablePagination";

class Unit extends Component {

  constructor(props) {

    super(props);

    // state management start
    this.state = {

      lazyParams: {
        first: 0,
        rows: 5,
        page: 1,
        filters: {}
      },

      pagination: {

        prevPageLink: {
          isPrevPageLink: true,
          classNames: ""
        },

        nextPageLink: {
          isNextPageLink: true,
          classNames: ""
        },

        pageLinks: {
          isPageLinks: true,
          classNames: ""
        },

        rowsPerPageDropdown: {
          isRowPerPage: true,
          dropdownOptions: [
            { label: 5, value: 5 },
            { label: 10, value: 10 },
            { label: 20, value: 20 },
            { label: 50, value: 50 }
          ],
          classNames: ""
        },

        currentPageReport: {
          isPageResult: true,
          isPageNavigator: false,
          classNames: ""
        }

      },

      unitID: null,

      unitName: null

    };
    // state management end

  }

  // datatable templates section start
  // unit template section start
  unitTemplate = rowData => {
    return (
      <div className="info-section" title={rowData.unit_name}>
        <span className="info">{rowData.unit_name}</span>
        <span className="info-icon" onClick={() => { this.unitInfo(rowData); }} > <i className="uil uil-info-circle"></i> </span>
      </div>
    )
  }
  // unit template section end

  // show modules template section start
  showModulesTemplate = rowData => {
    return (
      <div className="show-modules-link">
        <p onClick={() => {
          this.setState({ unitName: rowData.unit_name, unitID: rowData.unit_id }, () => { this.toggleUnitModulesPopup(); });
        }}
        >
          <u style={{ cursor: "pointer" }}>Show Modules for this Unit</u>
        </p>
      </div>
    )
  }
  // show modules template section end
  // datatable templates section end

  // unit info popup section start
  unitInfo = unitInfo => {
    confirmDialog({
      message: unitInfo.unit_desc,
      header: unitInfo.unit_name,
      className: "module-confirm-popup mcp-desc"
    });
  }
  // unit info popup section end

  // unit modules popup section start
  toggleUnitModulesPopup = () => {
    this.setState({ unitModulesPopup: !this.state.unitModulesPopup });
  }
  // unit modules popup section end

  render() {
    return (
      <div>
        <div className="hfn-datatable hfn-datatable-lazy">

          <DataTable
            value={this.props.units}
            lazy={false}
            paginator
            paginatorTemplate={HFNDataTablePagination(this.state.pagination)}
            rows={this.state.lazyParams.rows}
            totalRecords={this.props.units.length}
            autoLayout={true}
          >
            <Column field="unit_name" header="Unit" sortable filter filterMatchMode="contains" body={this.unitTemplate} />
            <Column header="Show Modules" body={this.showModulesTemplate} sortable sortableDisabled />
          </DataTable>

          <Dialog header={this.state.unitName} visible={this.state.unitModulesPopup} onHide={this.toggleUnitModulesPopup} className={"cart-popup"}>
            <UnitModuleListing unitID={this.state.unitID} />
            <div className="p-text-right p-mt-3">
              <button className="p-button p-button-secondary" onClick={this.toggleUnitModulesPopup} > Cancel </button>
            </div>
          </Dialog>

        </div>
      </div>
    )
  }
}

export default Unit;
