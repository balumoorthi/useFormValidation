import React, { Component } from 'react';

import { withRouter } from "react-router";

// components
import ProgramListing from 'components/program/listing/ProgramListing';

import ProgrameReports from 'components/program/reports';

import ChangeRequest from 'components/program/changeRequest';

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { getModuleAccess, getUserType } from "utils/common";

// services 
import ProgramService from 'services/program/program.service';

// prime components 
import { TabView, TabPanel } from 'primereact/tabview';

class ManageProgram extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.programService = new ProgramService();

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Program", url: "", },
      ]
    };
    // state management end
  }

  // list tabs based on privilege start
  listVisibleTabs = () => {
    let tabs = [
      {
        component: <ProgramListing />,
        header: "Program List"
      },
      {
        component: <ProgrameReports />,
        header: "Reports",
        slug: "reports",
        module: "PROGRAM"
      },
      {
        component: <ChangeRequest />,
        header: "Change Request",
        slug: "changerequest",
        module: "PROGRAM"
      }
    ]

    if (getUserType() === "U" || getUserType() === "POC") {
      tabs = tabs.filter(tab => {
        if (tab.slug) {
          const moduleAccess = getModuleAccess(tab.module) || {};
          return Array.isArray(moduleAccess.access) ? moduleAccess.access.includes(tab.slug) : false;
        }
        return true;
      });
    }

    return tabs.map(tab => <TabPanel key={tab.header} header={tab.header}>{tab.component}</TabPanel>)
  }
  // list tabs based on privilege end

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
  }

  render() {
    return (
      <div>
        <div className='tab-section program-tab-section'>
          <TabView activeIndex={this.state.activeIndex} onTabChange={(e) => this.setState({ activeIndex: e.index })}>
            {this.listVisibleTabs()}
          </TabView>
        </div>
      </div>
    )
  }
}

export default withRouter(ManageProgram);
