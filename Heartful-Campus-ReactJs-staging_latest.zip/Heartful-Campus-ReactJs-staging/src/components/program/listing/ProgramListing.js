import React, { Component } from 'react';

import { withRouter } from "react-router";

// components
import DraftProgram from "components/program/listing/draftProgram";

import SessionEditForm from 'components/college/collegeDetails/program/session/SessionEditForm';

import ProgramEditForm from 'components/college/collegeDetails/program/ProgramEditForm';

// prime components 
import { Button } from 'primereact/button';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { programStatusBadge, createdDateBadge, gotoPage, totalHoursBadge, participantCountBadge } from "utils/badgeTemplate";

import { modalPopup } from 'utils/modalPopup';

import { confirmDialog } from "utils/confirmDialog";

import { bulk } from "utils/bulk";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { getUserName, getModuleAccess, getUser, getUserID, getUserType } from "utils/common";

import { toaster } from "utils/toaster";

// services 
import ProgramService from 'services/program/program.service';

class ProgramListing extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.programService = new ProgramService();

    this.programTable = React.createRef();

    const moduleAccess = getModuleAccess("PROGRAM") || {};
    const enableViewLink = Array.isArray(moduleAccess.access) ? moduleAccess.access.includes("view") : false;
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Program", url: "", },
      ],

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("PROGRAM"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.programService,

        method: 'getProgramList',

        params: {
          manage_state: (getUser().role_slug === 'state-coordinator') ? getUser().state : undefined,
          manage_zone: (getUser().role_slug === 'zone-coordinator') ? getUser().zone : undefined,
          poc_id: (getUser().type === 'POC') ? getUserID() : undefined,
          role: getUser() ? getUser().role_slug : undefined
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Program',
            field: 'cart_name',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
            body: enableViewLink ? (rowData, { field }) => { return gotoPage(rowData, field, this.gotoSession); } : null
          },
          {
            header: 'College',
            field: 'college_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortField: "SortingDisabled",
            filter: true,
            body: programStatusBadge,
            filterType: 'select',
            headerStyle: {
              width: '150px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "programStatus"
            }
          },
          {
            header: 'Total Hours',
            sortable: true,
            field: 'total_hours',
            headerStyle: {
              width: '125px'
            },
            body: totalHoursBadge
          },
          {
            header: 'Participants',
            field: 'participant_count',
            sortField: "SortingDisabled",
            body: participantCountBadge,
            headerStyle: {
              width: '175px'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'update',
            icon: "uil uil-edit edit-icon",
            className: "p-mr-2",
            title: 'Edit Program',
            onClick: this.editProgram
          },
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-mr-2 p-button-icon-only",
            title: "View Sessions",
            onClick: this.gotoSession
          },
          {
            type: 'create',
            icon: "pi pi-user-plus edit-icon",
            className: "p-mr-2",
            title: 'Add Participant Count',
            onClick: this.addParticipantCount,
            visibilityCheck: rowData => (rowData.status_id === 6) ? true : false,
            visibility: (getUserType() === "U") ? "true" : false
          },
          {
            type: 'delete',
            title: "Delete Program",
            icon: "uil uil-trash-alt remove-icon",
            className: "p-mr-2",
            onClick: (ev, rowData) => {
              let programID = rowData.cart_id;
              if (programID) {
                confirmDialog.toggle(true)
                confirmDialog.custom({
                  message: "Are you sure you want to delete this program? Program will be deleted from Trainers account as well",
                  accept: () => { this.removeProgram(programID) }
                });
              }
            }
          },
        ],

        toolBarBtnOptions: {
          title: 'Program List',
          selection: {
            field: {
              options: "programStatus"
            },
            enableUpdate: false,
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "Are you sure you want to delete these programs? Programs will be deleted from Trainers account as well",
                  accept: () => { this.bulkDelete(selections) }
                });
              }
            },
          },
          rightBtnsOptions: [
            { visibility: false }
          ]
        },
        enableSelection: true
      },

      program: {}
    };
    // state management end
  }

  // Edit Program Section starts
  editProgram = (ev, rowdata) => {
    this.setState({programOpen:true})
    this.setState({
      programEdit: {
        initValue: {
          cart_id: rowdata.cart_id,
          cart_name: rowdata.cart_name
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Edit Program', className: "sdm-popup" });
      }
    )
  }
  // Edit Program Section ends

  // bulk status update start
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Cart",
        name: "cart_id",
        value: selections.map(value => { return value.cart_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.programTable,
    })
  }

  // bulk delete start
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Cart",
        name: "cart_id",
        value: selections.map(value => { return value.cart_id }),
        deleted_by: getUserName()
      },
      dataTable: this.programTable,
    })
  }
  // bulk delete end

  // Remove Program start
  removeProgram = async (id) => {
    if (id) {
      await response.remove({
        service: this.programService,
        method: 'removeProgram',
        data: { itemId: id },
        dataTable: this.programTable,
      })
    }
  }
  // Remove Program end

  // goto session start 
  gotoSession = (ev, rowData) => {
    if (rowData.status_id === 5) {
      toaster.info("The program was cancelled");
    }
    else if (rowData.status_id === 1) {
      this.setState({
        program: rowData
      },
        () => {
          modalPopup.toggle(true);
          modalPopup.custom({
            header: rowData.cart_name || "",
            className: 'draft-program-popup',
            footer: (
              <div className="p-text-right">
                <Button type="button" className='p-button p-button-secondary p-mr-2' label="Close" onClick={() => { modalPopup.toggle(false); }} />
              </div>
            )
          });
        });
    }
    else {
      const programID = rowData.cart_id;
      if (programID)
        this.props.history.push(`/program/${programID}/session`);
    }
  }
  // goto session end 

  // add participant section start
  addParticipantCount = (ev, rowdata) => {
    this.setState({sessionOpen:true})
    this.setState({
      sessionEdit: {
        initValue: {
          cart_id: rowdata.cart_id,
          cart_name: rowdata.cart_name,
          manual_participant_count: rowdata.manual_participant_count
        },
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: 'Add Participant Count', className: "sdm-popup" });
      }
    )
  }
  // add participant section end

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.programStatus();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.programTable} options={this.state.options} />
        <HFNModalPopup>
          {/* <DraftProgram program={this.state.program} /> */}
          {this.state.sessionOpen ? 
          <SessionEditForm  initialValue={this.state.sessionEdit} dataTableRef={this.programTable}/>:
          (this.state.programOpen) ?
          <ProgramEditForm  initialValue={this.state.programEdit} dataTableRef={this.programTable}/>
          :<DraftProgram program={this.state.program} />
          }
        </HFNModalPopup>
      </div>
    )
  }
}

export default withRouter(ProgramListing);
