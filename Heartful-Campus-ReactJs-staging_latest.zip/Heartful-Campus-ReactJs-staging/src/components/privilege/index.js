import React, { Component } from 'react';

import { withRouter } from "react-router";

// state
import { connect } from "react-redux";

// prime components
import { Dropdown } from 'primereact/dropdown';

import { Button } from 'primereact/button';

import { Checkbox } from 'primereact/checkbox';

// utils
import buildBreadcrumb from "utils/breadcrumb";

import { response } from 'utils/response';

import { lStorage } from 'utils/storage';

// services
import PrivelegeService from 'services/privilege/privilege.service';

import DropdownService from 'services/dropdown/dropdown.service';

class Privileges extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.privelegeService = new PrivelegeService();

    this.dropdownService = new DropdownService();

    this.addingPrivileges = this.addingPrivileges.bind(this);

    this.onRoleChange = this.onRoleChange.bind(this);
    // variable init end

    // state management start
    this.state = {

      privilegeList: [],

      roleData: '',

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Privilege", url: "privilege", },
      ],

      rolesDropDown: [],

      checkListofPrivilege: []
    };
    // state management end
  }

  onRoleChange(e) {
    this.setState({ roleData: e.value });
    this.rolePrivilegeAssignments(e.value.role_id)
    this.setState({
      privilegeList: [],
      checkListofPrivilege: []
    })
  }

  addingPrivileges(e) {
    let selectedPrivileges = [...this.state.privilegeList];

    if (e.checked)
      selectedPrivileges.push(e.value);
    else
      selectedPrivileges.splice(selectedPrivileges.indexOf(e.value), 1);

    this.setState({ privilegeList: selectedPrivileges });
  }

  rolePrivilegeAssignments = async (val) => {
    try {
      const privList = await this.privelegeService.getRoleprivilageassignmentsList({ val })
      if (privList && privList.data.data.length !== 0) {
        const privilege = privList.data.data[0].privilage_id;
        var privData = privilege.split(',');
        var convertedData = privData.map(Number);
        this.setState({
          privilegeList: convertedData,
          checkListofPrivilege: convertedData
        })
      } else {
        this.setState({
          privilegeList: [],
          checkListofPrivilege: []
        })
      }
    } catch (err) {
      console.log(err)
    }
  }

  rolesDropDownCall = async () => {
    try {
      let userDetails = lStorage.get('authInfo');

      if (userDetails && userDetails.role_priority) {
        const apiResponse = await response.getList(
          {
            service: this.dropdownService,
            method: 'getUserRoles',
            params: { priority: userDetails.role_priority }
          })
        if (apiResponse && apiResponse.data) {
          const rolesDropDown = apiResponse.data;
          this.setState({
            rolesDropDown: rolesDropDown.data
          })
        }
      }
    } catch (err) {
      console.log(err)
    }
  }
  savePrivileges = async () => {
    let userDetails;
    userDetails = lStorage.get('authInfo')
    if (this.state.checkListofPrivilege.length === 0) {
      await response.add({
        service: this.privelegeService,
        method: this.state.checkListofPrivilege.length === 0 ? 'privilageAssignment' : 'privilageassignmentData',
        data: { item: { "role_id": this.state.roleData.role_id, "created_by": userDetails.email_address, "privilage_id": this.state.privilegeList.toString() }, itemid: { userN: userDetails.id } },
        toastMessage: {
          success: "Privilege Changes saved successfully",
          error: "Error in Privelge Changes. Please try again"
        }
      })
      this.rolePrivilegeAssignments(this.state.roleData.role_id)

    } else {
      await response.add({
        service: this.privelegeService,
        method: this.state.checkListofPrivilege.length === 0 ? 'privilageAssignment' : 'privilageassignmentData',
        data: { item: { "role_id": this.state.roleData.role_id, "updated_by": userDetails.email_address, "privilage_id": this.state.privilegeList.toString() }, itemid: { userN: userDetails.id } },
        toastMessage: {
          success: "Privilege Changes saved successfully",
          error: "Error in Privelge Changes. Please try again"
        }
      })
      this.rolePrivilegeAssignments(this.state.roleData.role_id)
    }
  }
  componentDidMount() {
    this.rolesDropDownCall()
    buildBreadcrumb(this.props, this.state.breadcrumbs);
  }
  render() {
    return (
      <div>

        <div className="p-toolbar checkout-toolbar">
          <div className="datatable-title">
            <h4>Roles</h4>
          </div>
          <Dropdown optionLabel="label" value={this.state.roleData} options={this.state.rolesDropDown} onChange={this.onRoleChange} placeholder="Select Role" />
        </div>

        <div className="p-grid">

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Asset Categories">ASSET CATEGORIES</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create Asset Categories" value={1} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(1) !== -1} />
                  <label htmlFor="Create Asset Categories">  &nbsp;&nbsp;Create Asset Categories</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Asset Categories" value={2} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(2) !== -1} />
                  <label htmlFor="Update Asset Categories">  &nbsp;&nbsp;Update Asset Categories</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Asset Categories" value={3} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(3) !== -1} />
                  <label htmlFor="Delete Asset Categories">  &nbsp;&nbsp;Delete Asset Categories</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Asset">ASSET</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="create-assets" value={4} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(4) !== -1} />
                  <label htmlFor="create-assets">  &nbsp;&nbsp;Create Assets</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="update-assets" value={5} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(5) !== -1} />
                  <label htmlFor="update-assets">  &nbsp;&nbsp;Update Assets</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="delete-assets" value={6} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(6) !== -1} />
                  <label htmlFor="delete-assets">  &nbsp;&nbsp;Delete Assets</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="College">COLLEGE</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create Colleges" value={7} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(7) !== -1} />
                  <label htmlFor="Create Colleges">  &nbsp;&nbsp;Create Colleges</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Colleges" value={8} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(8) !== -1} />
                  <label htmlFor="View Colleges">  &nbsp;&nbsp;View College</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Colleges" value={9} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(9) !== -1} />
                  <label htmlFor="Update Colleges">  &nbsp;&nbsp;Update Colleges</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View College Reports" value={10} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(10) !== -1} />
                  <label htmlFor="View College Reports">  &nbsp;&nbsp;View Reports</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Colleges" value={11} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(11) !== -1} />
                  <label htmlFor="Delete Colleges">  &nbsp;&nbsp;Delete Colleges</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Artifacts" value={58} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(58) !== -1} />
                  <label htmlFor="Artifacts">  &nbsp;&nbsp;Artifacts</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="College POC" >COLLEGE POC</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create College POC" value={12} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(12) !== -1} />
                  <label htmlFor="Create College POC">  &nbsp;&nbsp;Create College POC</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View College POC" value={13} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(13) !== -1} />
                  <label htmlFor="View College POC">  &nbsp;&nbsp;View College POC</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update College POC" value={14} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(14) !== -1} />
                  <label htmlFor="Update College POC">  &nbsp;&nbsp;Update College POC</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete College POC" value={15} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(15) !== -1} />
                  <label htmlFor="Delete College POC">  &nbsp;&nbsp;Delete College POC</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="College Staff">COLLEGE STAFF</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create College Staff" value={16} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(16) !== -1} />
                  <label htmlFor="Create College Staff">  &nbsp;&nbsp;Create College Staff</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View College Staff" value={17} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(17) !== -1} />
                  <label htmlFor="View College Staff">  &nbsp;&nbsp;View College Staff</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update College Staff" value={18} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(18) !== -1} />
                  <label htmlFor="Update College Staff">  &nbsp;&nbsp;Update College Staff</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete College Staff" value={19} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(19) !== -1} />
                  <label htmlFor="Delete College Staff">  &nbsp;&nbsp;Delete College Staff</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="User" >USER</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create Users" value={20} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(20) !== -1} />
                  <label htmlFor="Create Users">  &nbsp;&nbsp;Create Users</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Users" value={21} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(21) !== -1} />
                  <label htmlFor="Update Users">  &nbsp;&nbsp;Update Users</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Users" value={22} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(22) !== -1} />
                  <label htmlFor="Delete Users">  &nbsp;&nbsp;Delete Users</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="enableTrainer" value={55} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(55) !== -1} />
                  <label htmlFor="enableTrainer">  &nbsp;&nbsp;Enable User as Trainer</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Program">PROGRAM</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create Cart" value={23} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(23) !== -1} />
                  <label htmlFor="Create Cart">  &nbsp;&nbsp;Create Cart</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Program" value={24} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(24) !== -1} />
                  <label htmlFor="View Program">  &nbsp;&nbsp;View Program</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Program" value={57} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(57) !== -1} />
                  <label htmlFor="Update Program">  &nbsp;&nbsp;Update Program</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Cart" value={25} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(25) !== -1} />
                  <label htmlFor="Delete Cart">  &nbsp;&nbsp;Delete Cart</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Program Reports" value={26} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(26) !== -1} />
                  <label htmlFor="View Program Reports">  &nbsp;&nbsp;View Reports</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Upload Certificate Template" value={27} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(27) !== -1} />
                  <label htmlFor="Upload Certificate Template">  &nbsp;&nbsp;Upload Certificate Template</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Upload Media" value={28} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(28) !== -1} />
                  <label htmlFor="Upload Media">  &nbsp;&nbsp;Upload Media</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Change Request" value={29} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(29) !== -1} />
                  <label htmlFor="Change Request">  &nbsp;&nbsp;Change Request</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Session">SESSION</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Session" value={30} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(30) !== -1} />
                  <label htmlFor="View Session">  &nbsp;&nbsp;View Session</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Assign Trainer" value={31} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(31) !== -1} />
                  <label htmlFor="Assign Trainer">  &nbsp;&nbsp;Assign Trainer</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Sessions" value={32} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(32) !== -1} />
                  <label htmlFor="Delete Sessions">  &nbsp;&nbsp;Delete Sessions</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Participants">PARTICIPANTS</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Bulk Upload Participants" value={33} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(33) !== -1} />
                  <label htmlFor="Bulk Upload Participants">  &nbsp;&nbsp;Bulk Upload Participants</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Certificate Dispatcher" value={34} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(34) !== -1} />
                  <label htmlFor="Certificate Dispatcher">  &nbsp;&nbsp;Certificate Dispatcher</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Manage Overall Participants" value={56} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(56) !== -1} />
                  <label htmlFor="Manage Overall Participants">  &nbsp;&nbsp;Manage Overall Participants</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Trainer">TRAINER</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create Trainers" value={35} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(35) !== -1} />
                  <label htmlFor="Create Trainers">  &nbsp;&nbsp;Create Trainers</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Trainers" value={36} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(36) !== -1} />
                  <label htmlFor="View Trainers">  &nbsp;&nbsp;View Trainer</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Trainers" value={37} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(37) !== -1} />
                  <label htmlFor="Update Trainers">  &nbsp;&nbsp;Update Trainers</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Trainer Reports" value={38} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(38) !== -1} />
                  <label htmlFor="View Trainer Reports">  &nbsp;&nbsp;View Reports</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Trainers" value={39} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(39) !== -1} />
                  <label htmlFor="Delete Trainers">  &nbsp;&nbsp;Delete Trainers</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Module">MODULE</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create Modules" value={40} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(40) !== -1} />
                  <label htmlFor="Create Modules">  &nbsp;&nbsp;Create Modules</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View Modules" value={41} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(41) !== -1} />
                  <label htmlFor="View Modules">  &nbsp;&nbsp;View Modules</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Modules" value={42} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(42) !== -1} />
                  <label htmlFor="Update Modules">  &nbsp;&nbsp;Update Modules</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete Modules" value={43} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(43) !== -1} />
                  <label htmlFor="Delete Modules">  &nbsp;&nbsp;Delete Modules</label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Standard Data">STANDARD DATA</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create  Standard Data" value={44} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(44) !== -1} />
                  <label htmlFor="Create  Standard Data">  &nbsp;&nbsp;Create Standard Data</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="View  Standard Data" value={45} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(45) !== -1} />
                  <label htmlFor="View  Standard Data">  &nbsp;&nbsp;View Standard Data</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update  Standard Data" value={46} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(46) !== -1} />
                  <label htmlFor="Update  Standard Data">  &nbsp;&nbsp;Update Standard Data</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete  Standard Data " value={47} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(47) !== -1} />
                  <label htmlFor="Delete  Standard Data ">  &nbsp;&nbsp;Delete Standard Data </label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="CMS">CMS</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create  CMS Pages" value={48} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(48) !== -1} />
                  <label htmlFor="Create  CMS Pages">  &nbsp;&nbsp;Create  CMS Pages</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update  CMS Pages" value={49} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(49) !== -1} />
                  <label htmlFor="Update  CMS Pages">  &nbsp;&nbsp;Update  CMS Pages</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete  CMS Pages " value={50} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(50) !== -1} />
                  <label htmlFor="Delete  CMS Pages ">  &nbsp;&nbsp;Delete  CMS Pages </label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="FAQ">FAQ</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Create  FAQ" value={51} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(51) !== -1} />
                  <label htmlFor="Create  FAQ">  &nbsp;&nbsp;Create  FAQ</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update  FAQ" value={52} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(52) !== -1} />
                  <label htmlFor="Update  FAQ">  &nbsp;&nbsp;Update  FAQ</label>
                </div>
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Delete  FAQ " value={53} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(53) !== -1} />
                  <label htmlFor="Delete  FAQ ">  &nbsp;&nbsp;Delete  FAQ </label>
                </div>
              </div>
            </div>
          </div>

          <div className="p-col-12 p-md-6 p-lg-3 privilege-card">
            <div className="card">
              <div className="card-header">
                <p htmlFor="Privileges">PRIVILEGES</p>
              </div>
              <div className="card-body">
                <div className="checkbox-wrapper">
                  <Checkbox inputId="Update Privileges" value={54} onChange={this.addingPrivileges} checked={this.state.privilegeList.indexOf(54) !== -1} />
                  <label htmlFor="Update Privileges">  &nbsp;&nbsp;Update Privileges</label>
                </div>
              </div>
            </div>
          </div>

        </div>

        <div className="p-d-flex p-jc-end p-mt-3 p-pr-2">
          <Button type="Submit" label="Save" className="p-button-success" onClick={this.savePrivileges} />
        </div>

      </div>

    );
  }
}
const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(Privileges));