import React, { useState, useEffect } from 'react';

import { connect } from 'react-redux';

import { useHistory } from "react-router-dom";

import { Link } from 'react-router-dom';

// utils 

import { getUserType, isLoginAuth, getUserRole } from 'utils/common';

import { isEmpty } from 'lodash';

import { response } from 'utils/response';

import { lStorage } from 'utils/storage';

// primereact components 
import { Card } from 'primereact/card';

import { Button } from 'primereact/button';

//import { HfnFirebaseAuth, signOut } from '@heartfulnessinstitute/react-hfn-profile';

// state 

import { LOGIN } from 'store/actions/type/login';

// services 
import LoginService from 'services/login';

// images 
import logo from 'assets/images/logo.png';

import HFNDynamicForm from 'shared-components/hfn-form/index';

import { validations } from 'utils/validations';

import { useCookies } from 'react-cookie';

const Login = (props) => {

  let history = useHistory();

  const ls = new LoginService();

  const [isShowSSO] = useState(false);

  const [cookies, setCookie] = useCookies(['tourRequired', 'tourGuidance']);

  // initial values 
  const [loginFormInitialValue] = useState({
    email_address: null,
    password: null
  });

  // properties 

  const [loginFormFields] = useState({
    email_address: {

      properties: {
        type: 'InputText',
        label: 'Email address',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
          pattern: validations.email
        }
      },

    },
    password: {

      properties: {
        type: 'InputText',
        label: 'Password',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
          type: 'password'
        },
        validations: {
          required: validations.required,
        }
      },


    }
  })

  // Login form submit section starts
  const loginFormOnsubmit = async (data, err) => {

    let loginResponse, loginResponseData;

    try {
      if (isEmpty(err)) {

        loginResponse = await response.add({
          service: ls,
          method: 'login',
          data: { item: data },
          toasterMessage: {
            success: "Login successfully",
            error: 'Please login with correct email address and password'
          }
        })

        loginResponseData = loginResponse.data;

        if (!loginResponseData.isError) {
          lStorage.set('authInfo', loginResponseData.data);
          localStorage.setItem('tourRequired', '');
          localStorage.setItem('tourGuidance', '1');
          if((getUserRole() === "Volunteer" || getUserRole() === "Zone Coordinator" || getUserRole()=== "State Coordinator" || getUserRole()=== "Trainer" || getUserRole()=== "College Staff") && (!cookies.tourRequired)) {
            setCookie('tourRequired', '', {path: '/'});
            setCookie('tourGuidance', '1', {path: '/'});
          }
          if(cookies.tourRequired && cookies.tourGuidance) {
            localStorage.setItem('tourRequired', cookies.tourRequired);
            localStorage.setItem('tourGuidance', cookies.tourGuidance);
          }
          props.dispatch({ type: LOGIN, payload: loginResponseData.data });
          getUserType() !== "CS" ? history.push('/dashboard') : history.push('/mycollege');
        }

      }
    } catch (err) {
      console.log(err)
    }

  }
  // Login form submit section end

  const isLogin = () => {
    if (isLoginAuth()) {
      history.push('/')
    } else {
      history.push('/login')
    }
  }

  const loginSubmitButtonGroup = () => {
    return (
      <div className="p-field p-col-12">
        <Button label="LogIn" className="p-button-primary login-button" type="submit" />
      </div>
    )
  }

  // const showSSO = () => {
  //   setShowSSO(!isShowSSO)
  // }

  // const processLogin = async ({ myInfo }) => {

  //   let loginResponse, ssoLoginInfo;

  //   console.log(myInfo)

  //   ssoLoginInfo = {
  //     ssoAuthenticate: { results: [myInfo] }
  //   }

  //   try {

  //     if (ssoLoginInfo.ssoAuthenticate.results.length > 0 && myInfo) {

  //       loginResponse = await response.add({
  //         service: ls,
  //         method: 'ssoLogin',
  //         data: { item: ssoLoginInfo },
  //         toasterMessage: {
  //           success: "Login successfully",
  //           error: 'Please login with registered email'
  //         }
  //       })

  //       if (loginResponse && loginResponse.data && !loginResponse.data.isError) {
  //         lStorage.set('authInfo', loginResponse.data.data);
  //         props.dispatch({ type: LOGIN, payload: loginResponse.data.data });
  //         history.push('/dashboard');
  //       } else {
  //         signOut()
  //       }
  //     }

  //   } catch (err) {
  //     console.log(err)
  //   }

  // }

  useEffect(() => {
    isLogin();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className='login-section'>
      <div className="card-wrapper">

        <div className="loging-logo p-mb-4 p-text-center">
          <img src={logo} alt="heartfulness" />
        </div>

        <Card>
          <div className="login">

            {
              (!isShowSSO) ? <div>
                <h2 className="title p-mb-4"> Login</h2>

                <HFNDynamicForm
                  initialValues={loginFormInitialValue}
                  fields={loginFormFields}
                  onFormSubmit={loginFormOnsubmit}
                  submitButtonGroup={loginSubmitButtonGroup}>
                </HFNDynamicForm>

                {/* <div className="sso-wrapper">
                  <div className="or">
                    <span>Or</span>
                  </div>
                  <div className="p-field p-col-12">
                    <Button onClick={showSSO} className="p-button-success sso-btn">SignIn With SRCM Profile</Button>
                  </div>
                </div> */}

                <Link className="forget-pass" to="/forgot-password">Forgot Password?</Link>

                <p className="p-text-center p-my-3">Don&apos;t have an account?
                </p>
                <div className="p-text-center p-d-sm-flex p-jc-center p-flex-wrap">
                  <Link to="/register" className="sign-up-link"> Sign Up </Link>
                  <div>&nbsp;Or&nbsp;</div>
                  <Link to="/trainer-register" className="sign-up-link"> Trainer Sign Up </Link>
                </div>
              </div> :
                <div>
                  {/* <HfnFirebaseAuth doLogin={processLogin}></HfnFirebaseAuth>
                  <div className="p-field p-col-12 p-text-center" style={{ cursor: 'pointer' }}>
                    <p onClick={showSSO}><u>Login</u></p>
                  </div> */}
                </div>
            }

          </div>
        </Card>
      </div>
    </div>
  );

}

// export default Login
const mapStateToProps = (state) => ({
  ld: state.loginDetails
});

export default connect(mapStateToProps)(Login);
