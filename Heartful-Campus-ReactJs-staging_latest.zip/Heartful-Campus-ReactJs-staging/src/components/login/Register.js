import React, { useState, useEffect } from 'react';

import { useHistory } from "react-router-dom";

// service
import LoginService from 'services/login';

// utitls 
import { validations } from 'utils/validations'

import { dropdown } from 'utils/dropdown';

import { response } from 'utils/response';

import { cityAutoCompleteTemplate, isLoginAuth } from 'utils/common';

// primereact components 
import { Card } from 'primereact/card';

import { Button } from 'primereact/button';

import { Divider } from 'primereact/divider';

import { isEmpty } from 'lodash';

// shared component 
import HFNDynamicForm from 'shared-components/hfn-form/index';

// images 
import logo from 'assets/images/logo.png';

import config from 'assets/config';

const Register = () => {

  let history = useHistory();

  const ls = new LoginService();

  const passwordHeader = <h6>Pick a password</h6>;

  const passwordFooter = (
    <React.Fragment>
      <Divider />
      <p className="p-mt-2">Suggestions</p>
      <ul className="p-pl-2 p-ml-2 p-mt-0" style={{ lineHeight: '1.5' }}>
        <li>At least one lowercase</li>
        <li>At least one uppercase</li>
        <li>At least one numeric</li>
        <li>Minimum 8 characters</li>
      </ul>
    </React.Fragment>
  );

  // register form section start 


  const [registerFormConfig] = useState({
    formClassName: 'register-form-wrapper',
    formSectionClassName: 'register-form-section',
    autoComplete: 'off',
  });

  // initial values 

  const [registerFormInitialValue] = useState({
    abhyasi_id: null,
    name: null,
    email_address: null,
    contact_number: null,
    address: null,
    state: null,
    city: null,
    country_id: null,
    pincode: null,
    photo: null,
    zone_id: null,
    password: null,
    role_id: null,
    status_id: null
  });

  const [registerFormFields, setRegisterFormFields] = useState({

    name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {},
        validations: {
          required: validations.required,
        }
      },
    },

    email_address: {
      properties: {
        type: 'InputText',
        label: 'Email',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          keyfilter: 'email'
        },
        validations: {
          required: validations.required,
          pattern: validations.email
        }
      },
    },

    password: {
      properties: {
        type: 'Password',
        label: 'Password',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          header: passwordHeader,
          footer: passwordFooter,
        },
        validations: {
          required: validations.required,
        }
      }
    },

    abhyasi_id: {
      properties: {
        type: 'InputText',
        label: 'Abhyasi ID',
        fieldWrapperClassNames: 'p-md-6',
        validations: {
          pattern: validations.abhyasiId
        }
      },
    },

    contact_number: {
      properties: {
        type: 'PhoneInput',
        label: 'Contact Number',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        }
      },
    },

    photo: {
      properties: {
        type: 'ProfileUpload',
        label: 'Photo',
        fieldWrapperClassNames: 'p-md-6',
        hint: `Maximum allowed file size is ${config.profileImageMaxFIleSize}MB. Allowed types are jpg, jpeg and png`,
        primeFieldProps: {
          accept: ".jpg,.jpeg,.png",
          onChange: (file) => {
            if (file.target.files.length !== 0) {
              setRegisterFormFields({
                ...registerFormFields,
                imageCrop: {
                  ...registerFormFields.imageCrop,
                  properties: {
                    ...registerFormFields.imageCrop.properties,
                    visibility: true
                  }
                },
                previewImage: {
                  ...registerFormFields.previewImage,
                  properties: {
                    ...registerFormFields.previewImage.properties,
                    visibility: true
                  }
                }
              })
            } else {
              setRegisterFormFields({
                ...registerFormFields,
                imageCrop: {
                  ...registerFormFields.imageCrop,
                  properties: {
                    ...registerFormFields.imageCrop.properties,
                    visibility: false
                  }
                },
                previewImage: {
                  ...registerFormFields.previewImage,
                  properties: {
                    ...registerFormFields.previewImage.properties,
                    visibility: false
                  }
                }
              })
            }
          }
        }
      }
    },

    imageCrop: {
      properties: {
        type: 'imageCrop',
        label: 'Selected Image',
        visibility: false,
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          accept: ".jpg, .jpeg, .png"
        },
      }
    },
    previewImage: {
      properties: {
        type: 'previewImage',
        label: 'Preview Image',
        visibility: false,
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          accept: ".jpg, .jpeg, .png"
        },
      }
    },

    address: {
      properties: {
        type: 'InputTextarea',
        label: 'Address',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        }
      },
    },

    city: {
      properties: {
        type: 'CityAutoComplete',
        label: 'City',
        fieldWrapperClassNames: 'p-md-6',
        searchField: 'name',
        fieldLabel: 'name',
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        },
        stateField: {
          label: 'State',
          fieldName: 'state',
          fieldWrapperClassNames: 'p-md-6',
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required,
          }
        },
        countryField: {
          label: 'Country',
          fieldName: 'country_id',
          fieldWrapperClassNames: 'p-md-6',
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required,
          },
          dropdownOptions: "country"
        }
      },
    },
    pincode: {
      properties: {
        type: 'InputText',
        label: 'Pincode',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {},
        validations: {
          required: validations.required,
          maxLength: {
            value: 10,
            message: "Please enter pincode with maximum 10 characters"
          }
        }
      }
    },

    zone_id: {
      properties: {
        type: 'SelectDropdown',
        label: 'Zone',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          isSearchable: true,
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "zone"

      }
    },
    role_id: {
      properties: {
        type: 'Dropdown',
        label: 'Role',
        fieldWrapperClassNames: 'p-md-6',
        primeFieldProps: {
          filter: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "userRoleList"
      }
    }

  });

  // Registration form submit section starts
  const registerFormOnsubmit = async (data, err) => {
    console.log(data, "data")

    let registerResponse, registerResponseData;


    let formData = new FormData();

    Object.keys(data).forEach(key => {
      if (key === "photo") {
        if (data[key][0]) {
          formData.append("photo", data[key])
        }
      }
      else
        formData.append(key, data[key])
    });
    try {
      if (isEmpty(err)) {
        registerResponse = await response.add({
          service: ls,
          method: 'register',
          data: { item: formData },
          toasterMessage: {
            success: 'Please check your email for the account activation link',
            error: 'User not registered'
          }
        })

        if (registerResponse) {
          registerResponseData = registerResponse.data;

        }

        if (!registerResponseData.isError) {
          setTimeout(() => {
            history.push('/login');
          }, 2000);
        }

      }
    } catch (err) {
      console.log(err)
    }

  }
  // Registration form submit section end


  const registerSubmitButtonGroup = () => {
    return (
      <div className="p-d-flex p-jc-end p-mt-3 p-pr-2">
        <Button type="button" className='p-button-secondary p-mr-2' label="Cancel" onClick={() => { history.push('/login'); }} >
        </Button>
        <Button type="submit" label="Submit" className="p-button-success" />
      </div>
    )
  }

  const isLogin = () => {
    if (isLoginAuth()) {
      history.push('/')
    }
  }

  useEffect(() => {
    isLogin();
    dropdown.zone();
    dropdown.country();
    dropdown.userRoleList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (

    <div className='login-section register-section'>
      <div className="card-wrapper">

        <div className="loging-logo p-mb-4 p-text-center">
          <img src={logo} alt="heartfulness" />
        </div>

        <Card>
          <div className="register">
            <h2 className="title p-mb-4">Register</h2>
            <HFNDynamicForm
              formConfig={registerFormConfig}
              initialValues={registerFormInitialValue}
              fields={registerFormFields}
              onFormSubmit={registerFormOnsubmit}
              submitButtonGroup={registerSubmitButtonGroup}>
            </HFNDynamicForm>
          </div>
        </Card>

      </div>
    </div>
  )

}

export default Register;
