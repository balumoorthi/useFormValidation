import React, { Component } from 'react';

// utils 
import { isEmpty } from 'lodash';

import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { statusBadge, createdDateBadge, levelBadge, multipleUnitBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { galleryPopup } from "utils/galleryPopup";

import { bulk } from "utils/bulk";

import { getUserName, getModuleAccess } from "utils/common";

import { validations } from 'utils/validations';

// components
import ModuleForm from 'components/module/ModuleForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

import HFNAttachments from 'shared-components/attachment';

// services 
import ModuleService from 'services/module/module.service';

// config
import config from 'assets/config';

class ModuleListing extends Component {

  constructor(props) {

    super(props);

    // variable initialization start
    this.moduleService = new ModuleService();

    this.moduleTable = React.createRef(null);

    this.attachmentList = React.createRef(null);

    this.moduleFormInitValue = {
      module_name: null,
      module_code: null,
      module_desc: null,
      module_type_code: null,
      unit_id: null,
      program_type_id: null,
      level_id: null,
      discipline_id: null,
      status_id: null,
    };
    // variable initialization end

    // state management start
    this.state = {

      moduleForm: {
        isEditable: false,
        initValue: this.moduleFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Module", url: "module", },
      ],

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("MODULE"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.moduleService,

        method: 'getModuleList',

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'module_name',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Unit',
            field: 'unit_id',
            filterType: 'select',
            sortField: "SortingDisabled",
            filterElementOptions: {
              type: 'Dropdown',
              value: "unit",
              primeFieldProps: {
                filter: true
              }
            },
            body: multipleUnitBadge,
            headerStyle: {
              width: '120px'
            }
          },
          {
            header: 'Level',
            field: 'level_id',
            sortable: true,
            filter: true,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "level",
              primeFieldProps: {
                filter: true
              }
            },
            body: levelBadge,
            headerStyle: {
              width: '120px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            body: statusBadge,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "generalStatus"
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            body: createdDateBadge,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '120px'
            }
          },
        ],

        actionBtnOptions: [
          {
            type: 'update',
            title: 'Edit Module',
            onClick: this.editModule
          },
          {
            type: 'update',
            icon: "pi pi-paperclip",
            className: "p-mr-2 gallery-button",
            title: 'View Attachment',
            onClick: this.viewAttachments
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            className: "p-mr-2",
            title: 'Delete Module',
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this module?",
                accept: () => { this.removeModule(rowData.module_id); }
              });
            }
          },
        ],

        toolBarBtnOptions: {
          title: 'module list',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "You are about to mass update the status of modules?",
                  accept: () => { this.bulkStatusUpdate(selections, status) }
                });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "Are you sure you want to delete these modules? This may affect other screens",
                  accept: () => { this.bulkDelete(selections); }
                });
              }
            },
          },
          rightBtnsOptions: [
            { onClick: this.setModuleFormInitValue }
          ]
        },

        enableSelection: true,
      },

      attachmentOptions: {

        service: this.moduleService,

        method: 'listAttachments',

        onDelete: attachment => {
          confirmDialog.toggle(true);
          confirmDialog.custom({
            message: "Are you sure you want to delete this attachment?",
            accept: () => { this.removeAttachment(attachment) }
          });
        },

        noDataText: "No attachments assigned for this module",

        enableUpload: true,

        uploadFormOptions: {

          initialValues: {},

          fields: {
            document_name: {
              properties: {
                type: 'FileUpload',
                label: 'Attachment',
                fieldWrapperClassNames: 'p-col-12',
                hint: `Maximum allowed file size is ${config.maxAllowedFileSize}MB`,
                primeFieldProps: {
                },
                validations: {
                  required: validations.required,
                }
              }
            }
          },

          onSubmit: this.onAttachmentUpload

        }
      },

      viewAttachments: false,

      processingModule: null

    }

    // state management end
  }

  // bulk edit start
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "Module",
        name: "module_id",
        value: selections.map(value => { return value.module_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.moduleTable,
    })
  }
  // bulk delete section starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "Module",
        name: "module_id",
        value: selections.map(value => { return value.module_id }),
        deleted_by: getUserName(),
      },
      dataTable: this.moduleTable,
    })
  }
  // bulk delete section end

  setModuleFormInitValue = () => {
    this.setState({
      moduleForm: {
        ...this.state.moduleForm,
        initValue: this.moduleFormInitValue,
        isEditable: false
      },
      viewAttachments: false
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'add module', className: 'sdm-popup' })
      })
  }

  // edit Module section starts
  editModule = (ev, rowData) => {
    this.setState({
      moduleForm: {
        ...this.state.moduleForm,
        initValue: {
          module_id: rowData.module_id,
          module_name: rowData.module_name,
          module_code: rowData.module_code,
          module_desc: rowData.module_desc,
          module_type_code: (rowData.module_types) ? rowData.module_types.module_type_id : "",
          unit_id: !isEmpty(rowData.unitmodules) ? rowData.unitmodules.map(unit => unit.unit_id) : null,
          program_type_id: (rowData.program_types) ? rowData.program_types.program_type_id : "",
          level_id: (rowData.levels) ? rowData.levels.level_id : "",
          discipline_id: (rowData.disciplines) ? rowData.disciplines.discipline_id : "",
          status_id: (rowData.status) ? rowData.status.status_id : "",
        },
        isEditable: true
      },
      viewAttachments: false
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'update module', className: 'sdm-popup' })
      })
  }
  // edit Module section end

  // remove Module section starts
  removeModule = async (id) => {
    await response.remove({
      service: this.moduleService,
      method: 'removeModule',
      data: { itemId: id },
      dataTable: this.moduleTable,
      toasterMessage: {
        success: 'Module has been deleted successfully',
        error: 'Error in deleting module'
      }
    })
  }
  // remove Module section end

  // view galler section starts
  viewGallery = (ev, rowData) => {
    this.setState({ processingModule: rowData },
      () => {
        galleryPopup.toggle(true);
        galleryPopup.custom({ onAttachmentCopy: (attachment) => { this.addAttachment(attachment) } })
      })
  }
  // view galler section end

  // add attachment sections starts
  addAttachment = async (attachment) => {
    let attachmentData = {
      module_id: null,
      document_name: null,
      created_by: getUserName()
    };

    if (attachment.file_name && attachment.file_type)
      attachmentData.document_name = attachment.file_name;
    if (this.state.processingModule && this.state.processingModule.module_id)
      attachmentData.module_id = this.state.processingModule.module_id

    let apiResponse = await response.add({
      service: this.moduleService,
      method: 'addAttachment',
      data: { item: attachmentData },
      dataTable: this.dataTableRef,
      toasterMessage: {
        success: 'Attachment has been added successfully',
        error: 'Unable to add attachment'
      }
    })

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      galleryPopup.toggle(false);
    }
  }
  // add attachment sections end

  // view attachment sections starts
  viewAttachments = (ev, rowData) => {
    this.setState({
      viewAttachments: true,
      processingModule: rowData,
      attachmentOptions: {
        ...this.state.attachmentOptions,
        urlPath: rowData.module_id
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Module Attachments', className: 'attachment-popup' })
      }
    )
  }
  // view attachment sections end

  // remove attachment sections starts
  removeAttachment = async (attachment) => {
    if (this.state.processingModule) {
      await response.remove({
        service: this.moduleService,
        method: 'removeAttachment',
        data: { itemId: attachment.module_document_id },
        toasterMessage: {
          success: 'Attachment has been added successfully',
          error: 'Unable to add attachment'
        },
        modalPopupHide: false
      })
    }
    if (this.attachmentList.current)
      this.attachmentList.current.loadData()
  }
  // remove attachment sections end

  // attachment direct upload section start
  onAttachmentUpload = async (data, error) => {
    try {
      if (isEmpty(error)) {
        const formData = new FormData();

        Object.keys(data).forEach(key => {
          (key === "document_name") ? formData.append(key, data[key][0]) : formData.append(key, data[key]);
        });
        formData.set('module_id', this.state.processingModule.module_id);
        formData.append("created_by", getUserName());

        await response.add({
          service: this.moduleService,
          method: 'addAttachment',
          data: { item: formData },
          modalPopupHide: false,
          toasterMessage: {
            success: "Attachment uploaded successfully. Continue uploading more attachments",
            error: "Error in uploading attachment. Please try again"
          }
        })
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // attachment direct upload section end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.generalStatus();
    dropdown.unit();
    dropdown.discipline();
    dropdown.level();
    dropdown.moduleType();
    dropdown.programType();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.moduleTable} options={this.state.options} />
        <HFNModalPopup>
          {
            this.state.viewAttachments
              ?
              <HFNAttachments ref={this.attachmentList} options={this.state.attachmentOptions} dataTableRef={this.moduleTable} />
              :
              <ModuleForm initialValue={this.state.moduleForm} dataTableRef={this.moduleTable} />
          }
        </HFNModalPopup>
      </div>
    );
  }
}

export default ModuleListing;
