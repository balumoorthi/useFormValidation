import React, { useState } from "react";

// utils 

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { getUserName } from "utils/common";

import { isEmpty } from 'lodash';


// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form";

// services 
import ModuleService from 'services/module/module.service';

const ModuleForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const moduleService = new ModuleService();
  // variable init end

  // state management start

  // validations start
  const [ModuleFormFields] = useState({
    module_name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        tooltip: "Enter module name",
        validations: {
          required: validations.required,
        }
      },
    },
    module_code: {
      properties: {
        type: 'InputText',
        label: 'Code',
        tooltip: "Enter module code",
        validations: {
          required: validations.required,
          maxLength: {
            value: 8,
            message: 'Please enter code with maximum 8 characters'
          },
        }
      }
    },
    module_desc: {
      properties: {
        type: 'InputTextarea',
        label: 'Description',
        tooltip: "Enter module description",
        validations: {
          required: validations.required,
        }
      }
    },
    module_type_code: {
      properties: {
        type: 'Dropdown',
        label: 'Type',
        tooltip: "Select module type",
        primeFieldProps: {
          filter: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "moduleType"
      }
    },
    unit_id: {
      properties: {
        type: 'MultiSelect',
        label: 'Units',
        tooltip: "Select units",
        primeFieldProps: {
          filter: true,
          showClear: true
        },
        dropdownOptions: "unit"
      }
    },
    program_type_id: {
      properties: {
        type: 'Dropdown',
        label: 'Program Type',
        tooltip: "Select program type",
        primeFieldProps: {
          filter: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "programType"
      },
    },
    level_id: {
      properties: {
        type: 'Dropdown',
        label: 'Level',
        tooltip: "Select level",
        primeFieldProps: {
          filter: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "level"
      }
    },
    discipline_id: {
      properties: {
        type: 'Dropdown',
        label: 'Discipline',
        tooltip: "Select discipline",
        primeFieldProps: {
          filter: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "discipline"
      }
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        tooltip: "Select Status",
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "generalStatus"
      }
    },

  });

  // form submit 

  const ModuleFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }

      for (var key in formData) {
        if (!formData[key]) {
          delete formData[key];
        }
      }
      formData = getUserName(isEditable, formData)
      addUpdateModule(formData)
    }
  }

  // add new Module 

  const addUpdateModule = async (data) => {
    if (!isEditable) {
      await response.add({
        service: moduleService,
        method: 'addModule',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: moduleService,
        method: 'updateModule',
        data: { itemId: initValue.module_id, item: data },
        dataTable: dataTableRef,
      })
    }
  }

  // add new and update module section end
  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={ModuleFormFields} onFormSubmit={ModuleFormOnsubmit} />
    </div>
  )
}

export default ModuleForm;
