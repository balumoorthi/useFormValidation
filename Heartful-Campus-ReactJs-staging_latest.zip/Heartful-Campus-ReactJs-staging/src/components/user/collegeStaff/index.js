import React, { Component } from "react";

// components
import CollegeStaffForm from "components/user/collegeStaff/CollegeStaffForm";

// shared components
import HFNDataTable from "shared-components/datatable/HFNDataTable";

import HFNModalPopup from "shared-components/modalPopup";

// utils
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { createdDateBadge, statusBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { bulk } from "utils/bulk";

import { getUserName, getModuleAccess } from "utils/common";

// services
import CollegeStaffService from "services/user/collegeStaff.service";

class CollegeStaffs extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.collegeStaffService = new CollegeStaffService();

    this.collegeStaffTable = React.createRef(null);
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: "pi pi-home" },
        { label: "College Staff", url: "user/collegestaff" }
      ],

      collegeStaffForm: {
        initValue: {}
      },

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("USER")
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px"
        },

        url: this.collegeStaffService,

        method: "getCollegeStaffs",

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: "Name",
            field: "name",
            sortable: true,
            filter: true,
            headerStyle: {
              width: "150px"
            }
          },
          {
            header: "Email",
            field: "email_address",
            sortable: true,
            filter: true,
            headerStyle: {
              width: "250px"
            },
            transformValue: false
          },
          {
            header: "College",
            field: "collegestaff.label",
            sortField: "SortingDisabled",
            headerStyle: {
              width: "200px"
            }
          },
          {
            header: 'Designation',
            field: 'designation',
            sortable: true,
            headerStyle: {
              width: "200px"
            }
          },
          {
            header: "Status",
            field: "status_id",
            sortable: true,
            filter: true,
            filterType: "select",
            filterElementOptions: {
              type: "Dropdown",
              value: "generalStatus"
            },
            body: statusBadge,
            headerStyle: {
              width: "120px"
            }
          },
          {
            header: "Created On",
            field: "created_at",
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: "Calendar",
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: "120px"
            }
          },
        ],

        actionBtnOptions: [
          {
            type: "update",
            icon: "uil uil-pen edit-icon",
            className: "p-mr-2",
            title: "Edit College Staff",
            onClick: this.editCollegeStaff
          },
          {
            type: "delete",
            icon: "uil uil-trash-alt remove-icon",
            title: "Delete College Staff",
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to delete this college staff?",
                accept: () => { this.removeCollegeStaff(rowData.user_id); }
              });
            }
          }
        ],

        toolBarBtnOptions: {
          title: "College Staff List",
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "You are about to mass update the status of college staffs?",
                  accept: () => { this.bulkStatusUpdate(selections, status); }
                });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "Are you sure you want to delete these college staffs? This may affect other screens",
                  accept: () => { this.bulkDelete(selections); }
                });
              }
            }
          },
          rightBtnsOptions: [{ visibility: false }]
        },
        enableSelection: true
      }
    };
    // state management end
  }

  // bulk edit section start
  // bulk update section start
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "User",
        name: "user_id",
        value: selections.map(value => { return value.user_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.collegeStaffTable
    });
  }
  // bulk update section end

  // bulk delete section start
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "User",
        name: "user_id",
        value: selections.map(value => { return value.user_id }),
        deleted_by: getUserName()
      },
      dataTable: this.collegeStaffTable
    });
  }
  // bulk delete section end
  // bulk edit section end

  // edit college staff section start
  editCollegeStaff = (ev, rowData) => {
    this.setState({
      collegeStaffForm: {
        initValue: {
          user_id: rowData.user_id,
          name: rowData.name,
          email_address: rowData.email_address,
          contact_number: rowData.contact_number,
          designation: rowData.designation,
          address: rowData.address,
          city: rowData.city,
          state: rowData.state,
          country_id: rowData.country_id,
          status_id: rowData.status_id,
          pincode: rowData.pincode,
          zone_id: rowData.zone_id,
          role_id: rowData.role_id
        }
      }
    },
      () => {
        modalPopup.toggle(true);
        modalPopup.custom({ header: "Update College Staff", className: "sdm-popup", blockScroll: true });
      });
  };
  // edit college staff section end

  // remove college staff section start
  removeCollegeStaff = async (id) => {
    await response.remove({
      service: this.collegeStaffService,
      method: "removeCollegeStaff",
      data: { itemId: id },
      dataTable: this.collegeStaffTable
    });
  };
  // remove college staff section start

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.generalStatus();
    dropdown.country();
    dropdown.zone();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.collegeStaffTable} options={this.state.options} />
        <HFNModalPopup>
          <CollegeStaffForm initialValue={this.state.collegeStaffForm} dataTableRef={this.collegeStaffTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default CollegeStaffs;
