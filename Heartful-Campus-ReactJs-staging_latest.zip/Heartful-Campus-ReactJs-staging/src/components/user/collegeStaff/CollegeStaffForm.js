import React, { useState } from "react";

// components
// shared components
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils
import { isEmpty } from "lodash";

import { validations } from "utils/validations";

import { response } from "utils/response";

import { cityAutoCompleteTemplate, getUserName } from "utils/common";

// services
import CollegeStaffService from "services/user/collegeStaff.service";

const CollegeStaffForm = ({ initialValue, dataTableRef }) => {
  // props destructure start
  const { initValue } = initialValue;
  // props destructure end

  // variable init start
  const collegeStaffService = new CollegeStaffService();
  // variable init end

  // state management start
  const [collegeStaffFormFields] = useState({
    name: {
      properties: {
        type: "InputText",
        label: "Name",
        validations: {
          required: validations.required,
          maxLength: {
            value: 120,
            message: "Please enter name with maximum 120 characters"
          }
        }
      }
    },

    email_address: {
      properties: {
        type: "InputText",
        label: "Email",
        primeFieldProps: {
          readOnly: true
        }
      }
    },

    contact_number: {
      properties: {
        type: "PhoneInput",
        label: "Phone No",
        validations: {
          required: validations.required
        }
      }
    },
    
    designation: {
      properties: {
        type: 'InputText',
        label: 'Designation',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {
        },
        validations: {
          required: validations.required
        }
      }
    },

    address: {
      properties: {
        type: "InputText",
        label: "Address",
        validations: {
          required: validations.required
        }
      }
    },

    city: {
      properties: {
        type: "CityAutoComplete",
        label: "City",
        fieldWrapperClassNames: "p-md-12",
        searchField: "name",
        fieldLabel: "name",
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: "Search value must be minimum 3 character..."
          }
        },
        stateField: {
          label: "State",
          fieldName: "state",
          fieldWrapperClassNames: "p-md-12",
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required
          }
        },
        countryField: {
          label: "Country",
          fieldName: "country_id",
          fieldWrapperClassNames: "p-md-12",
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required
          },
          dropdownOptions: "country"
        }
      }
    },

    pincode: {
      properties: {
        type: "InputText",
        label: "Pincode",
        validations: {
          required: validations.required,
          maxLength: {
            value: 10,
            message: "Please enter pincode with maximum 10 characters"
          }
        }
      }
    },

    zone_id: {
      properties: {
        type: "SelectDropdown",
        label: "Zone",
        primeFieldProps: {
          isSearchable: true
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "zone"
      }
    },

    status_id: {
      properties: {
        type: "Dropdown",
        label: "Status",
        primeFieldProps: {
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "generalStatus"
      }
    }
  });
  // state management start

  // form submit section start
  const formOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data };
      formData = getUserName(true, formData);
      updateCollegeStaff(formData);
    }
  };

  // update college staff section start
  const updateCollegeStaff = async (data) => {
    await response.update({
      service: collegeStaffService,
      method: "updateCollegeStaff",
      data: { itemId: initValue.user_id, item: data },
      dataTable: dataTableRef
    });
  };
  // update college staff section end
  // form submit section end

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={collegeStaffFormFields} onFormSubmit={formOnsubmit} />
    </div>
  )
};

export default CollegeStaffForm;
