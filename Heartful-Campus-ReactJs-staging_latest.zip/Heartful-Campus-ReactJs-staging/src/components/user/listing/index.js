import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { getModuleAccess, getUserType } from "utils/common";

// components
import UserListing from "components/user/listing/UserListing";

import CollegeStaffs from "components/user/collegeStaff";

import Report from "components/user/report";

// services 
import UserService from 'services/user/user.service';

// prime components 
import { TabView, TabPanel } from 'primereact/tabview';

class ManageUser extends Component {

  constructor(props) {

    super(props);

    this.userService = new UserService();

    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "User", url: "user", },
      ]
    }
  }

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
  }

  // list tabs based on privilege start
  listVisibleTabs = () => {
    let tabs = [
      {
        component: <UserListing />,
        header: "User List"
      },
      {
        component: <CollegeStaffs />,
        header: "College Staff List"
      },
      {
        component: <Report />,
        header: "Reports"
      }
    ]

    if (getUserType() === "U") {
      tabs = tabs.filter(tab => {
        if (tab.slug) {
          const moduleAccess = getModuleAccess(tab.module) || {};
          return Array.isArray(moduleAccess.access) ? moduleAccess.access.includes(tab.slug) : false;
        }
        return true;
      });
    }

    return tabs.map(tab => <TabPanel key={tab.header} header={tab.header}>{tab.component}</TabPanel>)
  }
  // list tabs based on privilege end

  render() {
    return (
      <div>
        <div className='tab-section user-tab-section'>
          <TabView activeIndex={this.state.activeIndex} onTabChange={(e) => this.setState({ activeIndex: e.index })}>
            {this.listVisibleTabs()}
          </TabView>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(ManageUser));