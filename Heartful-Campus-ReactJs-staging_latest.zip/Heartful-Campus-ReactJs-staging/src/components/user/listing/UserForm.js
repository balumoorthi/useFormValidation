import React, { useState } from "react";

// utils 
import { toaster } from "utils/toaster";

import { modalPopup } from 'utils/modalPopup';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { cityAutoCompleteTemplate, getUserName, getUserPrivilagesAccess } from "utils/common";

import { isEmpty } from 'lodash';

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// prime components 
import { Button } from 'primereact/button';

import { Divider } from 'primereact/divider';

// services 
import UserService from 'services/user/user.service';

const UserForm = (props) => {
  // props destructure start
  const { initialValue, dataTableRef } = props
  const { initValue, isEditable } = initialValue;

  const editable = getUserPrivilagesAccess()
  // props destructure end

  // variable init start 
  const userService = new UserService();

  const passwordHeader = <h6>Pick a password</h6>;

  const passwordFooter = (
    <React.Fragment>
      <Divider />
      <p className="p-mt-2">Suggestions</p>
      <ul className="p-pl-2 p-ml-2 p-mt-0" style={{ lineHeight: '1.5' }}>
        <li>At least one lowercase</li>
        <li>At least one uppercase</li>
        <li>At least one numeric</li>
        <li>At least one special character</li>
        <li>Minimum 8 characters</li>
      </ul>
    </React.Fragment>
  );
  // variable init end

  // state management start

  // validations start

  // user form section start 

  // validations 

  const [UserFormFields] = useState({

    abhyasi_id: {
      properties: {
        type: 'InputText',
        label: 'Abhyasi ID',
        validations: {
          required: false,
          pattern: validations.abhyasiId
        }
      },
    },

    name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        validations: {
          required: validations.required,
          pattern: validations.userName,
          maxLength: {
            value: 120,
            message: 'Please enter name with maximum 120 characters'
          },
        }
      }
    },

    email_address: {
      properties: {
        type: 'InputText',
        label: 'Email',
        primeFieldProps: {
          readOnly: isEditable ? true : false,
        },
        validations: {
          required: validations.required,
          pattern: validations.email,
          maxLength: {
            value: 180,
            message: 'Please enter email address with maximum 180 characters'
          }
        }
      }
    },

    password: {
      properties: {
        type: 'Password',
        label: 'Password',
        primeFieldProps: {
          header: passwordHeader,
          footer: passwordFooter,
        },
        validations: {
          required: validations.required,
        }
      }
    },

    contact_number: {
      properties: {
        type: 'PhoneInput',
        label: 'Phone No',
        validations: {
          required: validations.required,
        }
      }
    },

    address: {
      properties: {
        type: 'InputText',
        label: 'Address',
        validations: {
          required: validations.required,
        }
      },
    },

    city: {
      properties: {
        type: 'CityAutoComplete',
        label: 'City',
        fieldWrapperClassNames: 'p-md-12',
        searchField: 'name',
        fieldLabel: 'name',
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        },
        stateField: {
          label: 'State',
          fieldName: 'state',
          fieldWrapperClassNames: 'p-md-12',
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required
          }
        },
        countryField: {
          label: 'Country',
          fieldName: 'country_id',
          fieldWrapperClassNames: 'p-md-12',
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required
          },
          dropdownOptions: "country"
        }
      },
    },

    role_id: {
      properties: {
        type: 'Dropdown',
        label: 'User Role',
        primeFieldProps: {
          filter: true
        },
        dropdownOptions: "roles"
      }
    },

    pincode: {
      properties: {
        type: 'InputText',
        label: 'Pincode',
        validations: {
          required: validations.required,
          maxLength: {
            value: 10,
            message: 'Please enter pincode with maximum 10 characters'
          },
        }
      }
    },

    zone_id: {
      properties: {
        type: 'SelectDropdown',
        label: 'Zone',
        primeFieldProps: {
          isSearchable: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "zone"
      }
    },

    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "userStatus"
      }
    },
    secondary_user_type: {
      properties: {
        type: 'Dropdown',
        label: 'Enable User as Trainer',
        visibility: editable,
        primeFieldProps: {
          options: [
            {
              label: "Yes",
              value: "T"
            },
            {
              label: "No",
              value: "No"
            }
          ]
        }
      }
    },

  });

  // form submit 
  const UserFormFieldsonUpdate = {
    abhyasi_id: UserFormFields.abhyasi_id,
    name: UserFormFields.name,
    email_address: UserFormFields.email_address,
    contact_number: UserFormFields.contact_number,
    address: UserFormFields.address,
    city: UserFormFields.city,
    pincode: UserFormFields.pincode,
    zone_id: UserFormFields.zone_id,
    status_id: UserFormFields.status_id,
    role_id: UserFormFields.role_id,
    secondary_user_type: UserFormFields.secondary_user_type
  }

  const UserFormFieldsOnAdd = {
    abhyasi_id: UserFormFields.abhyasi_id,
    name: UserFormFields.name,
    email_address: UserFormFields.email_address,
    password: UserFormFields.password,
    contact_number: UserFormFields.contact_number,
    address: UserFormFields.address,
    city: UserFormFields.city,
    // state: UserFormFields.state,
    // country_id: UserFormFields.country_id,
    pincode: UserFormFields.pincode,
    zone_id: UserFormFields.zone_id,
    role_id: UserFormFields.role_id,
  }

  const UserFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      formData = getUserName(isEditable, formData)
      Object.keys(data).forEach(key => {
        if (key === "secondary_user_type") {
          if (data[key] === "T") {
            Object.assign(formData, { "secondary_role_id": "6" });
          }
        }
      });
      addUpdateUser(formData)
    }
  }

  // form submit section 

  const UserFormSubmitButtonGroup = () => {
    return (
      <div className="form-button-group">
        <Button type="button" className='p-button p-button-secondary p-mr-2' label="Cancel" onClick={() => { modalPopup.toggle(false) }}>
        </Button>
        {
          isEditable && initValue.status_id === 3 &&
          <Button type="button" label="Activate" className="p-button p-button-primary p-mr-2" onClick={() => ActivateUser()} />
        }
        <Button type="submit" label={isEditable ? "Update" : "Create"} className="p-button p-button-primary" />
      </div>
    )
  }

  // user form section end 

  // add new user 

  const addUpdateUser = async (data) => {
    if (!isEditable) {
      await response.add({
        service: userService,
        method: 'addUser',
        data: { item: data },
        dataTable: dataTableRef,
      })
    } else {
      await response.update({
        service: userService,
        method: 'updateUser',
        data: { itemId: initValue.user_id, item: data },
        dataTable: dataTableRef,
      })
    }
  }

  const ActivateUser = async () => {
    let userResponse, userResponseData;
    try {
      userResponse = await userService.activateUser({ email_address: initValue.email_address });

      if (userResponse.data) {
        userResponseData = userResponse.data;
      }
      if (!userResponseData.isError) {
        toaster.success(userResponseData.message || 'User Activated successfully');
        (dataTableRef.current) ? dataTableRef.current.loadData() : console.log("empty datatable");
        modalPopup.toggle(false);
      } else {
        toaster.error(userResponseData.message || 'User not activated')
      }
    } catch (err) {
      console.log(err)
    }
  }

  return (
    <div>
      <HFNDynamicForm
        initialValues={initValue}
        fields={!isEditable ? UserFormFieldsOnAdd : UserFormFieldsonUpdate}
        onFormSubmit={UserFormOnsubmit}
        submitButtonGroup={UserFormSubmitButtonGroup}
      />
    </div>
  );

}

export default UserForm;
