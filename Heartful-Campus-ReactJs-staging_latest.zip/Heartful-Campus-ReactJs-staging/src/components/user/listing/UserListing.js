import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { createdDateBadge, countryBadge, stateBadge, statusBadge, secondaryRole } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { bulk } from "utils/bulk";

import { getUserName, getModuleAccess, getUser } from "utils/common";

// components
import UserForm from 'components/user/listing/UserForm';

import UserRoleUpdateForm from 'components/user/listing//UserRoleUpdate';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import UserService from 'services/user/user.service';

class UserListing extends Component {

  constructor(props) {

    super(props);

    this.userService = new UserService();

    this.userTable = React.createRef(null);

    this.userFormInitValue = {
      abhyasi_id: null,
      name: null,
      email_address: null,
      contact_number: null,
      address: null,
      city: null,
      state: null,
      country_id: null,
      pincode: null,
      zone_id: null,
      role_id: 6,
      manage_zone: null,
      manage_state: null,
    }

    this.state = {

      userForm: {
        isEditable: false,
        initValue: this.formInitValue,
      },
      updateRole:false,

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "User", url: "user", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("USER"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.userService,

        method: 'getUserList',

        params : {
          manage_state : (getUser().role_slug === 'state-coordinator') ? getUser().state : undefined,
          manage_zone: (getUser().role_slug === 'zone-coordinator') ? getUser().zone : undefined,
          role: getUser() ? getUser().role_slug : undefined
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'name',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Email',
            field: 'email_address',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
            transformValue: false
          },
          {
            header: 'Secondary Role',
            field: 'secondary_user_type',
            sortable: true,
            filter: true,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: 'trainerSearchOption'
            },
            body: secondaryRole,
            headerStyle: {
              width: '160px'
            }
          },
          {
            header: 'State',
            field: 'state',
            sortable: true,
            filter: true,
            body: stateBadge,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Country',
            field: 'country_id',
            sortable: true,
            filter: true,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "country",
              primeFieldProps: {
                filter: true
              }
            },
            body: countryBadge,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "userStatus",
            },
            body: statusBadge,
            headerStyle: {
              width: '120px'
            }
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            body: createdDateBadge,
            headerStyle: {
              width: '120px'
            }
          },
        ],

        actionBtnOptions: [
          {
            title: 'Edit User',
            onClick: this.editUser
          },
          {
            onClick: this.editUserRoles,
            type:'update',
            title:'Manage State/Zone',
            icon: "pi pi-user-edit edit-icon",
            visibilityCheck: rowData => ((rowData.role_id === 5 || rowData.role_id === 7 ) ? true  : false)
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            title: 'Delete User',
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);
              confirmDialog.accept(() => { this.removeUser(rowdata.user_id) });
            }
          }
        ],

        toolBarBtnOptions: {
          title: 'user list',
          selection: {
            field: {
              options: "userStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "You are about to mass update the status of users?" });
                confirmDialog.accept(() => { this.bulkStatusUpdate(selections, status) });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({ message: "Are you sure you want to delete these users? This may affect other screens" });
                confirmDialog.accept(() => { this.bulkDelete(selections) });
              }
            },
          },
          rightBtnsOptions: [
            {
              onClick: this.setUserFormInitValue
            }
          ]
        },
        enableSelection: true,
      }

      // datatables 
    }
  }

  //bulk update starts
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "User",
        name: "user_id",
        value: selections.map(value => { return value.user_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.userTable,
    })
  }
  //bulk update end

  //bulk delete starts
  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "User",
        name: "user_id",
        value: selections.map(value => { return value.user_id }),
        deleted_by: getUserName()
      },
      dataTable: this.userTable,
    })
  }
  //bulk delete end

  // Add User Starts
  setUserFormInitValue = () => {
    this.setState({
      userForm: {
        ...this.state.userForm,
        initValue: this.userFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'add user', className: 'sdm-popup' })
      })
  }
  // Add User end

  //Edit User starts
  editUser = (ev, rowdata) => {
    this.setState({
      userForm: {
        ...this.state.userForm,
        initValue: {
          user_id: rowdata.user_id,
          abhyasi_id: rowdata.abhyasi_id,
          name: rowdata.name,
          email_address: rowdata.email_address,
          contact_number: rowdata.contact_number,
          address: rowdata.address,
          city: rowdata.city,
          state: rowdata.state,
          country_id: rowdata.country_id,
          status_id: rowdata.status_id,
          pincode: rowdata.pincode,
          zone_id: rowdata.zone_id,
          role_id: rowdata.role_id,
          manage_zone: rowdata.manage_zone,
          manage_state: rowdata.manage_state,
          secondary_user_type: rowdata.secondary_user_type === null ? "No" :rowdata.secondary_user_type
        },
        isEditable: true
      },
      updateRole:false
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'update user', className: 'sdm-popup' })
      })
  }

  //update roles
  editUserRoles = (ev, rowdata) => {
    this.setState({
      userForm: {
        ...this.state.userForm,
        initValue: {
          user_id: rowdata.user_id,
          secondary_role_id: rowdata.secondary_role_id,
          secondary_user_type: rowdata.secondary_user_type,
          abhyasi_id: rowdata.abhyasi_id,
          name: rowdata.name,
          email_address: rowdata.email_address,
          contact_number: rowdata.contact_number,
          address: rowdata.address,
          city: rowdata.city,
          state: rowdata.state,
          country_id: rowdata.country_id,
          status_id: rowdata.status_id,
          pincode: rowdata.pincode,
          zone_id: rowdata.zone_id,
          role_id: rowdata.role_id,
          manage_zone: rowdata.manage_zone,
          manage_state: rowdata.manage_state,
        },
        isEditable: true
      },
      updateRole:true
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: rowdata.role_id === 5 ? 'Manage State' : 'Manage Zone', className: 'sdm-popup' })
      })
  }
  //Edit User end

  //remove User starts
  removeUser = async (id) => {
    await response.remove({
      service: this.userService,
      method: 'removeUser',
      data: { itemId: id },
      dataTable: this.userTable,
    })
  }
  //remove User end

  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    dropdown.userStatus();
    dropdown.country();
    dropdown.zone();
    dropdown.roles();
    dropdown.trainerSearchOption();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.userTable} options={this.state.options} />
        
        {this.state.updateRole === true ?
        <HFNModalPopup>
          <UserRoleUpdateForm initialValue={this.state.userForm} dataTableRef={this.userTable} fieldOptions={this.state.fieldOptions} />
        </HFNModalPopup>:<HFNModalPopup>
          <UserForm initialValue={this.state.userForm} dataTableRef={this.userTable} fieldOptions={this.state.fieldOptions} />
        </HFNModalPopup>}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(UserListing));