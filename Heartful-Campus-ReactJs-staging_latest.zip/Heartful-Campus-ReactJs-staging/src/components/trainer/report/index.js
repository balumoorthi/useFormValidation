import React, { Component } from 'react';

// components
//shared-components
import ReportForm from "shared-components/report";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from 'utils/dropdown';

import { cityAutoCompleteTemplate } from 'utils/common';

// services
import TrainerService from 'services/trainer/trainer.service';

class TrainerReport extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.trainerService = new TrainerService();
    // variable init end

    // state management start
    this.state = {
      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Trainer Report", url: "trainer/reports", },
      ],

      initialValues: {},

      options: {
        title: "Trainer Report",

        service: this.trainerService,

        method: "getTrainerReport",

        rows: 1000,

        timestampSuffix: "DDMMYYYY",

        fileName: "Trainer_Report",

        columns: [
          {
            label: "Name",
            key: "name"
          },
          {
            label: "Email",
            key: "email_address"
          },
          {
            label: "Phone No",
            key: "contact_number"
          },
          {
            label: "Address",
            key: "address"
          },
          {
            label: "City",
            key: "city"
          },
          {
            label: "State",
            key: "state"
          },
          {
            label: "Country",
            key: "country_name"
          },
          {
            label: "Pincode",
            key: "pincode"
          },
          {
            label: "Status",
            key: "status_name"
          },
          {
            label: "Center",
            key: "center"
          },
          {
            label: "Batch",
            key: "batch_name"
          },
          {
            label: "Profession",
            key: "profession"
          },
          {
            label: "Education",
            key: "education"
          },
          {
            label: "Language",
            key: "language_name"
          },
          {
            label: "Age Group",
            key: "age_group_name"
          },
          {
            label: "Experience Remarks",
            key: "exp_remarks"
          },
          {
            label: "Public Speaker Profile",
            key: "motivation_remarks"
          },
        ]
      },

      formFields: {

        from_date: {
          properties: {
            type: 'Calendar',
            label: 'Registered From',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              maxDate: new Date(),
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          }
        },

        to_date: {
          properties: {
            type: 'Calendar',
            label: 'Registered To',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: {
              readOnlyInput: true,
              dateFormat: "M dd, yy",
              maxDate: new Date(),
              showButtonBar: true,
              todayButtonClassName: "p-button-secondary p-ml-2",
              clearButtonClassName: "p-button-secondary p-mr-2"
            }
          }
        },

        city: {
          properties: {
            type: 'CityAutoComplete',
            label: 'City',
            fieldWrapperClassNames: 'p-md-3',
            searchField: 'name',
            fieldLabel: 'name',
            primeFieldProps: {
              itemTemplate: cityAutoCompleteTemplate
            },
            validations: {
              minLength: {
                value: 3,
                message: 'Search value must be minimum 3 character...'
              },
            },
            stateField: {
              label: 'State',
              fieldName: 'state',
              fieldWrapperClassNames: 'p-md-3'
            },
            countryField: {
              label: 'Country',
              fieldName: 'country_id',
              fieldWrapperClassNames: 'p-md-3',
              primeFieldProps: {
                filter: true,
                showClear: true
              },
              dropdownOptions: "country"
            }
          },
        },

        pincode: {
          properties: {
            type: 'InputText',
            label: 'Pincode',
            fieldWrapperClassNames: 'p-md-3',
            validations: {
              maxLength: {
                value: 10,
                message: 'Please enter pincode with maximum 10 characters'
              },
            }
          }
        },

        zone_id: {
          properties: {
            type: 'SelectDropdown',
            label: 'Zone',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { isSearchable: true, isClearable: true },
            dropdownOptions: "zone"
          }
        },

        status_id: {
          properties: {
            type: 'Dropdown',
            label: 'Status',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: "userStatus"
          }
        },

        first_language: {
          properties: {
            type: 'Dropdown',
            label: 'Language',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: "language"
          }
        },

        age_group: {
          properties: {
            type: 'Dropdown',
            label: 'Age Group',
            fieldWrapperClassNames: 'p-md-3',
            primeFieldProps: { filter: true, showClear: true },
            dropdownOptions: "ageGroup"
          }
        }
      }
    };
    // state management end
  }

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.userStatus();
    dropdown.country();
    dropdown.zone();
    dropdown.language();
    dropdown.ageGroup();
  }

  render() {
    return (
      <div>
        <ReportForm fields={this.state.formFields} initialValues={this.state.initialValues} options={this.state.options} />
      </div>
    )
  }
}

export default TrainerReport;
