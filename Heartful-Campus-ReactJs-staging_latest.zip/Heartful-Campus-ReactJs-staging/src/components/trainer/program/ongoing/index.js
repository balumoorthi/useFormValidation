import React, { Component } from 'react';

import { moduleBadge, sessionDateBadge, createdDateBadge } from "utils/badgeTemplate";

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// services
import TrainerService from "services/trainer/trainer.service";

//utils
import { dropdown } from 'utils/dropdown';

class OnGoing extends Component {

  constructor(props) {

    super(props);

    //variable init starts
    this.trainerService = new TrainerService();
    //variable init end
    this.state = {
      //datatables
      options: {

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getTrainerPrograms',

        params: {
          event_status: "ONGOING"
        },

        urlPath: props.trainerID,

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'module_id',
            sortField: "SortingDisabled",
            filter: true,
            headerStyle: {
              width: '200px'
            },
            filterType: 'select',
            filterElementOptions: {
              type: 'Dropdown',
              value: "moduleList",
              primeFieldProps: {
                className: "p-inputtext-sm",
                filter: true,
              }
            },
            body: moduleBadge
          },
          {
            header: 'Program',
            field: 'cart_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'College',
            field: 'college_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Start Date',
            field: 'event_start_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat:"YYYY-MM-DD",
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'End Date',
            field: 'event_end_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat:"YYYY-MM-DD",
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '150px'
            },
            body: createdDateBadge,
          },
        ],

        enableActionColumn: false,

        toolBarBtnOptions: {
          title: '',
          rightBtnsOptions: [
            { visibility: false }
          ]
        }

      },
    }
  }

  componentDidMount(){
    dropdown.moduleList()
  }

  render() {
    return (
      <div>
        <HFNDataTable options={this.state.options} />
      </div>
    )
  }
}

export default OnGoing;