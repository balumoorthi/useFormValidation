import React, { Component } from 'react'

import { withRouter } from 'react-router';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// utils
import { sessionDateBadge, createdDateBadge, gotoPage } from "utils/badgeTemplate";

// services
import TrainerService from "services/trainer/trainer.service";

import { dropdown } from 'utils/dropdown';

class Completed extends Component {

  constructor(props) {

    super(props);

    this.trainerService = new TrainerService();

    this.state = {

      options: {

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getTrainerPrograms',

        params: {
          event_status: "COMPLETED"
        },

        urlPath: props.trainerID,

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'modules.module_name',
            filterField : "module_id",
            sortField: "SortingDisabled",
            filter: true,
            filterElementOptions: {
              type: 'Dropdown',
              value: "moduleList",
              primeFieldProps: {
                className: "p-inputtext-sm",
                filter: true,
              }
            },
            headerStyle: {
              width: '200px'
            },
            body: (rowData, { field }) => { return gotoPage(rowData, field, this.viewParticipants) }
          },
          {
            header: 'Program',
            field: 'cart_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'College',
            field: 'college_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Start Date',
            field: 'event_start_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat:"YYYY-MM-DD",
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'End Date',
            field: 'event_end_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat:"YYYY-MM-DD",
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              outputFormat:"YYYY-MM-DD",
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '150px'
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-ml-2 p-mr-2 p-button-icon-only",
            title: 'Manage Participants',
            onClick: this.viewParticipants
          },
          {
            visibility: false
          }
        ],

        toolBarBtnOptions: {
          title: '',
          rightBtnsOptions: [
            { visibility: false }
          ]
        }

      },
    }
  }

  viewParticipants = (ev, rowData) => {
    let trainerID = this.props.trainerID, sessionID = rowData.session_id;
    if (trainerID && sessionID)
      this.props.history.push(`/trainer/${trainerID}/programs/${sessionID}/participant`);
  }

  componentDidMount(){
    dropdown.moduleList()
  }

  render() {
    return (
      <div>
        <HFNDataTable options={this.state.options} />
      </div>
    )
  }
}

export default withRouter(Completed);