import React, { Component } from 'react'

//components

import CalendarProgram from 'components/trainer/program/calendar/CalendarProgram';

// shared components 
import HFNCalendar from 'shared-components/calendar';

// prime components
import { Divider } from 'primereact/divider';

import HFNModalPopup from 'shared-components/modalPopup';

// utils
import { isEmpty } from "lodash";

import moment from 'moment';

import { modalPopup } from "utils/modalPopup";

// services
import TrainerService from "services/trainer/trainer.service";

class Calendar extends Component {

  constructor(props) {
    super(props);

    this.trainerService = new TrainerService();

    this.state = {
      options: {

        service: this.trainerService,
  
        method: 'getTrainerCalendar',

        params: {
          user_info_id: props.trainerID,
        },

        eventProps: {
          title: "session_name",
          start: "event_start_date",
          end: "event_end_date",
        },

        calendarOptions: {
          header: {
            right: ''
          },

          displayEventTime: false,
  
          eventClick: this.onProgramClick
        }
      },
      program: {}
    }
  }

  onProgramClick = info => {
    if (info.event && !isEmpty(info.event.extendedProps)) {
      let programData = info.event.extendedProps, program = {}, date;
      program.trainerID = this.props.trainerID;
      program.sessionID = programData.session_id;
      program.programName = programData.cart_name;
      program.sessionName = programData.session_name;
      program.college = programData.college_name;
      if (programData.event_start_date) {
        date = new Date(programData.event_start_date)
        program.start = (!isNaN(date)) ? moment(date).format('MMM DD, YYYY hh:mm A') : "";
      }
      if (programData.event_end_date) {
        date = new Date(programData.event_end_date)
        program.end = (!isNaN(date)) ? moment(date).format('MMM DD, YYYY hh:mm A') : "";

        if (program.end) {
          let currentDate = new Date();
          program.completed =  currentDate > date ? true : false;
        }
      }
      program.location = programData.location;
      this.setState({program: program}, () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: (program.programName || "-"), className: 'sdm-popup' })
      })
    }
  }

  render() {
    return (
      <div>
        <h3>Trainer Calendar</h3>
        <Divider/>
        <HFNCalendar options={this.state.options} />
        <HFNModalPopup>
          <CalendarProgram program={this.state.program}/>
        </HFNModalPopup>
      </div>
    )
  }
}

export default Calendar;