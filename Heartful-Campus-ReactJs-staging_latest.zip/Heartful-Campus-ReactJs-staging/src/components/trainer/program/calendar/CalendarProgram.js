import React, { Component } from 'react';

import { withRouter } from "react-router";

// components

// prime components 
import { Button } from 'primereact/button';

// utils
import { modalPopup } from 'utils/modalPopup';

import { getUserType } from 'utils/common';

class CalendarProgram extends Component {
  openParticipants = () => {
    const { trainerID, sessionID } = this.props.program;
    if (trainerID && sessionID) {
      modalPopup.toggle(false);
      if (getUserType() === "T") {
        this.props.history.push(`/myprograms/${sessionID}/participant`);
      }
      else {
        this.props.history.push(`/trainer/${trainerID}/programs/${sessionID}/participant`);
      }
    }
  }

  render() {
    const { sessionName, college, start, end, completed } = this.props.program;
    return (
      <div>
      <div className="p-d-flex">
        <div className="p-m-2"><b> Session Name: </b></div>
        <div className="p-m-2"> {sessionName || "-"} </div>
      </div>
        <div className="p-d-flex">
          <div className="p-m-2"><b> College Name: </b></div>
          <div className="p-m-2"> {college || "-"} </div>
        </div>
        <div className="p-d-flex">
          <div className="p-m-2"><b> Start: </b></div>
          <div className="p-m-2"> {start || "-"} </div>
        </div>
        <div className="p-d-flex">
          <div className="p-m-2"><b> End: </b></div>
          <div className="p-m-2"> {end || "-"} </div>
        </div>
        <div className=" p-col-12 calendar-popup-button-group">
          { completed && 
            <Button type="button" className="p-button p-button-primary p-mr-2" label="Open Participants" onClick={this.openParticipants} />
          }
          <Button type="button" className='p-button p-button-secondary' label="Close" onClick={() => { modalPopup.toggle(false) }} />
        </div>
      </div>
    )
  }
}

export default withRouter(CalendarProgram);
