import React, { Component } from 'react';

import { withRouter } from 'react-router';

// state 
import { connect } from "react-redux";

// components
import OnGoing from 'components/trainer/program/ongoing';

import Completed from 'components/trainer/program/completed';

import Calendar from 'components/trainer/program/calendar';

// prime components
import { Divider } from 'primereact/divider';

import { Accordion, AccordionTab } from 'primereact/accordion';

import { TabView, TabPanel } from 'primereact/tabview';

// utils
import { response } from "utils/response";

import { isObject, isString, toUpper } from "lodash";

import { toaster } from "utils/toaster";

import buildBreadcrumb from "utils/breadcrumb";

import { dropdown } from 'utils/dropdown';

// services
import TrainerService from "services/trainer/trainer.service";

class TrainerDetails extends Component {

  constructor(props) {

    super(props);

    this.trainerService = new TrainerService();

    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Trainer List", url: "trainer/listing", },
        { label: "Programs", url: "", },
      ],

      trainerInfo: null,

      trainerID: this.props.match.params.id
    }
  }

  getTrainerDetail = async () => {
    const errorMessage = "Unable to fetch trainer details";
    try {
      const apiResponse = await response.get(
        {
          service: this.trainerService,
          method: 'getTrainer',
          data: { itemId: this.state.trainerID }
        });

      if (apiResponse && apiResponse.data) {
        const apiResponseData = apiResponse.data;

        if (!apiResponseData.isError) {

          if (isObject(apiResponseData.data)) {
            let trainerInfo = apiResponseData.data;
            const trainer = trainerInfo.trainer;

            if (trainer) {
              if (Array.isArray(trainer.language)) {
                trainerInfo.language = trainer.language.reduce((languages, language) => {
                  if (languages)
                    return languages + ", " + (language.language_name ? language.language_name : "-");
                  else
                    return language.language_name || "-";
                }, "");
              }
              else if (trainer.language && trainer.language.language_name) {
                trainerInfo.language = trainer.language.language_name;
              }
            }

            this.setState({
              trainerInfo: trainerInfo
            });
          }

        } else {
          toaster.error(apiResponseData.message || errorMessage)
        }
      }
    }
    catch (err) {
      toaster.error(errorMessage)
    }

  }

  componentDidMount = () => {
    buildBreadcrumb(null, this.state.breadcrumbs);
    this.getTrainerDetail();
    dropdown.zone();
  }
  render() {
    // state and props destructure start
    const trainerInfo = this.state.trainerInfo || {};
    const trainer = trainerInfo.trainer ? trainerInfo.trainer : {};
    const zone = this.props.zones.find(value => value.value === trainerInfo.zone_id);
    // state and props destructure end

    return (
      <>
        <div className='p-card'>

          <div className="p-card-body">

            <div className="p-col-12">
              <h3>Trainer Programs</h3>
            </div>
            <Divider />
            <Accordion activeIndex={0} >
              <AccordionTab header="Trainer Details" >
                <div className="p-d-flex p-flex-wrap">
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Name</b>
                    </p>
                    <div>{trainerInfo.name || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Email</b>
                    </p>
                    <div>{trainerInfo.email_address || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Phone No</b>
                    </p>
                    <div>{trainerInfo.contact_number || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Address</b>
                    </p>
                    <div>{trainerInfo.address || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>City</b>
                    </p>
                    <div>{trainerInfo.city || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>State</b>
                    </p>
                    <div>{trainerInfo.state ? toUpper(trainerInfo.state) : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Zone</b>
                    </p>
                    <div>{(zone && zone.label) ? zone.label : '-'}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Country</b>
                    </p>
                    <div>{(trainerInfo.country && trainerInfo.country.country_name) ? trainerInfo.country.country_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Pincode</b>
                    </p>
                    <div>{trainerInfo.pincode || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Status</b>
                    </p>
                    <div>{(trainerInfo.status && trainerInfo.status.status_name) ? trainerInfo.status.status_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Center</b>
                    </p>
                    <div>{(trainer.center && isString(trainer.center)) ? trainer.center : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Batch</b>
                    </p>
                    <div>{(trainer.batch && trainer.batch.batch_name) ? trainer.batch.batch_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Profession</b>
                    </p>
                    <div>{(trainer.profession && isString(trainer.profession)) ? trainer.profession : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Education</b>
                    </p>
                    <div>{(trainer.education && isString(trainer.education)) ? trainer.education : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Language</b>
                    </p>
                    <div>{trainerInfo.language || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Age Group</b>
                    </p>
                    <div>{(trainer.agegroup && trainer.agegroup.age_group_name) ? trainer.agegroup.age_group_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Experience Remarks</b>
                    </p>
                    <div>{trainer.exp_remarks || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Public Speaker Profile</b>
                    </p>
                    <div>{trainer.motivation_remarks || "-"}</div>
                  </div>
                </div>
              </AccordionTab>
            </Accordion>

          </div>
        </div>

        <div className='tab-section'>

          <TabView>
            <TabPanel header="Upcoming Programs">
              <OnGoing trainerID={this.state.trainerID} />
            </TabPanel>
            <TabPanel header="Completed Programs">
              <Completed trainerID={this.state.trainerID} />
            </TabPanel>
            <TabPanel header="Calendar View">
              <Calendar trainerID={this.state.trainerID} />
            </TabPanel>
          </TabView>
        </div>
      </>
    )
  }
}

const mapStateToProps = (state) => ({
  zones: state.dropdownDetails.zone,
});

export default withRouter(connect(mapStateToProps)(TrainerDetails));
