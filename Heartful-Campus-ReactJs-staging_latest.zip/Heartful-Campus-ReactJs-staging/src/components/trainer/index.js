import React, { Component } from 'react';

import { Switch, } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import TrainerListing from 'components/trainer/listing';

import TrainerProgram from 'components/trainer/program';

import TrainerReport from 'components/trainer/report';

import Participant from 'components/trainer/participant';

// shared components 
import HFNLoader from 'shared-components/lazyLoading';

class Trainer extends Component {
  render() {
    return (
      <div>
        <HFNLoader>
          <Switch>
            <AuthGuard path='/trainer/listing' component={TrainerListing} />
            <AuthGuard path='/trainer/:trainerID/programs/:sessionID/participant' component={Participant} />
            <AuthGuard path='/trainer/:id/programs' component={TrainerProgram} />
            <AuthGuard path='/trainer/report' component={TrainerReport} />
          </Switch>
        </HFNLoader>
      </div>
    );
  }
}

export default Trainer;
