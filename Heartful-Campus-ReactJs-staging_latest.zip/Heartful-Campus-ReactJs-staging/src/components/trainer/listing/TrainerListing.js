import React, { Component } from 'react';

import { withRouter } from "react-router";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from "utils/response";

import { dropdown } from "utils/dropdown";

import { countryBadge, createdDateBadge, statusBadge, stateBadge, gotoPage } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { modalPopup } from "utils/modalPopup";

import { bulk } from "utils/bulk";

import { getUserName, getModuleAccess, getUser } from "utils/common";

// components
import TrainerForm from 'components/trainer/listing/TrainerForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services 
import TrainerService from 'services/trainer/trainer.service';

class TrainerListing extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.trainerService = new TrainerService();

    this.trainerTable = React.createRef(null);

    this.trainerFormInitValue = {
      abhyasi_id: null,
      name: null,
      email_address: null,
      contact_number: null,
      address: null,
      city: null,
      state: null,
      country_id: null,
      pincode: null,
      zone_id: null,
      center: null,
      batch: null,
      profession: null,
      education: null,
      language: null,
      age_group: null,
      exp_remarks: null,
      motivation_remarks: null
    }

    const moduleAccess = getModuleAccess("TRAINER") || {};
    const enableViewLink = Array.isArray(moduleAccess.access) ? moduleAccess.access.includes("view") : false;
    // variable init end

    // state management start
    this.state = {

      trainerForm: {
        isEditable: false,
        initValue: this.trainerFormInitValue,
      },

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Trainer", url: "trainer", },
      ],

      // datatables 

      options: {

        privilege: {
          isActive: true,
          moduleName: getModuleAccess("TRAINER"),
        },

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getTrainerList',

        params: {
          manage_state: (getUser().role_slug === 'state-coordinator') ? getUser().state : undefined,
          manage_zone: (getUser().role_slug === 'zone-coordinator') ? getUser().zone : undefined,
          role: getUser() ? getUser().role_slug : undefined
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Name',
            field: 'name',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '150px'
            },
            body: enableViewLink ? (rowData, { field }) => { return gotoPage(rowData, field, this.openPrograms) } : null
          },
          {
            header: 'Email',
            field: 'email_address',
            sortable: true,
            filter: true,
            headerStyle: {
              width: '200px'
            },
            transformValue: false
          },
          {
            header: 'State',
            field: 'state',
            sortable: true,
            filter: true,
            body: stateBadge,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Country',
            field: 'country_id',
            sortable: true,
            filter: true,
            body: countryBadge,
            filterType: 'select',
            headerStyle: {
              width: '150px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "country",
              primeFieldProps: {
                className: "p-inputtext-sm",
                filter: true,

              }
            },
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: true,
            filterType: 'select',
            headerStyle: {
              width: '120px'
            },
            filterElementOptions: {
              type: 'Dropdown',
              value: "userStatus",
            },
            body: statusBadge,

          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '120px'
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-ml-2 p-mr-2 p-button-icon-only",
            title: 'Manage Trainer Programs',
            onClick: this.openPrograms
          },
          {
            type: 'update',
            icon: "uil uil-pen edit-icon",
            className: "p-mr-2",
            title: 'Edit Trainer',
            onClick: this.editTrainer
          },
          {
            type: 'delete',
            icon: "uil uil-trash-alt remove-icon",
            className: "p-mr-23",
            title: 'Delete Trainer',
            onClick: (ev, rowData) => {
              confirmDialog.toggle(true)
              confirmDialog.custom({
                message: "Are you sure you want to delete this trainer?",
                accept: () => { this.removeTrainer(rowData.user_id) }
              })
            }
          },
        ],

        toolBarBtnOptions: {
          title: 'trainer list',
          selection: {
            field: {
              options: "generalStatus"
            },
            updateBtnsOptions: {
              onClick: ({ selections, status }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "You are about to mass update the status of trainers?",
                  accept: () => { this.bulkStatusUpdate(selections, status) }
                });
              }
            },
            deleteBtnsOptions: {
              onClick: ({ selections }) => {
                confirmDialog.toggle(true);
                confirmDialog.custom({
                  message: "Are you sure you want to delete these trainers?",
                  accept: () => { this.bulkDelete(selections) }
                });
              }
            },
          },
          rightBtnsOptions: [
            {
              onClick: this.setTrainerFormInitValue
            }
          ]
        },
        enableSelection: true,
      }

      // datatables 
    }
    // state management end
  }

  // bulk actions start
  bulkStatusUpdate = async (selections, status_id) => {
    await bulk.setBulkStatus({
      data: {
        type: "User",
        name: "user_id",
        value: selections.map(value => { return value.user_id }),
        status_id: status_id,
        updated_by: getUserName()
      },
      dataTable: this.trainerTable,
    })
  }

  bulkDelete = async (selections) => {
    await bulk.deleteBulkItems({
      data: {
        type: "User",
        name: "user_id",
        value: selections.map(value => { return value.user_id }),
        deleted_by: getUserName()
      },
      dataTable: this.trainerTable,
    })
  }
  // bulk actions end

  // add, edit and remove trainer section start
  setTrainerFormInitValue = () => {
    this.setState({
      trainerForm: {
        ...this.state.trainerForm,
        initValue: this.trainerFormInitValue,
        isEditable: false
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'add trainer', className: 'sdm-popup trainer-register-form' })
      })
  }

  editTrainer = (ev, rowData) => {
    this.setState({
      trainerForm: {
        ...this.state.trainerForm,
        initValue: {
          user_id: rowData.user_id,
          abhyasi_id: rowData.abhyasi_id,
          name: rowData.name,
          email_address: rowData.email_address,
          contact_number: rowData.contact_number,
          address: rowData.address,
          city: rowData.city,
          state: rowData.state,
          country_id: rowData.country_id,
          status_id: rowData.status_id,
          pincode: rowData.pincode,
          zone_id: rowData.zone_id,
          salutation: rowData.trainer.salutation,
          center: rowData.trainer.center,
          batch: (rowData.trainer.batch && rowData.trainer.batch.batch_id) ? rowData.trainer.batch.batch_id : null,
          profession: rowData.trainer.profession,
          education: rowData.trainer.education,
          first_language: Array.isArray(rowData.trainer.language)
            ?
            rowData.trainer.language.map(language => language.language_id)
            :
            ((rowData.trainer.language && rowData.trainer.language.language_id) ? [rowData.trainer.language.language_id] : []),
          age_group: rowData.trainer.age_group,
          exp_remarks: rowData.trainer.exp_remarks,
          motivation_remarks: rowData.trainer.motivation_remarks
        },
        isEditable: true
      }
    },
      () => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Update trainer', className: 'sdm-popup trainer-register-form' })
      })
  }

  removeTrainer = async (id) => {
    await response.remove({
      service: this.trainerService,
      method: 'removeTrainer',
      data: { itemId: id },
      dataTable: this.trainerTable,
      toasterMessage: {
        success: 'Trainer deleted successfully',
        error: 'Trainer not deleted'
      }
    })
  }
  // add, edit and remove trainer section end

  // view program section start
  openPrograms = (ev, rowdata) => {
    this.props.history.push(`/trainer/${rowdata.user_id}/programs`);
  }
  // view program section end

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    dropdown.generalStatus();
    dropdown.country();
    dropdown.zone();
    dropdown.ageGroup();
    dropdown.language();
    dropdown.batch();
    dropdown.userStatus();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.trainerTable} options={this.state.options} />
        <HFNModalPopup>
          <TrainerForm initialValue={this.state.trainerForm} dataTableRef={this.trainerTable} />
        </HFNModalPopup>
      </div>
    )
  }
}

export default withRouter(TrainerListing);
