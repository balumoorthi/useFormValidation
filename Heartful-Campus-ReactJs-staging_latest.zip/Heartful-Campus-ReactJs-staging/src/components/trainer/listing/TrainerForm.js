import React, { useState } from "react";

// components 
// prime components 
import { Button } from 'primereact/button';

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { isEmpty } from 'lodash';

import { toaster } from "utils/toaster";

import { modalPopup } from 'utils/modalPopup';

import { validations } from 'utils/validations';

import { response } from "utils/response";

import { cityAutoCompleteTemplate, getUserName, getResponseMessage } from "utils/common";

// services 
import TrainerService from 'services/trainer/trainer.service';

const TrainerForm = (props) => {

  // props destructure start
  const { initialValue, dataTableRef } = props
  const { initValue, isEditable } = initialValue;
  // props destructure end

  // variable init start 
  const trainerService = new TrainerService();
  // variable init end

  // state management start
  const [formInitValue] = useState({
    ...initialValue.initValue,
    status_id: (initValue.status_id !== 3) ? initValue.status_id : null,
  });

  const [registerFormConfig] = useState({
    formClassName: 'register-form-wrapper',
    formSectionClassName: 'register-form-section'
  });

  const [TrainerFormFields] = useState({

    salutation: {
      properties: {
        type: 'Dropdown',
        label: 'Salutation',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          options: [
            {
              label: "Mr",
              value: "Mr"
            },
            {
              label: "Mrs",
              value: "Mrs"
            },
            {
              label: "Miss",
              value: "Miss"
            }
          ]
        },
        validations: {
          required: validations.required,
        }
      }
    },
    name: {
      properties: {
        type: 'InputText',
        label: 'Name',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
        validations: {
          required: validations.required,
          pattern: validations.userName,
          maxLength: {
            value: 120,
            message: 'Please enter name with maximum 120 characters'
          },
        }
      }
    },
    email_address: {
      properties: {
        type: 'InputText',
        label: 'Email',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          readOnly: isEditable ? true : false,
        },
        validations: {
          required: validations.required,
          pattern: validations.email,
          maxLength: {
            value: 180,
            message: 'Please enter email address with maximum 180 characters'
          }
        }
      }
    },

    contact_number: {
      properties: {
        type: 'PhoneInput',
        label: 'Phone No',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
        validations: {
          required: validations.required
        }
      }
    },
    address: {
      properties: {
        type: 'InputText',
        label: 'Address',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
      },
    },
    city: {
      properties: {
        type: 'CityAutoComplete',
        label: 'City',
        fieldWrapperClassNames: 'p-md-6',
        searchField: 'name',
        fieldLabel: 'name',
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: 'Search value must be minimum 3 character...'
          },
        },
        stateField: {
          label: 'State',
          fieldName: 'state',
          fieldWrapperClassNames: 'p-md-6',
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required,
          }
        },
        countryField: {
          label: 'Country',
          fieldName: 'country_id',
          fieldWrapperClassNames: 'p-md-6',
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required,
          },
          dropdownOptions: "country"
        }
      },
    },

    pincode: {
      properties: {
        type: 'InputText',
        label: 'Pincode',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
      }
    },
    zone_id: {
      properties: {
        type: 'SelectDropdown',
        label: 'Zone',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          isSearchable: true
        },
        validations: {
          required: validations.required,
        },
        dropdownOptions: "zone"
      }
    },
    center: {
      properties: {
        type: 'InputText',
        label: 'Center',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
      }
    },
    first_language: {
      properties: {
        type: 'MultiSelect',
        label: 'Language',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
          filter: true,
          showClear: true
        },
        dropdownOptions: "language"

      }
    },
    education: {
      properties: {
        type: 'InputText',
        label: 'Education',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
      }
    },
    batch: {
      properties: {
        type: 'Dropdown',
        label: 'Batch',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {},
        dropdownOptions: "batch"
      }
    },
    profession: {
      properties: {
        type: 'InputText',
        label: 'Profession',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
      }
    },
    age_group: {
      properties: {
        type: 'Dropdown',
        label: 'Age Group',
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
        dropdownOptions: "ageGroup"

      },
    },
    status_id: {
      properties: {
        type: 'Dropdown',
        label: 'Status',
        visibility: isEditable,
        fieldWrapperClassNames: 'p-col-6',
        primeFieldProps: {
        },
        dropdownOptions: "generalStatus"

      },
    },
    exp_remarks: {
      properties: {
        type: 'InputTextarea',
        label: 'Experience Remarks',
        primeFieldProps: {
        },

      },
    },
    motivation_remarks: {
      properties: {
        type: 'InputTextarea',
        label: 'Public Speaker Profile',
        primeFieldProps: {
        },

      },
    },
  });
  // state management end

  // form button section start 
  const TrainerFormSubmitButtonGroup = () => {
    return (
      <div className="form-button-group">
        <Button type="button" className='p-button p-button-secondary p-mr-2' label="Cancel" onClick={() => { modalPopup.toggle(false) }} />
        {
          (isEditable && initValue.status_id === 3)
            ?
            <Button type="button" label="Activate" className="p-button p-button-primary p-mr-2" onClick={() => activateTrainer()} />
            :
            null
        }
        <Button type="submit" label={isEditable ? "Update" : "Create"} className="p-button p-button-primary" />
      </div>
    )
  }
  // form button section end 

  // form submit section start
  const TrainerFormOnsubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data }
      formData = getUserName(isEditable, formData)
      addUpdateTrainer(formData)
    }
  }

  // add new and update trainer section start
  const addUpdateTrainer = async (data) => {
    if (!isEditable) {
      await response.add({
        service: trainerService,
        method: 'addTrainer',
        data: { item: data },
        dataTable: dataTableRef,
        toasterMessage: {
          success: 'Trainer added successfully',
          error: 'Trainer not added'
        }
      })
    } else {
      await response.update({
        service: trainerService,
        method: 'updateTrainer',
        data: { itemId: initValue.user_id, item: data },
        dataTable: dataTableRef,
        toasterMessage: {
          success: 'Trainer updated successfully',
          error: 'Trainer not updated'
        }
      })
    }
  }
  // add new and update trainer section end
  // form submit section end

  // activate trainer section start
  const activateTrainer = async () => {
    try {
      let apiResponse = await trainerService.activateTrainer({ email_address: initValue.email_address });

      if (apiResponse && apiResponse.data) {
        const apiResponseData = apiResponse.data;
        if (!apiResponseData.isError) {
          toaster.success("Trainer activated successfully");
          if (dataTableRef && dataTableRef.current)
            dataTableRef.current.loadData();
          modalPopup.toggle(false);
        }
        else
          toaster.error(getResponseMessage(apiResponseData) || "Trainer not activated");
      }
    }
    catch {
      console.log("Something went wrong.");
    }
  };
  // activate trainer section end

  return (
    <div className='login-section register-section'>
      <div className="card-wrapper">
        <div className="register">
          <HFNDynamicForm
            initialValues={formInitValue}
            fields={TrainerFormFields}
            onFormSubmit={TrainerFormOnsubmit}
            submitButtonGroup={TrainerFormSubmitButtonGroup}
            formConfig={registerFormConfig}
          />
        </div>
      </div>
    </div>
  )
}

export default TrainerForm;
