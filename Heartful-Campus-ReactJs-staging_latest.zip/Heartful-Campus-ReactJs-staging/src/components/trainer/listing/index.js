import React, { Component } from 'react';

import { withRouter } from "react-router";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { getModuleAccess, getUserType } from "utils/common";

// components
import TrainerListing from 'components/trainer/listing/TrainerListing';

import TrainerReport from 'components/trainer/report';

// services 
import TrainerService from 'services/trainer/trainer.service';

// prime components 
import { TabView, TabPanel } from 'primereact/tabview';

class ManageTrainer extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.trainerService = new TrainerService();

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Trainer", url: "trainer", },
      ]
    }
    // state management end
  }

  // list tabs based on privilege start
  listVisibleTabs = () => {
    let tabs = [
      {
        component: <TrainerListing />,
        header: "Trainer List"
      },
      {
        component: <TrainerReport />,
        header: "Report",
        slug: "reports",
        module: "TRAINER"
      }
    ]

    if (getUserType() === "U") {
      tabs = tabs.filter(tab => {
        if (tab.slug) {
          const moduleAccess = getModuleAccess(tab.module) || {};
          return Array.isArray(moduleAccess.access) ? moduleAccess.access.includes(tab.slug) : false;
        }
        return true;
      });
    }

    return tabs.map(tab => <TabPanel key={tab.header} header={tab.header}>{tab.component}</TabPanel>)
  }
  // list tabs based on privilege end

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
  }

  render() {
    return (
      <div>
        <div className='tab-section trainer-tab-section'>
          <TabView activeIndex={this.state.activeIndex} onTabChange={(e) => this.setState({ activeIndex: e.index })}>
            {this.listVisibleTabs()}
          </TabView>
        </div>
      </div>
    )
  }
}

export default withRouter(ManageTrainer);
