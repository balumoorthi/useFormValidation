import React, { Component } from 'react';

import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

import Participants from 'components/college/collegeDetails/program/participant/ParticipantListing';

// utils
import buildBreadcrumb from "utils/breadcrumb";

class Participant extends Component {

  constructor(props) {

    super(props);

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Participant", url: "", },
      ],

      sessionID: this.props.match.params.sessionID
    }
    // state management end
  }

  componentDidMount() {
    let trainerID = this.props.match.params.trainerID, pageBreadcrumbs;
    if (trainerID && (this.props.match.path === '/trainer/:trainerID/programs/:sessionID/participant')) {
      pageBreadcrumbs = [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "Trainer List", url: "trainer/listing" },
        { label: "Program", url: trainerID ? `trainer/${trainerID}/programs` : "" },
        { label: "Participant", url: "" },
      ];
      buildBreadcrumb(this.props, pageBreadcrumbs)
    }
    else if (this.props.match.path === '/myprograms/:sessionID/participant') {
      pageBreadcrumbs = [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "My Program", url: "myprograms" },
        { label: "Participant", url: "" },
      ];
      buildBreadcrumb(this.props, pageBreadcrumbs)
    }
    else {
      buildBreadcrumb(this.props, this.state.breadcrumbs);
    }
  }

  render() {
    return (
      <div className='p-card'>
        <div className='tab-section'>
          <Participants sessionID={this.state.sessionID} />
        </div>
      </div>
    );
  }
}

export default withRouter(connect()(Participant));