import React, { Component } from "react";

// components
// prime components
import { Divider } from "primereact/divider";

import { Calendar } from "primereact/calendar";

import { Button } from "primereact/button";

// shared components
import HFNCalendar from "shared-components/calendar";

// utils
import moment from "moment";

import buildBreadcrumb from "utils/breadcrumb";

import { toaster } from "utils/toaster";

import { getResponseMessage, getUserID } from "utils/common";

// services
import TrainerService from "services/trainer/trainer.service";

import HFNLoading from "shared-components/lazyLoading/Loading";

class TrainerAvailability extends Component {

  constructor(props) {

    super(props);

    // variables init start
    this.trainerService = new TrainerService();

    this.calendarRef = React.createRef(null);
    // variables init end

    // state management start
    this.state = {
      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: "pi pi-home" },
        { label: "Trainer Unavailablity", url: "notify-unavailability", }
      ],
      options: {

        service: this.trainerService,

        method: "gettraineravailability",

        params: {
          user_info_id: getUserID(),
        },
        eventProps: {
          start: "start_date",
          end: "end_date",
          type: "trainer"
        },

        calendarOptions: {
          timeZone: 'UTC',
          header: {
            right: ""
          },

          displayEventTime: false
        }
      },
      program: {},
      seletedDates: "",
      loading: false
    };
    // state management end
  }

  notifyToAdmin = async () => {
    const checkDate = (start, end) => {
      var mStart = moment(start);
      var mEnd = moment(end);
      return mStart.isBefore(mEnd);
    };

    const startDate = this.state.seletedDates[0];
    const endDate = this.state.seletedDates[1];

    let isValidDate = checkDate(startDate, endDate);

    if ((startDate === "" && endDate === "") || (startDate === undefined && endDate === undefined)) {
      toaster.custom({ severity: "error", summary: "The start date and end should not be empty" });
    } else {
      if (!isValidDate) {
        toaster.custom({ severity: "error", summary: "The end date should be greater than start date" });
        return;
      }
    }
    if (isValidDate) {
      let startDateTime = moment(startDate).format("YYYY-MM-DD") + "T00:00:00.000Z";
      let endDateTime = moment(endDate).format("YYYY-MM-DD") + "T23:59:59.000Z";

      let notifyData = {
        start_date: startDateTime,
        user_id: getUserID(),
        end_date: endDateTime
      };

      try {
        this.setState({ loading: true })
        let apiResponse = await this.trainerService.traineravailability({ item: notifyData });

        if (apiResponse && apiResponse.data) {
          const apiResponseData = apiResponse.data;
          const errorMessage = apiResponseData.message[0].user_id
          if (!apiResponseData.isError) {
            this.setState({ loading: false })
            toaster.success(getResponseMessage(apiResponseData) || "Dates updated successfully");
            if (this.calendarRef && this.calendarRef.current)
              this.calendarRef.current.refresh();
          }
          else {
            this.setState({ loading: false })
            toaster.error(errorMessage || "Dates Not Updated Successfully");
          }
        }
      }
      catch {
        this.setState({ loading: false })
        console.log("Something went wrong.");
      }
    }
  }

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
  }

  render() {
    return (
      <div>
        <h3>Trainer Unavailability Calendar</h3>
        <Divider />
        <div className="p-fluid p-grid p-formgrid">
          <div className="p-field p-col-12 p-md-4">
            <label htmlFor="range">Start and End Date</label>
            <Calendar id="range" minDate={new Date()} value={this.state.seletedDates} onChange={(e) => this.setState({ seletedDates: e.value })} selectionMode="range" readOnlyInput />
          </div>
          <div className="p-field p-col-12 p-md-4 button-adjust">
            <Button onClick={this.notifyToAdmin} label="Notify to Admin" />
          </div>
        </div>
        <Divider />
        <HFNCalendar ref={this.calendarRef} options={this.state.options} />
        {this.state.loading ? <HFNLoading /> : null}
      </div>
    )
  }
}

export default TrainerAvailability;

