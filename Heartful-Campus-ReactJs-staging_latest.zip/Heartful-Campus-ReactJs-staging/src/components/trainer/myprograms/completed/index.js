import React, { Component } from 'react'

import { withRouter } from 'react-router';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// utils
import { sessionDateBadge, createdDateBadge, gotoPage } from "utils/badgeTemplate";

import { dropdown } from 'utils/dropdown';

import { getUserRole } from "utils/common";

// services
import TrainerService from "services/trainer/trainer.service";

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class Completed extends Component {

  constructor(props) {

    super(props);

    this.trainerService = new TrainerService();

    localStorage.setItem('moduleName', 'completed');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['completed'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      options: {

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getTrainerPrograms',

        params: {
          event_status: "COMPLETED"
        },

        urlPath: props.trainerID,

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'modules.module_name',
            filterField : "module_id",
            filter: true,
            sortField: "SortingDisabled",
            filterElementOptions: {
              type: 'Dropdown',
              value: "moduleList",
              primeFieldProps: {
                className: "p-inputtext-sm",
                filter: true,
              }
            },
            headerStyle: {
              width: '200px'
            },
            body: (rowData, { field }) => { return gotoPage(rowData, field, this.viewParticipants) }
          },
          {
            header: 'Program',
            field: 'cart_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'College',
            field: 'college_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Start Date',
            field: 'event_start_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'End Date',
            field: 'event_end_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '150px'
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            type: 'view',
            icon: "pi pi-eye view-icon",
            className: "p-ml-2 p-mr-2 p-button-icon-only manageParticipant",
            title: 'Manage Participants',
            onClick: this.viewParticipants
          },
          {
            visibility: false
          }
        ],

        toolBarBtnOptions: {
          title: '',
          selection: {
            enableBulkEdit: false,
            enableReport: true,
            reportBtnsOptions: {
              fileName: "Completed_Programs_Report",
              timestampSuffix: "DDMMYYYY",
              headers: [
                {
                  label: "Session",
                  key: "session"
                },
                {
                  label: "Program",
                  key: "program"
                },
                {
                  label: "College",
                  key: "college"
                },
                {
                  label: "Start",
                  key: "start"
                },
                {
                  label: "End",
                  key: "end"
                },
              ],
              generateReportData: selections => {
                return selections.map(selection => {
                  return {
                    session: (selection.modules && selection.modules.module_name) ? selection.modules.module_name : "",
                    program: selection.cart_name,
                    college: selection.college_name,
                    start: selection.event_start_date,
                    end: selection.event_end_date,
                  }
                })
              }
            }
          },
          rightBtnsOptions: [
            { visibility: false }
          ]
        },
        enableSelection: true,

      },
    }
  }

  viewParticipants = (ev, rowData) => {
    let sessionID = rowData.session_id;
    if (sessionID)
      this.props.history.push(`/myprograms/${sessionID}/participant`);
  }

  componentDidMount(){
    setTimeout(() => {
      tourGuideSteps(this.props,this.state.joyDetails);
    }, 1000);
    dropdown.moduleList();
  }

  render() {
    return (
      <div>
        <HFNDataTable options={this.state.options} />
      </div>
    )
  }
}

export default withRouter(Completed);
