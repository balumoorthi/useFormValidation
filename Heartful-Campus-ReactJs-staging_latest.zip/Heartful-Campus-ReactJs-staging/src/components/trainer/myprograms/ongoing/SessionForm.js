import React, { useState } from "react";

// utils 
import { validations } from 'utils/validations';

import { isEmpty } from 'lodash';

import { response } from "utils/response";

import { getUserName } from "utils/common";

// components 

// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// services 
import TrainerService from "services/trainer/trainer.service";

const SessionForm = props => {

  // props destructure start
  const { initialValue, dataTableRef } = props;
  const { initValue } = initialValue;
  // props destructure end

  // variable init start 
  const trainerService = new TrainerService()
  // variable init end

  // state management start

  // validations start
  const [sessionFormFields] = useState({
    comments: {
      properties: {
        type: 'InputText',
        label: 'Comments',
        fieldWrapperClassNames: 'p-col-12',
        primeFieldProps: {

        },
        validations: {
          required: validations.required,
        },
      }
    }
  });
  // validations end

  // state management end  

  const sessionFormOnsubmit = (data, error) => {
    let formData = { ...initValue, ...data }
    if (isEmpty(error)) {
      createChangeRequest(formData)
    }
  }

  const createChangeRequest = async (data) => {
    data.created_by = getUserName();
    await response.add({
      service: trainerService,
      method: 'createChangeRequest',
      data: { item: data },
      dataTable: dataTableRef,
      toasterMessage: {
        success: "Successfully created Change Request",
        error: "Unable to create Change Request"
      }
    })
  }

  return (
    <div>
      <HFNDynamicForm initialValues={initValue} fields={sessionFormFields} onFormSubmit={sessionFormOnsubmit} />
    </div>
  );
}

export default SessionForm;