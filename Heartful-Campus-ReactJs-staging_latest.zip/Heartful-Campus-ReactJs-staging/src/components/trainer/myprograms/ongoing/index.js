import React, { Component } from 'react';

// utils
import { modalPopup } from "utils/modalPopup";

import { moduleBadge, sessionDateBadge, createdDateBadge } from "utils/badgeTemplate";

import { dropdown } from 'utils/dropdown';

import { getUserRole } from "utils/common";

// components
import SessionForm from 'components/trainer/myprograms/ongoing/SessionForm';

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

import HFNModalPopup from 'shared-components/modalPopup';

// services
import TrainerService from "services/trainer/trainer.service";

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class OnGoing extends Component {

  constructor(props) {

    super(props);

    // variable init starts
    this.trainerService = new TrainerService();

    this.sessionTable = React.createRef(null);

    localStorage.setItem('moduleName', 'upcoming');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['upcoming'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },

      sessionForm: {
        initValue: {},
      },
      // variable init end

      options: {

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getTrainerPrograms',

        params: {
          event_status: "ONGOING"
        },

        urlPath: props.trainerID,

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'module_name',
            filterField: "module_id",
            sortField: "SortingDisabled",
            filter: true,
            filterElementOptions: {
              type: 'Dropdown',
              value: "moduleList",
              primeFieldProps: {
                className: "p-inputtext-sm",
                filter: true,
              }
            },
            headerStyle: {
              width: '200px'
            },
            body: moduleBadge
          },
          {
            header: 'Program',
            field: 'cart_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'College',
            field: 'college_name',
            filter: true,
            sortable: true,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Start Date',
            field: 'event_start_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'End Date',
            field: 'event_end_date',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
            },
            headerStyle: {
              width: '180px'
            },
            body: sessionDateBadge,
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: true,
            filterElementOptions: {
              type: 'Calendar',
              primeFieldProps: {
                maxDate: new Date()
              },
            },
            headerStyle: {
              width: '150px'
            },
            body: createdDateBadge,
          },
        ],

        actionBtnOptions: [
          {
            icon: "pi pi-calendar-minus edit-icon",
            className: "p-mr-2 changeReq",
            title: 'Request to change',
            visibilityCheck: rowData => rowData.change_request_flag !== true,
            onClick: this.editSessionAssignment
          },
          {
            visibility: false
          }
        ],

        toolBarBtnOptions: {
          title: '',
          selection: {
            enableBulkEdit: false,
            enableReport: true,
            reportBtnsOptions: {
              fileName: "Upcoming_Programs_Report",
              timestampSuffix: "DDMMYYYY",
              headers: [
                {
                  label: "Session",
                  key: "session"
                },
                {
                  label: "Program",
                  key: "program"
                },
                {
                  label: "College",
                  key: "college"
                },
                {
                  label: "Start",
                  key: "start"
                },
                {
                  label: "End",
                  key: "end"
                },
              ],
              generateReportData: selections => {
                return selections.map(selection => {
                  return {
                    session: (selection.modules && selection.modules.module_name) ? selection.modules.module_name : "",
                    program: selection.cart_name,
                    college: selection.college_name,
                    start: selection.event_start_date,
                    end: selection.event_end_date,
                  }
                })
              }
            }
          },
          rightBtnsOptions: [
            { visibility: false }
          ]
        },
        enableSelection: true,

      },
    }
  }

  editSessionAssignment = (ev, rowData) => {
    this.setState({
      sessionForm: {
        initValue: {
          program_id: (rowData.cart_modules && rowData.cart_modules.cart_id) ? rowData.cart_modules.cart_id : rowData.cart_id,
          session_id: rowData.session_id,
          college_id: rowData.college_id,
          user_info_id: rowData.user_info_id,
          comments: ""
        }
      },
    },
      () => {
        this.props.setTrainerEdit(false);
        modalPopup.toggle(true);
        modalPopup.custom({
          header: 'Change Request',
          className: "sdm-popup",
          onHide: () => {
            modalPopup.toggle(false);
            this.props.setTrainerEdit(true);
          }
        });
      })
  }

  componentDidMount() {
    tourGuideSteps(this.props,this.state.joyDetails);
    dropdown.moduleList();
  }

  render() {
    return (
      <div>
        <HFNDataTable ref={this.sessionTable} options={this.state.options} />
        {
          !this.props.trainerEdit
            ?
            <HFNModalPopup>
              <SessionForm initialValue={this.state.sessionForm} dataTableRef={this.sessionTable} />
            </HFNModalPopup>
            :
            null
        }
      </div>
    )
  }
}

export default OnGoing;
