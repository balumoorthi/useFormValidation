import React, { Component } from 'react';

import { Switch, Route } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import Participant from 'components/trainer/participant';

import MyPrograms from 'components/trainer/myprograms/MyPrograms';

// shared components 
import HFNLoader from 'shared-components/lazyLoading';

class Trainer extends Component {
  render() {
    return (
      <div>
        <HFNLoader>
          <Switch>
            <AuthGuard path='/myprograms/:sessionID/participant' component={Participant} />
            <Route>
              {
                this.props.location.pathname === "/myprograms"
                  ?
                  <MyPrograms />
                  :
                  <></>
              }
            </Route>
          </Switch>
        </HFNLoader>
      </div>
    );
  }
}

export default Trainer;