import React, { Component } from 'react'

// shared components 
import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// utils
import { crStatusBadge, createdDateBadge } from "utils/badgeTemplate";

import { confirmDialog } from "utils/confirmDialog";

import { response } from "utils/response";

// services
import TrainerService from "services/trainer/trainer.service";

class ChangeRequest extends Component {

  constructor(props) {

    super(props);

    this.trainerService = new TrainerService();

    this.trainerChangeRequestTable = React.createRef(null);

    this.state = {

      options: {

        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
        },

        url: this.trainerService,

        method: 'getChangeRequests',

        params: {
          user_info_id: props.trainerID
        },

        lazyParams: {
          sortField: "created_at",
          sortOrder: -1
        },

        columns: [
          {
            header: 'Session',
            field: 'session_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Program',
            field: 'program_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'College',
            field: 'college_name',
            sortField: "SortingDisabled",
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Comments',
            field: 'comments',
            sortable: true,
            filter: false,
            headerStyle: {
              width: '200px'
            },
          },
          {
            header: 'Status',
            field: 'status_id',
            sortable: true,
            filter: false,
            headerStyle: {
              width: '150px'
            },
            body: crStatusBadge
          },
          {
            header: 'Created On',
            field: 'created_at',
            sortable: true,
            filter: false,
            headerStyle: {
              width: '150px'
            },
            body: createdDateBadge,
          },
        ],
        actionBtnOptions: [
          {
            type: 'update',
            icon: "uil uil-pen edit-icon",
            className: "p-mr-2",
            title: 'Withdraw Change Request',
            visibilityCheck: rowData => (rowData.status_id === 1),
            onClick: (ev, rowdata) => {
              confirmDialog.toggle(true);
              confirmDialog.custom({
                message: "Are you sure you want to revert change request ?",
                accept: () => { this.revertChangeRequest({ request_id: rowdata.request_id }) }
              });
            }
          },
          {
            visibility: false
          }
        ],

        toolBarBtnOptions: {
          title: '',
          rightBtnsOptions: [
            { visibility: false }
          ]
        }

      },
    }
  }
  // Revert change request starts
  revertChangeRequest = async (id) => {
    try {
      await response.update({
        service: this.trainerService,
        method: 'revertChangeRequest',
        data: { itemId: id },
        dataTable: this.trainerChangeRequestTable,
        toasterMessage: {
          success: 'Withdraw Request Updated successfully',
          error: 'Request Not Updated Successfully'
        }
      })
    }
    catch {
      console.log("Something went wrong.");
    }
  }
  // Revert change request end

  render() {
    return (
      <div>
        <HFNDataTable ref={this.trainerChangeRequestTable} options={this.state.options} />
      </div>
    )
  }
}

export default ChangeRequest;