import React, { useState } from "react";

// components
// shared components 
import HFNDynamicForm from "shared-components/hfn-form/index";

// utils 
import { isEmpty } from "lodash";

import { validations } from "utils/validations";

import { response } from "utils/response";

import { cityAutoCompleteTemplate, getUserName } from "utils/common";

import { modalPopup } from "utils/modalPopup";

// services 
import TrainerService from "services/trainer/trainer.service";

const TrainerForm = ({ initialValue, refreshTrainer }) => {
  // variable init start 
  const trainerService = new TrainerService();
  // variable init end

  // state management start
  const [initValue] = useState({
    user_id: initialValue.user_id,
    name: initialValue.name,
    email_address: initialValue.email_address,
    contact_number: initialValue.contact_number,
    address: initialValue.address,
    city: initialValue.city,
    state: initialValue.state,
    country_id: initialValue.country_id,
    pincode: initialValue.pincode,
    zone_id: initialValue.zone_id,
    salutation: initialValue.trainer.salutation,
    center: initialValue.trainer.center,
    batch: (initialValue.trainer.batch && initialValue.trainer.batch.batch_id) ? initialValue.trainer.batch.batch_id : null,
    profession: initialValue.trainer.profession,
    education: initialValue.trainer.education,
    first_language: Array.isArray(initialValue.trainer.language)
      ?
      initialValue.trainer.language.map(language => language.language_id)
      :
      ((initialValue.trainer.language && initialValue.trainer.language.language_id) ? [initialValue.trainer.language.language_id] : []),
    age_group: initialValue.trainer.age_group,
    exp_remarks: initialValue.trainer.exp_remarks,
    motivation_remarks: initialValue.trainer.motivation_remarks
  });

  const [formConfig] = useState({
    formClassName: "register-form-wrapper",
    formSectionClassName: "register-form-section"
  });

  const [formFields] = useState({

    salutation: {
      properties: {
        type: "Dropdown",
        label: "Salutation",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {
          options: [
            {
              label: "Mr",
              value: "Mr"
            },
            {
              label: "Mrs",
              value: "Mrs"
            },
            {
              label: "Miss",
              value: "Miss"
            }
          ]
        },
        validations: {
          required: validations.required
        }
      }
    },
    name: {
      properties: {
        type: "InputText",
        label: "Name",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required,
          pattern: validations.userName,
          maxLength: {
            value: 120,
            message: "Please enter name with maximum 120 characters"
          }
        }
      }
    },
    email_address: {
      properties: {
        type: "InputText",
        label: "Email",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {
          readOnly: true
        },
        validations: {
          required: validations.required,
          pattern: validations.email,
          maxLength: {
            value: 180,
            message: "Please enter email address with maximum 180 characters"
          }
        }
      }
    },

    contact_number: {
      properties: {
        type: "PhoneInput",
        label: "Phone No",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required
        }
      }
    },
    address: {
      properties: {
        type: "InputText",
        label: "Address",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {}
      }
    },
    city: {
      properties: {
        type: "CityAutoComplete",
        label: "City",
        fieldWrapperClassNames: "p-md-6",
        searchField: "name",
        fieldLabel: "name",
        primeFieldProps: {
          itemTemplate: cityAutoCompleteTemplate
        },
        validations: {
          required: validations.required,
          minLength: {
            value: 3,
            message: "Search value must be minimum 3 character..."
          }
        },
        stateField: {
          label: "State",
          fieldName: "state",
          fieldWrapperClassNames: "p-md-6",
          primeFieldProps: {
            readOnly: true
          },
          validations: {
            required: validations.required
          }
        },
        countryField: {
          label: "Country",
          fieldName: "country_id",
          fieldWrapperClassNames: "p-md-6",
          primeFieldProps: {
            disabled: true
          },
          validations: {
            required: validations.required
          },
          dropdownOptions: "country"
        }
      },
    },

    pincode: {
      properties: {
        type: "InputText",
        label: "Pincode",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required,
          maxLength: {
            value: 10,
            message: "Please enter pincode with maximum 10 characters"
          }
        }
      }
    },
    zone_id: {
      properties: {
        type: "SelectDropdown",
        label: "Zone",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {
          isSearchable: true
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "zone"
      }
    },
    center: {
      properties: {
        type: "InputText",
        label: "Center",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required
        }
      }
    },
    first_language: {
      properties: {
        type: "MultiSelect",
        label: "Language",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {
          filter: true,
          showClear: true
        },
        validations: {
          required: validations.required
        },
        dropdownOptions: "language"
      }
    },
    education: {
      properties: {
        type: "InputText",
        label: "Education",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required
        }
      }
    },
    batch: {
      properties: {
        type: "Dropdown",
        label: "Batch",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required
        },
        dropdownOptions: "batch"
      }
    },
    profession: {
      properties: {
        type: "InputText",
        label: "Profession",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required
        }
      }
    },
    age_group: {
      properties: {
        type: "Dropdown",
        label: "Age Group",
        fieldWrapperClassNames: "p-col-6",
        primeFieldProps: {},
        validations: {
          required: validations.required
        },
        dropdownOptions: "ageGroup"
      },
    },
    exp_remarks: {
      properties: {
        type: "InputTextarea",
        label: "Experience Remarks",
        primeFieldProps: {}
      }
    },
    motivation_remarks: {
      properties: {
        type: "InputTextarea",
        label: "Public Speaker Profile",
        primeFieldProps: {}
      }
    }
  });
  // state management end

  // form submit section start
  const formOnSubmit = (data, error) => {
    if (isEmpty(error)) {
      let formData = { ...initValue, ...data };
      formData = getUserName(true, formData);
      updateTrainer(formData);
    }
  }

  // update trainer section start
  const updateTrainer = async (data) => {
    let apiResponse = await response.update({
      service: trainerService,
      method: "updateTrainer",
      data: { itemId: initValue.user_id, item: data },
      modalPopupHide: false,
      toasterMessage: {
        success: "Trainer updated successfully",
        error: "Trainer not updated"
      }
    });

    if (apiResponse && apiResponse.data && !apiResponse.data.isError) {
      refreshTrainer();
      modalPopup.toggle(false);
    }
  }
  // update trainer section end
  // form submit section end

  return (
    <div className="login-section register-section">
      <div className="card-wrapper">
        <div className="register">
          <HFNDynamicForm initialValues={initValue} fields={formFields} onFormSubmit={formOnSubmit} formConfig={formConfig} />
        </div>
      </div>
    </div>
  )
}

export default TrainerForm;
