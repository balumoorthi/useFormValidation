import React, { Component } from 'react';

import { withRouter } from 'react-router';
// state 
import { connect } from "react-redux";

// components
import OnGoing from 'components/trainer/myprograms/ongoing';

import Completed from 'components/trainer/myprograms/completed';

import Calendar from 'components/trainer/program/calendar';

import ChangeRequest from 'components/trainer/myprograms/changeRequest';

import TrainerForm from 'components/trainer/myprograms/TrainerForm';

// prime components
import { Accordion, AccordionTab } from 'primereact/accordion';

import { TabView, TabPanel } from 'primereact/tabview';

import { Button } from 'primereact/button';

// shared components
import HFNModalPopup from 'shared-components/modalPopup';

// utils
import { getUserID, getUserRole } from "utils/common";

import buildBreadcrumb from "utils/breadcrumb";

import { isObject, isString, toUpper } from "lodash";

import { toaster } from "utils/toaster";

import { response } from "utils/response";

import { dropdown } from 'utils/dropdown';

import { modalPopup } from "utils/modalPopup";

// services
import TrainerService from "services/trainer/trainer.service";

import StepsInnerPage from 'shared-components/tourGuide/StepsInnerPage';

import tourGuideSteps from 'utils/tourGuideSteps';

class TrainerDetails extends Component {

  constructor(props) {

    super(props);

    this.trainerService = new TrainerService();

    localStorage.setItem('moduleName', 'upcoming');

    this.state = {

      joyDetails: { 
        run: true,
        steps: StepsInnerPage[getUserRole()]['upcoming'],
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      },
      
      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
        { label: "My Programs", url: "myprograms", },
      ],

      trainerInfo: null,

      trainerID: getUserID(),

      trainerEdit: false
    }
  }

  getTrainerDetail = async () => {
    const errorMessage = "Unable to fetch trainer details";
    try {
      const apiResponse = await response.get(
        {
          service: this.trainerService,
          method: 'getTrainer',
          data: { itemId: this.state.trainerID }
        });

      if (apiResponse && apiResponse.data) {
        const apiResponseData = apiResponse.data;

        if (!apiResponseData.isError) {

          if (isObject(apiResponseData.data)) {
            let trainerInfo = apiResponseData.data;
            const trainer = trainerInfo.trainer;

            if (trainer) {
              if (Array.isArray(trainer.language)) {
                trainerInfo.language = trainer.language.reduce((languages, language) => {
                  if (languages)
                    return languages + ", " + (language.language_name ? language.language_name : "-");
                  else
                    return language.language_name || "-";
                }, "");
              }
              else if (trainer.language && trainer.language.language_name) {
                trainerInfo.language = trainer.language.language_name;
              }
            }

            this.setState({ trainerInfo: trainerInfo });
          }
        }
        else {
          toaster.error(apiResponseData.message || errorMessage)
        }
      }
    }
    catch (err) {
      toaster.error(errorMessage)
    }

  }

  setTrainerEdit = toggle => {
    this.setState({ trainerEdit: toggle });
  }

  gotoNotifyCalendarPage = () => {
    this.props.history.push('/notify-unavailability');
  }

  componentDidMount = () => {
    tourGuideSteps(this.props,this.state.joyDetails);
    buildBreadcrumb(null, this.state.breadcrumbs);
    this.getTrainerDetail();
    dropdown.generalStatus();
    dropdown.country();
    dropdown.zone();
    dropdown.ageGroup();
    dropdown.language();
    dropdown.batch();
  }

  render() {
    // state and props destructure start
    const trainerInfo = this.state.trainerInfo || {};
    const trainer = (trainerInfo && trainerInfo.trainer) ? trainerInfo.trainer : {};
    const zone = this.props.zones.find(value => value.value === trainerInfo.zone_id);
    // state and props destructure end

    return (
      <>
        <div className='tab-section'>
          <div className="college-create-program">
            <Button
              className="p-button p-button-primary notifyUnavailable"
              label="Notify Unavailability"
              onClick={()=>{ this.gotoNotifyCalendarPage()} }
            />
          </div>
          <TabView>
            <TabPanel header="Upcoming Programs">
              <OnGoing trainerID={this.state.trainerID} trainerEdit={this.state.trainerEdit} setTrainerEdit={this.setTrainerEdit} />
            </TabPanel>
            <TabPanel header="Completed Programs">
              <Completed trainerID={this.state.trainerID} />
            </TabPanel>
            <TabPanel header="Calendar View">
              <Calendar trainerID={this.state.trainerID} />
            </TabPanel>
            <TabPanel header="Change Requests">
              <ChangeRequest trainerID={this.state.trainerID} />
            </TabPanel>
          </TabView>
        </div>

        {
          this.state.trainerEdit
            ?
            <HFNModalPopup>
              <TrainerForm initialValue={this.state.trainerInfo} refreshTrainer={this.getTrainerDetail} />
            </HFNModalPopup>
            :
            null
        }

        <div className='p-card'>

          <div className="p-card-body">
            <Accordion activeIndex={0} >
              <AccordionTab
                header={<>
                  <div className="p-mr-1 p-mb-1 p-text-center">My Profile</div>
                  {
                    this.state.trainerInfo
                      ?
                      <Button type="button" label="Edit Profile" className="p-button p-button-primary p-mr-2 p-mb-1 p-px-3" onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        this.setTrainerEdit(true);
                        modalPopup.toggle(true);
                        modalPopup.custom({
                          header: "Update Profile",
                          className: "trainer-form-popup",
                          blockScroll: true,
                          onHide: () => {
                            modalPopup.toggle(false);
                            this.setTrainerEdit(false);
                          }
                        });
                      }} />
                      :
                      null
                  }
                </>}
                headerClassName="trainer-myprofile-section-header"
              >
                <div className="p-d-flex p-flex-wrap">
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Name</b>
                    </p>
                    <div>{trainerInfo.name || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Email</b>
                    </p>
                    <div>{trainerInfo.email_address || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Phone No</b>
                    </p>
                    <div>{trainerInfo.contact_number || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Address</b>
                    </p>
                    <div>{trainerInfo.address || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>City</b>
                    </p>
                    <div>{trainerInfo.city || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>State</b>
                    </p>
                    <div>{trainerInfo.state ? toUpper(trainerInfo.state) : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Zone</b>
                    </p>
                    <div>{(zone && zone.label) ? zone.label : '-'}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Country</b>
                    </p>
                    <div>{(trainerInfo.country && trainerInfo.country.country_name) ? trainerInfo.country.country_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Pincode</b>
                    </p>
                    <div>{trainerInfo.pincode || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Status</b>
                    </p>
                    <div>{(trainerInfo.status && trainerInfo.status.status_name) ? trainerInfo.status.status_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Center</b>
                    </p>
                    <div>{(trainer.center && isString(trainer.center)) ? trainer.center : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Batch</b>
                    </p>
                    <div>{(trainer.batch && trainer.batch.batch_name) ? trainer.batch.batch_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Profession</b>
                    </p>
                    <div>{(trainer.profession && isString(trainer.profession)) ? trainer.profession : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Education</b>
                    </p>
                    <div>{(trainer.education && isString(trainer.education)) ? trainer.education : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Language</b>
                    </p>
                    <div>{trainerInfo.language || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Age Group</b>
                    </p>
                    <div>{(trainer.agegroup && trainer.agegroup.age_group_name) ? trainer.agegroup.age_group_name : "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Experience Remarks</b>
                    </p>
                    <div>{trainer.exp_remarks || "-"}</div>
                  </div>
                  <div className="p-col-12 p-md-4 p-mb-3">
                    <p className="p-mb-2">
                      <b>Public Speaker Profile</b>
                    </p>
                    <div>{trainer.motivation_remarks || "-"}</div>
                  </div>
                </div>
              </AccordionTab>
            </Accordion>

          </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = (state) => ({
  zones: state.dropdownDetails.zone,
});

export default withRouter(connect(mapStateToProps)(TrainerDetails));

