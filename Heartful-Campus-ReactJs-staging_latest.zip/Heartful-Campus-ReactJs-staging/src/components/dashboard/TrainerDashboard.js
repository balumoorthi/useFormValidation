import React, { Component } from 'react'

//import HFNStatsCard from 'shared-components/card/index';

import HFNChart from 'shared-components/charts/index'

//services
import TrainerDashboardService from 'services/trainerDashboard/trainerDashBoard.service'

import { connect } from 'react-redux';

//utils
import buildBreadcrumb from "utils/breadcrumb";

import { lStorage } from 'utils/storage';

//shared components
import HFNLoading from 'shared-components/lazyLoading/Loading';

import randomColor from 'randomcolor';

export class TrainerDashboard extends Component {

  constructor(props) {

    super(props);
    this.trainerDashboardService = new TrainerDashboardService();
    this.state = {
      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
      ],
      columns: [{
        title: "first",
        label: "First Data",
        count: "1",
        className: "p-col-3",
        titleColor: "#4e73df"
      },
      {
        title: "second",
        label: "second Data",
        count: "2",
        className: "p-col-3",
        titleColor: "#1cc88a"
      },
      {
        title: "Third",
        label: "Third Data",
        count: "3",
        className: "p-col-3",
        titleColor: "#36b9cc"
      },
      {
        title: "Fourth",
        label: "Fourth Data",
        count: "4",
        className: "p-col-3",
        titleColor: "#f6c23e"
      }
      ],
      userStatics: {

        type: 'Doughnut',

        service: this.trainerDashboardService,

        method: "getTrainerData",

        chartOptions: {

          data: {

          },

          options: {

          }
        }
      },
      doughnutChart: {
        labels: [],
        datasets: [
          {
            data: [],
            backgroundColor: [],
            borderColor: [],
            borderWidth: 1,
          },
        ],
      },
      trainerData: {
        labels: ['Active', 'Inactive'],
        datasets: [
          {
            data: [12, 19],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
          },
        ],
      },
      dataState: {
        labels: ['Chennai', 'Andhra Pradesh', 'Kerala', 'Telangana', 'Maharastra', 'Karnataka'],
        datasets: [
          {
            label: 'no of Ongoing',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: 'rgb(255, 99, 132)',
          },
          {
            label: 'no of Idle',
            data: [3, 10, 13, 15, 22, 30],
            backgroundColor: 'rgb(75, 192, 192)',
          },
        ],
      },
      optionsState: {
        scales: {
          yAxes: [
            {
              stacked: true,
              ticks: {
                beginAtZero: true,
              },
            },
          ],
          xAxes: [
            {
              stacked: true,
            },
          ],
        },
      }
    }
    this.data = {
      labels: ['Chennai', 'Bangalore', 'Hyderabad', 'Karnataka', 'Vellore', 'Coimbatore'],
      datasets: [
        {
          label: '# of Trainers',
          data: [12, 19, 3, 5, 2, 3],
          fill: false,
          backgroundColor: 'rgb(255, 99, 132)',
          borderColor: 'rgba(255, 99, 132, 0.2)',
        },
      ],
    };

    this.options = {
      scales: {
        yAxes: [
          {
            ticks: {
              beginAtZero: true,
            },
          },
        ],
      },
    };

  }
  trainerDetails = async () => {
    this.setState({
      loading: true
    })
    let userDetails;
    userDetails = lStorage.get('authInfo')
    try {
      const apiResponse = await this.trainerDashboardService.getTrainerData(userDetails.id);

      if (apiResponse && apiResponse.data.data.length !== 0) {
        const trainerData = apiResponse.data.data;
        let data, backgroundColors, borderColors;
        data = trainerData.count;
        backgroundColors = data.map(() => { return randomColor({ luminosity: 'light' }) });
        borderColors = backgroundColors.map(color => { return randomColor({ luminosity: 'dark', hue: color }) })

        var doughnutChart = { ...this.state.doughnutChart }
        doughnutChart.labels = trainerData.eventstatus;
        doughnutChart.datasets[0].data = trainerData.count;
        doughnutChart.datasets[0].backgroundColor = backgroundColors;
        doughnutChart.datasets[0].borderColor = borderColors;
        this.setState({ doughnutChart, loading: false })
      } else {
        this.setState({
          loading: false
        })
      }
    } catch (err) {
      console.log(err)
    }



  }

  async componentDidMount() {
    await this.trainerDetails()
    buildBreadcrumb(this.props, this.state.breadcrumbs);
  }
  render() {
    return (

      <div >
        <br />
        {this.state.loading === true ? <HFNLoading /> : <>
          {/* <div className="p-grid p-jc-between">
          {this.state.columns.map((item, index) => {
            return <HFNStatsCard key={index} { ...item } />
          })}
        </div>
        <br /> */}
          <div >
            {/* <div className="p-col-8">
            <div >
              <h5>Number of Trainers</h5>
              <div className="card p-d-flex p-jc-center">
                <HFNChart data={this.data} options={this.options} type="line" />
              </div>
            </div>
          </div> */}
            <div>
              <div>
                {this.state.doughnutChart.labels.length !== 0 ? <div className="card p-d-flex p-jc-center" style={{
                  width: '700px',
                  height: '700px',
                  margin: '0 0 0 183px'
                }}>
                  <HFNChart doughdata={this.state.doughnutChart}
                    option={this.state.userStatics}
                    type="Doughnut" />
                </div> : <h3>No data found</h3>}
              </div>
            </div>
            {/* <div className="p-col-6">
            <div>
              <h5>Trainer</h5>
              <div className="card p-d-flex p-jc-center">
                <HFNChart trainerData={this.state.trainerData} type="Pie" />
              </div>
            </div>
          </div>
          <div className="p-col-6">
            <div>
              <h5>Activity</h5>
              <div className="card p-d-flex p-jc-center">
                <HFNChart barData={this.state.dataState} baroptions={this.state.optionsState} type="Bar" />
              </div>
            </div>
          </div> */}
          </div></>}
      </div>
    )
  }

}
const mapStateToProps = (state) => ({
  ld: state.loginDetails
});

export default connect(mapStateToProps)(TrainerDashboard);
