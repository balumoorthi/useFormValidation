import React, { Component } from 'react';

// components
// shared components
import HFNLoading from 'shared-components/lazyLoading/Loading';

import HFNCard from 'shared-components/card';

import HFNChart from 'shared-components/charts';

import HFNDataTable from 'shared-components/datatable/HFNDataTable';

// utils 
import randomColor from 'randomcolor';

import buildBreadcrumb from "utils/breadcrumb";

// prime components
import { Button } from 'primereact/button';

// services
import DashboardService from 'services/dashboard/dashboard.service';

import { jsPDF } from "jspdf";

import * as html2canvas from 'html2canvas';

// constants
const initValue = {
  cardCounts: [0, 0, 0, 0, 0],

  barChartOptions: {
    scales: {
      xAxes: {
        stacked: true,
      },
      yAxes: {
        stacked: true,
        ticks: {
          beginAtZero: true,
          min: 0,
          callback: function (value, index, ticks) {
            return ((value / ticks[ticks.length - 1].value) * 100).toFixed(0) + '%';
          }
        }
      }
    }
  },

  barChartData: {
    labels: [],
    datasets: [
      {
        label: 'In Active',
        data: [],
        backgroundColor: '#ac40bf',
      },
      {
        label: 'Active',
        data: [],
        backgroundColor: '#98fb98',
      },
    ],
  },

  doughnutChartOptions: {
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  },

  doughnutChartData: {
    labels: [],
    datasets: [
      {
        // label: 'Event Type',
        label: 'Program Type',
        data: [],
        backgroundColor: [],
        borderColor: [],
        borderWidth: 1
      }
    ]
  },

  linearChartOptions: {
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          }
        }
      ]
    },
    plugins: {
      legend: {
        display: false
      }
    }
  },

  linearChartData: {
    labels: [],
    datasets: [
      {
        label: 'Record count',
        data: [],
        fill: false,
        backgroundColor: '#f6c23e',
        borderColor: '#f6c23e'
      }
    ]
  }
};

class MainDashboard extends Component {

  constructor(props) {

    super(props);

    // variable init start
    this.dashboardService = new DashboardService();

    this.unmounted = false;

    this.maxCenterSessions = 0;

    this.maxTrainerSessions = 0;
    // variable init end

    // state management start
    this.state = {

      breadcrumbs: [
        { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
      ],

      loading: false,

      cards: [
        {
          title: "Participants",
          titleColor: "#4e73df",
          path: ""
        },
        {
          title: "Colleges",
          titleColor: "#1cc88a",
          path: ""
        },
        {
          title: "Sessions",
          titleColor: "#36b9cc",
          path: ""
        },
        {
          title: "Trainers",
          titleColor: "#f6c23e",
          path: ""
        },
        {
          title: "MOU Signed",
          titleColor: "#4100ff8c",
          path: ""
        }
      ],

      cardCounts: initValue.cardCounts,

      barChartOptions: initValue.barChartOptions,

      barChartData: initValue.barChartData,

      doughnutChartOptions: initValue.doughnutChartOptions,

      doughnutChartData: initValue.doughnutChartData,

      centerSessionsTableOptions: {
        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
          emptyMessage: 'No data found'
        },
        url: this.dashboardService,
        method: 'getCenterSessions',
        params: {
          board: "center"
        },
        lazyParams: {
          sortField: "sessions",
          sortOrder: -1
        },
        columns: [
          {
            header: 'City',
            field: 'city',
            sortable: true,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Sessions',
            field: 'sessions',
            sortable: true,
            headerStyle: {
              width: '120px'
            },
            body: this.centerSessionsTemplate
          }
        ],
        pagination: {
          currentPageReport: {
            isPageResult: false,
            shortResult: true
          },
          rowsPerPageDropdown: {
            isRowPerPage: false
          }
        },
        enableActionColumn: false,
        toolBarBtnOptions: {
          title: '',
          rightBtnsOptions: [{ visibility: false }]
        }
      },

      trainerSessionsTableOptions: {
        tablePrimeConfig: {
          autoLayout: true,
          lazy: true,
          scrollable: true,
          scrollHeight: "500px",
          emptyMessage: 'No data found'
        },
        url: this.dashboardService,
        method: 'getTrainerSessions',
        params: {
          board: "trainer"
        },
        lazyParams: {
          sortField: "sessions",
          sortOrder: -1
        },
        columns: [
          {
            header: 'Trainer',
            field: 'name',
            sortable: true,
            headerStyle: {
              width: '150px'
            }
          },
          {
            header: 'Sessions',
            field: 'sessions',
            sortable: true,
            headerStyle: {
              width: '120px'
            },
            body: this.trainerSessionsTemplate
          }
        ],
        pagination: {
          currentPageReport: {
            isPageResult: false,
            shortResult: true
          },
          rowsPerPageDropdown: {
            isRowPerPage: false
          }
        },
        enableActionColumn: false,
        toolBarBtnOptions: {
          title: '',
          rightBtnsOptions: [{ visibility: false }]
        }
      },

      linearChartOptions: initValue.linearChartOptions,

      linearChartData: initValue.linearChartData

    }
    // state management end

  }

  // dashboard data load section start
  loadData = async () => {
    let apiResponse, dashboardData, cardCounts, barChartOptions, barChartData, doughnutChartData, linearChartData;

    cardCounts = initValue.cardCounts;
    barChartOptions = initValue.barChartOptions;
    barChartData = initValue.barChartData;
    doughnutChartData = initValue.doughnutChartData;
    linearChartData = initValue.linearChartData;

    if (this.unmounted) return;
    this.setState({ loading: true });

    try {

      // cards data load section start
      if (this.unmounted) return;
      apiResponse = await this.dashboardService.getCountsOfCards();

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        dashboardData = apiResponse.data.data;

        cardCounts = [
          dashboardData.participantCount || 0,
          dashboardData.collegeCount || 0,
          dashboardData.sessionCount || 0,
          dashboardData.activeTrainers || 0,
          dashboardData.mouSignedColleges || 0,
        ];

      }
      // cards data load section end

      // college bar chart data load section start
      if (this.unmounted) return;
      apiResponse = await this.dashboardService.getCollegesPerState();

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        dashboardData = apiResponse.data.data;

        if (Array.isArray(dashboardData.labels) &&
          Array.isArray(dashboardData.inactiveCollege) &&
          Array.isArray(dashboardData.activeCollege) &&
          Number.isInteger(dashboardData.maxValue) &&
          (dashboardData.labels.length === dashboardData.inactiveCollege.length) &&
          (dashboardData.inactiveCollege.length === dashboardData.activeCollege.length)) {

          barChartOptions.scales.yAxes.ticks.max = dashboardData.maxValue;
          barChartOptions.scales.yAxes.ticks.stepSize = (dashboardData.maxValue / 4);
          barChartData.labels = dashboardData.labels;
          barChartData.datasets[0].data = dashboardData.inactiveCollege;
          barChartData.datasets[1].data = dashboardData.activeCollege;

        }
      }
      // college bar chart data load section end

      // event doughnut chart data load section start
      if (this.unmounted) return;
      apiResponse = await this.dashboardService.getEventTypes();

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        dashboardData = apiResponse.data.data;

        if (Array.isArray(dashboardData.labels) && Array.isArray(dashboardData.eventtypeData) && (dashboardData.labels.length === dashboardData.eventtypeData.length)) {

          const backgroundColors = dashboardData.eventtypeData.map(() => { return randomColor({ luminosity: 'light' }) });
          const borderColors = backgroundColors.map(color => { return randomColor({ luminosity: 'dark', hue: color }) });
          doughnutChartData.labels = dashboardData.labels;
          doughnutChartData.datasets[0].data = dashboardData.eventtypeData;
          doughnutChartData.datasets[0].backgroundColor = backgroundColors;
          doughnutChartData.datasets[0].borderColor = borderColors;

        }
      }
      // event doughnut chart data load section end

      // event linear chart data load section start
      if (this.unmounted) return;
      apiResponse = await this.dashboardService.getEventsByMonth();

      if (apiResponse && apiResponse.data && !apiResponse.data.isError && apiResponse.data.data) {
        dashboardData = apiResponse.data.data;

        if (Array.isArray(dashboardData.labels) && Array.isArray(dashboardData.totalSessions) && (dashboardData.labels.length === dashboardData.totalSessions.length)) {

          linearChartData.labels = dashboardData.labels;
          linearChartData.datasets[0].data = dashboardData.totalSessions;

        }
      }
      // event linear chart data load section end
    }
    catch {
      console.log("Something went wrong.");
    }

    if (this.unmounted) return;
    this.setState({
      cardCounts: cardCounts,
      barChartOptions: barChartOptions,
      barChartData: barChartData,
      doughnutChartData: doughnutChartData,
      linearChartData: linearChartData,
      loading: false
    });
  }
  // dashboard data load section end

  centerSessionsTemplate = (rowData, { field }) => {
    if (!this.maxCenterSessions && rowData[field])
      this.maxCenterSessions = rowData[field];
    return rowData[field]
      ?
      <div style={{ textAlign: "right", paddingRight: "4px", backgroundColor: `rgba(108, 213, 13, ${Math.max((rowData[field] / this.maxCenterSessions), 0.04)})` }}>
        {rowData[field]}
      </div>
      :
      <div style={{ textAlign: "right", backgroundColor: `rgba(108, 213, 13, 0.04)` }}> 0 </div>
  }

  trainerSessionsTemplate = (rowData, { field }) => {
    if (!this.maxTrainerSessions && rowData[field])
      this.maxTrainerSessions = rowData[field];
    return rowData[field]
      ?
      <div style={{ textAlign: "right", paddingRight: "4px", backgroundColor: `rgba(230, 34, 139, ${Math.max((rowData[field] / this.maxTrainerSessions), 0.04)})` }}>{rowData[field]}</div>
      :
      <div style={{ textAlign: "right", backgroundColor: `rgba(230, 34, 139, 0.04)` }}> 0 </div>
  }

  exportAsPdf = async () => {
    html2canvas(document.getElementById("demo"), 
      { 
        width: document.querySelector('#demo').scrollWidth,
        height: document.querySelector('#demo').scrollHeight,
        scrollX: -window.scrollX,
        scrollY: -window.scrollY,
        backgroundColor: '#f4f7ff',
        onclone: async function (doc) {
          // Change text in cloned document, which should reflect in generated PDF
          // Slowing it down to see what's going on...
          doc.querySelector('#export .p-button-primary').style.display = "none";
          doc.querySelector('#activeCityStats .p-paginator-bottom').style.display = "none";
          doc.querySelector('#activeTrainerStats .p-paginator-bottom').style.display = "none";
          
          if(doc.querySelector('#activeCityStats .pi-sort-alt'))
            doc.querySelector('#activeCityStats .pi-sort-alt').style.display = "none";
          if(doc.querySelector('#activeCityStats .pi-sort-amount-up-alt'))
            doc.querySelector('#activeCityStats .pi-sort-amount-up-alt').style.display = "none";
          
          if(doc.querySelector('#activeCityStats .pi-sort-amount-down'))
            doc.querySelector('#activeCityStats .pi-sort-amount-down').style.display = "none";

          if(doc.querySelector('#activeTrainerStats .pi-sort-alt'))
            doc.querySelector('#activeTrainerStats .pi-sort-alt').style.display = "none";
          if(doc.querySelector('#activeTrainerStats .pi-sort-amount-up-alt'))
            doc.querySelector('#activeTrainerStats .pi-sort-amount-up-alt').style.display = "none";
          
          if(doc.querySelector('#activeTrainerStats .pi-sort-amount-down'))
            doc.querySelector('#activeTrainerStats .pi-sort-amount-down').style.display = "none";
        }
      }).then((canvas) => {
        var imgWidth = 207;
        var pageHeight = 250;
        var imgHeight = canvas.height * imgWidth / canvas.width;
        var heightLeft = imgHeight;

        var doc = new jsPDF('p', 'mm', 'a4');
        var position = 0;
        var pageData = canvas.toDataURL('image/jpeg', 1.0);
        var imgData = encodeURIComponent(pageData);
        doc.addImage(imgData, 'PNG', 2.5, position, imgWidth, imgHeight);
        doc.setLineWidth(5);
        doc.setDrawColor(244, 247, 255);
        heightLeft -= pageHeight;
      
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          doc.addPage();
          doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
          doc.setLineWidth(5);
          heightLeft -= pageHeight;
        }
        doc.save( 'dashboard.pdf' );
    });
  }

  componentDidMount() {
    buildBreadcrumb(null, this.state.breadcrumbs);
    this.loadData()
  }

  componentWillUnmount() {
    this.unmounted = true;
  }

  render() {
    return (
      <>
        {this.state.loading === true ? <HFNLoading /> : <></>}
        <div className='container p-mt-2' id='demo'>
          <div className="p-d-flex p-jc-end" id='export' style={{ marginTop: "-40px" }}>
            <Button type="button" label="Export" className="p-button-primary" onClick={this.exportAsPdf} />
          </div>
          <div className="p-grid p-jc-between">
            {
              this.state.cards.map((item, index) => {
                return <div className="p-col-12 p-md-2 p-my-2" key={index}>
                  <HFNCard {...item} count={this.state.cardCounts[index] || 0} />
                </div>
              })
            }
          </div>

          <div className="p-grid p-mt-2">
            <div className="p-col-12 p-md-8">
              <div className="p-card p-p-4 ">
                <div className="p-my-2"> Colleges Per State </div>
                <div className="p-d-flex p-jc-center p-mt-3">
                  {
                    (this.state.barChartData.datasets[0].data.length > 0 || this.state.barChartData.datasets[1].data.length > 0)
                      ?
                      <HFNChart type="Bar" baroptions={this.state.barChartOptions} barData={this.state.barChartData} />
                      :
                      <div>
                        {this.state.loading === true ? "Loading..." : "No data found"}
                      </div>
                  }
                </div>
              </div>
            </div>
            <div className="p-col-12 p-md-4">
              <div className="p-card p-p-4">
                <div className="p-my-2 "> Program Type </div>
                <div className="p-d-flex p-jc-center p-mt-3">
                  {
                    this.state.doughnutChartData.datasets[0].data.length > 0
                      ?
                      <HFNChart type="Doughnut" options={this.state.doughnutChartOptions} doughdata={this.state.doughnutChartData} />
                      :
                      <div>
                        {this.state.loading === true ? "Loading..." : "No data found"}
                      </div>
                  }
                </div>
              </div>
            </div>
          </div>

          <div className="p-grid p-mt-2">
            <div className="p-col-12 p-md-4">
              <div className="p-card" id="activeCityStats">
                <div className="p-pl-4 p-pt-4"> Most Active City </div>
                <HFNDataTable options={this.state.centerSessionsTableOptions} />
              </div>
            </div>
            <div className="p-col-12 p-md-4">
              <div className="p-card" id="activeTrainerStats">
                <div className="p-pl-4 p-pt-4"> Trainer Leaderboard </div>
                <HFNDataTable options={this.state.trainerSessionsTableOptions} />
              </div>
            </div>
            <div className="p-col-12 p-md-4">
              <div className="p-card p-p-4">
                <div className="p-my-2"> Events By Month </div>
                <div className="p-d-flex p-jc-center p-mt-3">
                  {
                    this.state.linearChartData.datasets[0].data.length > 0
                      ?
                      <HFNChart type="line" options={this.state.linearChartOptions} data={this.state.linearChartData} />
                      :
                      <div>
                        {this.state.loading === true ? "Loading..." : "No data found"}
                      </div>
                  }
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default MainDashboard;
