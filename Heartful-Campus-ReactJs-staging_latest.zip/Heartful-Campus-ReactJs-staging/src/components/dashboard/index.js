import React, { Component } from 'react';

// components
import MainDashboard from 'components/dashboard/MainDashboard';

import TrainerDashboard from 'components/dashboard/TrainerDashboard';

// utils
import { getUserType, getUserRole } from 'utils/common';

import MyCollege from 'components/college/myCollege/MyCollege';

import { modalPopup } from "utils/modalPopup";

import HFNModalPopup from 'shared-components/modalPopup';

import { Button } from 'primereact/button';

import Steps from 'shared-components/tourGuide/Steps';

import tourGuideSteps from 'utils/tourGuideSteps';

import { Cookies, withCookies } from "react-cookie";
import { instanceOf } from "prop-types";


class Dashboard extends Component {
  static propTypes = {
    cookies: instanceOf(Cookies).isRequired
  };
  constructor(props) {
    super (props);
    this.state = {
      tourGuidance : this.props.cookies.get("tourGuidance"),
      tourRequired : this.props.cookies.get("tourRequired"),
      joyDetails: { 
        run: true,
        steps: this.props.location.pathname === "/dashboard" ? Steps[getUserRole()] : '',
        stepIndex: 0,
        loadSet:Math.random(),
        continuous: true,
        loading: false
      }
    }
  }

  componentDidMount() {
    if(this.state.tourRequired === '') {
      this.setState(() => {
        modalPopup.toggle(true)
        modalPopup.custom({ header: 'Tour Guidance', className: 'sdm-popup' })
      })
    }
  }
  render() {
    const { cookies } = this.props;
    return (
      <>
        {
          ((getUserType() === "U") || (getUserType() === "POC"))
            ?
            <MainDashboard />
            :
            <></>
        }
        {
          (getUserType() === "CS")
            ?
            <MyCollege />
            :
            <></>
        }
        {
          (getUserType() === "T")
            ?
            <TrainerDashboard />
            :
            <></>
        }
        {(this.state.tourRequired === '') ?
        <HFNModalPopup>
          <div className="p-d-flex p-flex-wrap p-my-3">
            <div className="p-col-12 p-d-flex p-flex-wrap p-mx-5">
              <p style={{ height: '50px' }}>Would you like to go for Tour Guidance?</p>
            </div>
            <div className="form-button-group">
            <Button 
              type="button" 
              className='p-button p-button-primary p-mr-2' 
              label="Yes" 
              onClick={() => { 
                localStorage.setItem('tourGuidance', 0);
                localStorage.setItem('tourRequired', 'yes');
                cookies.set("tourRequired", "yes", { path: "/" }); // set the cookie
                cookies.set("tourGuidance", 0, { path: "/" }); // set the cookie
                tourGuideSteps(this.props,this.state.joyDetails);
                modalPopup.toggle(false)
              }} 
            />
            <Button 
              type="button" 
              className='p-button p-button-secondary p-mr-2' 
              label="No! I am good" 
              onClick={() => { 
                localStorage.setItem('tourGuidance', 1);
                localStorage.setItem('tourRequired', 'no');
                cookies.set("tourRequired", "no", { path: "/" }); // set the cookie
                cookies.set("tourGuidance", 1, { path: "/" }); // set the cookie
                modalPopup.toggle(false) }}
            />
            </div>
          </div>
        </HFNModalPopup>
        :""}
      </>
    )
  }
}

export default withCookies(Dashboard);
