import React, { Component } from 'react';

// routes 
import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

// services 
import FaqService from 'services/faq/faq.service';

import { getUserType } from 'utils/common';

class HelpDetails extends Component {

  constructor(props) {

    super(props);

    this.faqService = new FaqService();

    this.state = {
      helpData: []
    };

  }


  helpDetailsBreadCrubms = () => {

    let participantBreadcrumbs, programID = this.props.match.params.id;

    const breadCrumb = [
      { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
      { label: "Help", url: "help" },
      { label: this.state.helpData.page_title, url: `help/details/${programID}` },
    ]

    if (getUserType() === "CS") {
      breadCrumb.shift()
    }
    participantBreadcrumbs = breadCrumb;

    buildBreadcrumb(this.props, participantBreadcrumbs);

  }

  loadStaffFaq = async () => {
    try {
      const apiResponse = await this.faqService.getHelpDetails(parseInt(this.props.match.params.id));

      if (apiResponse && apiResponse.data) {
        const helpData = apiResponse.data.data;
        this.setState({
          helpData: helpData
        })
      }

      this.helpDetailsBreadCrubms();
    } catch (err) {
      console.log(err)
    }

  }

  gotoDetailsPage = (event) => {
    let pageId = event.currentTarget.value
    this.props.history.push(`/help/${pageId}/details`)
  }

  componentDidMount() {
    this.loadStaffFaq();
  }

  render() {
    return (
      <div className="help-details-page p-mt-3 p-mb-4">
        <div className="p-card">
          <div className="p-card-body">
            <h3 className="card-title-section">{this.state.helpData.page_title}</h3>
            <div dangerouslySetInnerHTML={{ __html: this.state.helpData.page_content }}></div>
          </div>
        </div>
      </div>
    );
  }

}
const mapStateToProps = (state) => ({
  ad: state.appDetails,
});

export default withRouter(connect(mapStateToProps)(HelpDetails));