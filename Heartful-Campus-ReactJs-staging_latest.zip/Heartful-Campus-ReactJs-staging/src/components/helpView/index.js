import React, { Component } from 'react';

// shared components
import HFNLoader from 'shared-components/lazyLoading';

import { Switch, } from "react-router-dom";

// components
import AuthGuard from 'auth-guard/index';

import HelpDetails from 'components/helpView/HelpDetails';

import HelpViewQuestions from 'components/helpView/HelpQuestions';

class HelpView extends Component {
  render() {
    return (
      <div className="container">
        <HFNLoader>
          <Switch>
            <AuthGuard exact path='/help/details/:id' component={HelpDetails} />
            <AuthGuard path='/help' component={HelpViewQuestions} />
          </Switch>
        </HFNLoader>
      </div>
    );
  }

}


export default HelpView;