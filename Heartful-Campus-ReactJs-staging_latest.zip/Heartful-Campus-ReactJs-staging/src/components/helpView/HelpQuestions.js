import React, { Component } from 'react';

// routes 
import { withRouter } from "react-router";

// state 
import { connect } from "react-redux";

// utils 
import buildBreadcrumb from "utils/breadcrumb";

import { response } from 'utils/response';

// services 
import FaqService from 'services/faq/faq.service';

import { getUserType } from 'utils/common';


class HelpQuestions extends Component {

  constructor(props) {

    super(props);

    this.faqService = new FaqService();

    const breadCrumb = [
      { label: "Dashboard", url: "dashboard", icon: 'pi pi-home' },
      { label: "Help", url: "dashboard/help", },
    ];
    if (getUserType() === "CS") {
      breadCrumb.shift()
    }

    this.state = {
      breadcrumbs: breadCrumb,
      helpData: []
    };

  }

  loadHelpList = async () => {

    let params;

    params = {
      "lazyEvent": {
        "rows": 10, "page": 1,
      }
    };
    try {
      const apiResponse = await response.addNoMessage({
        service: this.faqService,
        method: 'getHelpList',
        data: { item: params }
      })

      if (apiResponse && apiResponse.data) {

        const helpData = apiResponse.data.data;

        this.setState({
          helpData: helpData
        });

      }
    } catch (err) {
      console.log(err)
    }

  }

  gotoDetailsPage = (event) => {
    let pageId = event.currentTarget.value
    this.props.history.push(`/help/details/${pageId}`)
  }
  componentDidMount() {
    buildBreadcrumb(this.props, this.state.breadcrumbs);
    this.loadHelpList();
  }
  render() {
    return (
      <div className="help-page p-mt-3 p-mb-4">
        <div className="p-card">
          <div className="p-card-body">
            <h3 className="card-title-section">Help Page</h3>
            {(Array.isArray(this.state.helpData) && this.state.helpData.length > 0) ?
              <ol className="item-listing" type="number">
                {this.state.helpData.map((data, index) => {
                  return (
                    <li key={index} value={data.page_id} onClick={this.gotoDetailsPage}>
                      <u>{data.page_title}</u>
                    </li>)
                })}
              </ol> :
              <h4>No data found</h4>}
          </div>
        </div>

      </div>
    );
  }

}
const mapStateToProps = (state) => ({
  ad: state.appDetails
});

export default withRouter(connect(mapStateToProps)(HelpQuestions));