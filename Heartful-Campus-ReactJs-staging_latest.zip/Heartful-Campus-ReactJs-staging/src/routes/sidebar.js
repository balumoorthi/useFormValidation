const sidebarRoutes = [
  {
    userType: "U",
    route: [
      {
        url: "dashboard",
        label: "Dashboard",
        icon: "uil uil-home-alt",
      },
      {
        label: "Asset",
        icon: "uil uil-books",
        items: [
          {
            url: "assets/listing",
            label: "Manage Asset",
            icon: "uil uil-books",
          },
        ]
      },
      {
        label: "Asset Categories",
        url: "assets/category",
        icon: "uil uil-layer-group",
      },
      {
        label: "College",
        icon: "uil uil-university",
        url: "college/listing",
        className:"college",
        /* items: [
          {
            url: "college/listing",
            label: "Manage College",
            icon: "uil uil-university",
          },
          {
            url: "college/reports",
            label: "Reports",
            slug: "reports",
            icon: "uil uil-file-exclamation-alt",
          },
        ] */
      },
      {
        label: "User",
        icon: "uil uil-users-alt",
        url: "user/listing",
        className:"user",
        /* items: [
          {
            url: "user/listing",
            label: "Manage User",
            icon: "uil uil-folder-open",
          },
          {
            url: "user/collegestaff",
            label: "Manage College Staff",
            icon: "uil uil-folder-open"
          },
          {
            url: "user/report",
            label: "Report",
            icon: "uil uil-file-exclamation-alt"
          }
        ] */
      },
      {
        label: "Program",
        icon: "uil uil-file-landscape-alt",
        url: "program/listing",
        className:"list",
        /* items: [
          {
            url: "program/listing",
            label: "Manage Program",
            icon: "uil uil-adjust",
          },
          {
            url: "program/changerequest",
            label: "Change Request",
            slug: "changerequest",
            icon: "pi pi-user-edit",
          },
          {
            url: "program/reports",
            label: "Reports",
            slug: "reports",
            icon: "uil uil-file-exclamation-alt",
          },
        ] */
      },
      {
        label: "Trainer",
        icon: "uil uil-users-alt",
        url: "trainer/listing",
        className:"trainerMenu",
        /* items: [
          {
            url: "trainer/listing",
            label: "Manage Trainer",
            icon: "uil uil-folder-open",
          },
          {
            url: "trainer/report",
            label: "Report",
            slug: "reports",
            icon: "uil uil-file-exclamation-alt",
          }
        ] */
      },
      {
        url: "module",
        label: "Module",
        icon: "uil uil-adjust",
      },
      {
        url: "cms",
        label: "CMS",
        icon: "uil uil-image-edit",
      },
      {
        url: "faq",
        label: "FAQ",
        icon: "uil uil-comment-alt-question",
      },
      {
        label: "Standard Data",
        icon: "uil uil-database",
        items: [
          {
            url: "standard-data/zone",
            label: 'Manage Zone',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/country",
            label: 'Manage Country',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/level",
            label: 'Manage Level',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/discipline",
            label: 'Manage Discipline',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/unit",
            label: 'Manage Unit',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/moduletype",
            label: 'Manage Module Type',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/programtype",
            label: 'Manage Program Type',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/agegroup",
            label: 'Manage Age Group',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/language",
            label: 'Manage Language',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/faqcategory",
            label: 'Manage FAQ Category',
            icon: "fa fa-puzzle-piece",
          },
          {
            url: "standard-data/batch",
            label: 'Manage Batch',
            icon: "fa fa-puzzle-piece",
          },
        ]
      },
      {
        url: "privilege",
        label: "Privileges",
        icon: "uil uil-lock-access",
      },
    ]
  },
  {
    userType: "CS",
    route: [
      {
        url: "mycollege",
        label: "My College",
        icon: "uil uil-university",
      }
    ]
  },
  {
    userType: "T",
    route: [
      {
        url: "dashboard",
        label: "Dashboard",
        icon: "uil uil-home-alt",
      },
      {
        url: "myprograms",
        label: "My Programs",
        icon: "uil uil-file-landscape-alt",
        className:"list",
      },
    ]
  },
  {
    userType: "CS",
    route: [
      {
        url: "dashboard",
        label: "Dashboard",
        icon: "uil uil-home-alt",
      },
      {
        url: "mycollege",
        label: "My College",
        icon: "uil uil-university",
      }
    ]
  },
  {
    userType: "POC",
    route: [
      {
        url: "dashboard",
        label: "Dashboard",
        icon: "uil uil-home-alt",
      },
      {
        label: "College",
        icon: "uil uil-university",
        url: "college/listing",
        className:"college",
        /* items: [
          {
            url: "college/listing",
            label: "Manage College",
            icon: "uil uil-university",
          }
        ] */
      },
      {
        label: "Program",
        icon: "uil uil-file-landscape-alt",
        url: "program/listing",
        className:"list",
        /* items: [
          {
            url: "program/listing",
            label: "Manage Program",
            icon: "uil uil-adjust",
          },
          {
            url: "program/changerequest",
            label: "Change Request",
            slug: "changerequest",
            icon: "pi pi-user-edit",
          }
        ] */
      },
    ]
  }
];

export {
  sidebarRoutes
};
